switch (process.env.NODE_ENV) {
  case 'development':
    module.exports = require('./config/development');
    break;
  case 'staging':
    module.exports = require('./config/staging');
    break;
  case 'production':
    module.exports = require('./config/production');
    break;
  default:
    console.error("Unrecognized NODE_ENV: " + process.env.NODE_ENV);
    process.exit(1);
    break;
}
