Default ViewportLayer example:

```html
<ViewportLayer>
  Level 0
</ViewportLayer>
```

Multiple ViewportLayers example:

```html
<div>
  <ViewportLayer>
    Level 0
  </ViewportLayer>
  <ViewportLayer zIndex={10}>
    Level 1
  </ViewportLayer>
</div>
```
