import React from 'react';
import PropTypes from 'prop-types';

const propTypes = {
  /** element/s contained by this component */
  children: PropTypes.node,
  /** higher value puts layer in foreground */
};

const defaultProps = {
  children: null,
};

/**
 * The `ViewportLayer` component is a fixed flex container that occupies the
 * entire viewport. Multiple ViewportLayers can be stacked on top of one
 * another using the `zIndex` prop.
 */
const ViewportLayer = ({ children, ...other }) => {
  return (
    <div {...other} className="layer">
      {children}
    </div>
  )
};

ViewportLayer.propTypes = propTypes;
ViewportLayer.defaultProps = defaultProps;

export default ViewportLayer;
