import React from 'react'
import '../../public/styles/commons/uploadFile/uploadFile.scss';
import Ic_Add from '../../public/images/icons/ic_add.png';
import Image from './Image';
import AlertModal from '../../js/views/components/alertModal/AlertModal'
import {connect} from "react-redux";
import {hideAlert, showAlert} from "../../js/actions/share";

class AddImage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fileName: "",
      isShowWarningMessage: false,
      warningMessage: "",
      isShowDialog: false,
      addImages: "add-images"
    };
  }

  componentWillUpdate(nextProps, nextState) {
    if (nextProps.listImages !== this.props.listImages) {
      for (let i = 0; i < nextProps.listImages.length; i++) {
        if (nextProps.listImages[i]) {
          this.setState({
            addImages: "add-images-disabled"
          });
        }
      }
    }
  }

  uploadImage = (files) => {
    let uploadImageFiles = Array.prototype.filter.call(files, file => {
      if ((file.type.includes('image/jpeg') || file.type.includes('image/png')) &&
        (file.name.split('.').pop() === 'jpg' || file.name.split('.').pop() === 'png' || file.name.split('.').pop() === 'PNG')) {
        return file;
      }
    });

    if (uploadImageFiles.length > 1) {
      let imgId = this.props.click;
      document.getElementById(imgId).value = null;
      this.setState({
        isShowDialog: false
      });
      this.props.showAlert('Please select only one image file .jpg or .png!');
      return;
    }
    if (uploadImageFiles[0].size > 3 * 1024 * 1024) {
      let imgId = this.props.click;
      document.getElementById(imgId).value = null;
      this.setState({
        isShowDialog: false
      });
      this.props.showAlert('The uploaded file is too large. File need to be smaller than 3 Mb');
      return;
    }

    let srcList = [];
    let count = 0;
    for (let i = 0; i < uploadImageFiles.length; i++) {
      let imageObj = {file: uploadImageFiles[i]};
      let reader = new FileReader();
      reader.onloadend = () => {
        imageObj.src = reader.result;
        count++;
        if (count === uploadImageFiles.length) {
          this.setState({
            fileName: uploadImageFiles[0].name,
            isShowDialog: false
          });
          this.props.watchChangeImg([...this.props.listImages, ...srcList], this.props.id, 'change');
        }
      };
      reader.readAsDataURL(uploadImageFiles[i]);
      srcList.push(imageObj);
    }
    if (this.props.listImages.length >= 0) {
      this.setState({
        addImages: "add-images-disabled"
      });
    }
  };

  componentDidMount() {
    let dropZone = document.getElementById(this.props.id);
    dropZone.ondrop = (e) => {
      e.preventDefault();
      this.className = 'upload-image';
      let files = e.dataTransfer.files;
      this.uploadImage(files);
    };
    dropZone.ondragover = () => {
      this.className = 'upload-image drop';
      this.setState({
        isShowDialog: true
      });
      return false;
    };
    dropZone.ondragleave = () => {
      this.className = 'upload-image';
      this.setState({
        isShowDialog: false
      });
      return false;
    }
  }

  removeImg = (index) => {
    let listImage = [];
    //listImage.splice(index, 1);
    this.props.watchChangeImg(listImage, this.props.id, 'delete');
    this.setState({
      addImages: "add-images"
    });
    let imgId = this.props.click;
    document.getElementById(imgId).value = null;
  };

  upload = () => {
    let imgId = this.props.click;
    document.getElementById(imgId).click();
  };

  onUpload = () => {
    let files = document.getElementById(this.props.click).files;
    this.uploadImage(files);
  };

  render() {
    const {resolutionX, resolutionY, id, click} = this.props;
    let imgList = [];
    for (let i = 0; i < this.props.listImages.length; i++) {
      if (this.props.listImages[i]) {
        imgList.push(<Image key={i} src={this.props.listImages[i].src} ind={i} removeImg={this.removeImg}/>);
        break;
      }
    }

    return (

      <div className="group-images">
        <AlertModal/>
        <div className="view-group-images">
          {imgList}
          <div className={this.state.addImages}>
            <div className="upload-image" id={id}>
              <div hidden>
                <input type="file" id={click} onChange={this.onUpload} accept=".jpg, .png"/>
              </div>
              <div onClick={this.upload} className="upload-image-add">
                <img className="ic-add" src={Ic_Add}/>
              </div>
              <div className="upload-image-text">Add image</div>
              <div className="upload-image-text">Drop image here</div>
            </div>
            {this.state.isShowDialog === true && <div className="upload-image-dragover">Image is dragovering</div>}
          </div>
          <div className="upload-image-info-group">
            <div className="upload-image-info-title">Recommended size:</div>
            <div className="upload-image-info-size">{resolutionX}px*{resolutionY}px</div>
          </div>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = function (dispatch) {
  return ({
    hideAlert: () => {
      dispatch(hideAlert());
    },
    showAlert: (message) => {
      dispatch(showAlert(message));
    }
  })
};

export default connect(null, mapDispatchToProps)(AddImage);