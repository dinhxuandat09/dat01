import {SET_VIEW_MODE} from '../utils/Constants';

export const setViewMode = (viewMode) => {
  return {
    type: SET_VIEW_MODE,
    viewMode
  };
}