import { CHANGE_COLLECTION, TOGGLE_COLLECTION } from '../utils/constants/actiontypes';

export const changeCollection = key => ({
  type: CHANGE_COLLECTION,
  payload: key,
});

export const toggleCollection = () => ({
  type: TOGGLE_COLLECTION,
});