import { OPEN_DIALOG, CLOSE_DIALOG } from '../utils/constants/actiontypes';

export const openDialog = props => ({
  type: OPEN_DIALOG,
  payload: props,
});

export const closeDialog = () => ({
  type: CLOSE_DIALOG,
});
