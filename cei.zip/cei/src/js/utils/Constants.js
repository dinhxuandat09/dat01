export const LOGGED_IN = 'LOGGED_IN';
export const LOG_OUT = 'LOG_OUT';

export const LOCALE_SWITCHED = 'LOCALE_SWITCHED';
export const SHOW_ERROR = 'SHOW_ERROR';
export const HIDE_ERROR = 'HIDE_ERROR';

export const ERROR = 'ERROR';
export const SET_VIEW_MODE = "SET_VIEW_MODE";

export const COOKIE_OPTION = {
  path: '/'
};
export const VIEW_MODE = {
  'TILE_VIEW': 'TILE_VIEW',
  'LIST_VIEW': 'LIST_VIEW'
};
export const COOKIE_DEFAULT_EXPIRES = parseInt(1800);
export const DEFAULT_LOGIN_SESSION_EXPIRES = parseInt(1800);

var buildTargetRole = 'portal';
export const BUILD_TARGET_ROLE = buildTargetRole;
export const KEYS = {
  apiToken: 's1',
  uidToken: 'uid',
  ssoToken: 'iPlanetDirectoryPro',
  ssoTokenOpt: 'iPlanetDirectoryProOptVal',
};

export const SET_ROLE = 'SET_ROLE';
// Action types naming