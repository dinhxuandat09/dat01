export function createRequestData(data) {
  let newData = {
    records: []
  }
  if (Array.isArray(data)) {
    newData.records = [...data];
  } else {
    newData.records.push(data);
  }
  return newData;
}

export function createDeleteRequestData(data) {
  let newData = data.map(value => {
    return {
      record_id: value,
      mod_timestamp: new Date().getTime()
    }
  })
  return createRequestData(newData);
}

export function transformResponse(data) {
  let newData = [];
  newData = data.records;
  return newData;
}