import { map, isArray, isUndefinedOrNull, isString, isDefined, each, isEmpty, indexOf, contains, pluck } from 'lodash';

export function jsonParse(string) {
  try {
    return JSON.parse(string);
  } catch (err) {
    return '[]';
  }
}

export function extractIds(list) {
  return map(list, function (item) {
    return item.id;
  });
}

export function getBaseHref() {
  var baseTag = document.getElementsByTagName('base')[0];
  return baseTag.outerHTML.substring(baseTag.outerHTML.indexOf('/') + 1, baseTag.outerHTML.lastIndexOf('/'));
}

export function startsWith(string, prefix) {
  return string.indexOf(prefix) === 0;
}

export function endsWith(string, suffix) {
  return string.indexOf(suffix, string.length - suffix.length) !== -1;
}

export function arrayToString(array) {
  if (isArray(array)) {
    return array.join(', ');
  }
  return array;
}

export function generateGUID() {
  var s4 = function () {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
    ;
  return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
}

export function verifyGUID(guid) {
  var pattern = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
  return pattern.test(guid);
}

export function preventEventBubbling(event) {
  event.preventDefault();
  event.stopPropagation();
}

var languageMapping = jsonParse('<%= languageMapping %>');
export function findMappingLocale(languages) {
  var language = "en-US";
  var lowerCaseLanguage = '';
  if (isArray(languages)) {
    if (isUndefinedOrNull(languages[0])) {
      return language;
    } else {
      lowerCaseLanguage = languages[0].toLowerCase().split(';')[0];
    }
  }
  else if (isString(languages)) {
    lowerCaseLanguage = languages.toLowerCase();
  }

  for (var localeKey in languageMapping) {
    var list = map(languageMapping[localeKey], function (i) {
      return i.toLowerCase();
    });

    if (contains(list, lowerCaseLanguage)) {
      return localeKey;
    }
  }
  return language;
}

export function urlParser(url) {
  var regExp = "^(((([^:\\/#\\?]+:)?(?:(\\/\\/)((?:(([^:@\\/#\\?]+)(?:\\:([^:@\\/#\\?]+))?)@)" +
    "?(([^:\\/#\\?\\]\\[]+|\\[[^\\/\\]@#?]+\\])(?:\\:([0-9]+))?))?)?)?((\\/?(?:[^\\/\\?#]+\\/+)*)([^\\?#]*)))?(\\?[^#]+)?)(#.*)?";
  var matches = new RegExp(regExp).exec(url);
  return {
    href: matches[0],
    withoutHash: matches[1],
    url: matches[2],
    origin: matches[3],
    protocol: matches[4],
    protocolseparator: matches[5],
    credhost: matches[6],
    cred: matches[7],
    user: matches[8],
    pass: matches[9],
    host: matches[10],
    hostname: matches[11],
    port: matches[12],
    pathname: matches[13],
    segment1: matches[14],
    segment2: matches[15],
    search: matches[16],
    hash: matches[17]
  };
}

export function pushExceptDuplicated(list, item, property, isExtend) {
  var pluckList = property ? pluck(list, property) : list;

  var index = indexOf(pluckList, item[property] || item);
  if (index === -1) {
    list.push(item);
  } else if (isExtend) {
    list[index] = item;
  }
}

export function buildUrl(url, params) {
  var queryStr = "";
  for (var key in params) {
    var value = params[key];
    if (isDefined(value)) {
      if (isArray(value)) {
        each(value, function (val) {
          queryStr += encodeURIComponent(key) + "=" + encodeURIComponent(val) + "&";
        });
      }
      else {
        queryStr += encodeURIComponent(key) + "=" + encodeURIComponent(value) + "&";
      }
    }
  }
  if (isEmpty(queryStr)) {
    return url;
  } else {
    return url + "?" + queryStr.replace(/\&$/gi, '');
  }
}

export function extractExtension(fileName) {
  return fileName.split('.').pop();
}

export function conparationObjectById(obj1, obj2, isTag) {
  //true is same
  if(obj1 !== null && obj2 !== null  && obj1 !== undefined && obj2 !== undefined && obj1.constructor === obj2.constructor) {
    if(obj1 instanceof Array) {
      if(obj1.length === obj2.length) {
        if(!isTag){
          for(let i=0; i<obj1.length; i++) {
            if(obj1[i].id !== obj2[i].id) {
              return false;
            }
          }
        } else {
          for(let i=0; i<obj1.length; i++) {
            if(obj1[i].name !== obj2[i]) {
              return false;
            }
          }
        }
        return true;
      } else {
        return false;
      }
    } else {
      return obj1.id === obj2.id;
    }
  } else {
    //not same type
    return false;
  }
}