import PropTypes from 'prop-types'; // ES6
import React from 'react';
import ReactDOM from 'react-dom';
import { Redirect, Route } from 'react-router'
import { ReduxRouter } from 'redux-router'
import { Provider, connect } from 'react-redux';
import * as i18n from './i18n'
import { IntlProvider } from 'react-intl'
import * as SecurityService from './utils/securityService'
import 'babel-polyfill'


import {
  MainPage,
  PageNotFound,
  BuildTestBinary,
  CodeDiff,
  LastLogin,
  CIAReport,
  UploadTestLog,
  SearchResultPage
} from "./views/pages";
import * as constants from './utils/Constants';
import * as storage from './persistence/storage';
import Application from './application';

//style 
import css from '../public/styles/main.scss';

// Redux
import configureStore from './utils/configure-store';

const initialState = {
  application: {
    system: {
      token: storage.get('token'),
      locale: storage.get('locale') || 'en',
      user: { permissions: [/*'manage_account'*/] }
    }
  }
};
export const store = configureStore(initialState);

function getRootChildren(props) {
  const { locale } = props.application.system;
  const intlData = {
    locale: locale,
    messages: i18n[locale]
  };
  const rootChildren = [
    <IntlProvider key="intl" {...intlData}>
      {renderRoutes(props)}
    </IntlProvider>
  ];

  return rootChildren
}

function logout(nextState, replaceLocation) {
  store.dispatch({ type: constants.LOG_OUT });
  SecurityService.requestLogOut();
}

function requireLogin(nextState, replaceLocation) {
  if (!SecurityService.isLoggedIn()) {
    replaceLocation('/login');
  }
}

function renderRoutes(props) {
  return (
    <ReduxRouter>
      <Route component={Application}>
        <Route path="/" component={MainPage}>
          <Route path="/BuildTestBinary" component={BuildTestBinary} />
          <Route path="/CodeDiff" component={CodeDiff} />

          <Route path="/CIAReport" component={CIAReport} />
          <Route path="/UploadTestLog" component={UploadTestLog} />
          <Route path="/Search/:searchKey" component={SearchResultPage} />
        </Route>
        <Route path="/main" onEnter={requireLogin} component={MainPage} />
        <Route path='/PageNotFound' component={PageNotFound} />
        <Redirect from='*' to='/PageNotFound' />
      </Route>
    </ReduxRouter>
  )
}

class Root extends React.Component {
  static propTypes = {
    application: PropTypes.object.isRequired
  };

  render() {
    return (
      <div>{getRootChildren(this.props)}</div>
    )
  }
}

const mapStateToProps = (state) => ({
  application: state.application
});

const mapDispatchToProps = (dispatch) => ({
});

export default connect(mapStateToProps, mapDispatchToProps)(Root)
