import React from 'react';
import { connect } from "react-redux";
import { push } from "redux-router";
import '../../../../public/styles/commons/share/body.scss';
import '../../../../public/styles/pages/BuildTestBinary.scss';
import Header from '../../components/share/header';
import { loadToolFunc, reloadToolPage } from "../../../actions/share";
import { showProgress, hideProgress, actionModal } from "../../../actions/share";
import ProgressModal from '../../components/progressModal/ProgressModal';
import { select } from 'react-cookie';
import ComponentDropdown from '../../components/ComponentDropdown';
import * as commonService from '../../../service/commonService';
import BinaryTable from './BinaryTable';
import * as BinaryService from '../../../service/BuilTestBinary/BuilTestBinary';
import UltimatePagination from "react-ultimate-pagination-bootstrap-4";
import PickModelListComponent from '../../components/pickModelListComponent/pickModelListComponent';
import ModuleComponent from '../../components/moduleInfoComponent/moduleComponent';
import VersionComponent from '../../components/moduleInfoComponent/versionComponent';
import {showAlert} from "../../../../js/actions/share";
import ComponentPagination from '../../components/ComponentPagination';
let searchBinary = {};
let pageShow = {};
let checkQuickBuildData = {};
let isPolling = false;
class BuildTestBinary extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dropdownIsOpen: false,
      modelBinaryTitle: 'Enter Model',
      listModelBinary: [],
      typeBinaryTitle: 'Search Type',
      listTypeBinary: [],
      moduleBinaryTitle: 'Enter Module Name',
      listModuleBinary: [],
      versionBinaryTitle: 'Enter Version',
      listVersionBinary: [],
      codetypeBinaryTitle: 'Java',
      listCodeTypeBinary: [],
      qbServerBinaryTitle: 'Enter QB Sever',
      listQBServerBinary: [],
      qbIDBinaryTitle: '',
      listQBIDBinary: [],
      severBinaryTitle: '1717',
      pathBinaryTitle: '',
      listPathBinary: [],
      commmitBinaryTitle: '',
      listCommitBinary: [],
      listBuildLog: {
        list: [],
        pageNum :'',
 
      },
      TotalTCPage: 1,
      currentTCPage: 1,
      totalCount: 0
    };

  }

  componentWillMount() {
    pageShow = {};
    searchBinary = {};
    checkQuickBuildData = {};
    this.props.showProgress();
    commonService.getModel(null, (res) => {
      this.props.hideProgress();
      this.setState({
        listModelBinary: res.data.value.list
      })
    }, (error) => {
      this.props.hideProgress();
    });
    isPolling = false;
    this.getServer();
    this.getAllCheckBuildBinary(pageShow);
  };

  componentWillUnmount () {
    clearTimeout(this.setTimeOut);
  };

  getTypeByModel = () => {
    let data = {
      modelId: searchBinary.modelId,
    };
    this.props.showProgress();
    commonService.getTypeByModel(data, (res) => {
      this.props.hideProgress();
      let dropdownList = [];
      for (let i = 0; i < res.data.length; i++) {
        let item = { title: res.data[i], value: res.data[i] };
        dropdownList.push(item);
      }
      this.setState({
        listTypeBinary: dropdownList
      })
    }, (error) => {
      this.props.hideProgress();
    })
  };

  setLable = (codetypeList, qbserverList, qbidList, pathList, clList) => {
    this.setState({
      listCodeTypeBinary: codetypeList,
      listQBServerBinary: qbserverList,
      listQBIDBinary: qbidList,
      listPathBinary: pathList,
      listCommitBinary: clList
    })
  }

  getServer = () => {
    let data = {
      modelId: searchBinary.modelId,
      moduleId: searchBinary.moduleId,
      versionId: searchBinary.versionId
    };
    this.props.showProgress();
    commonService.getServerFromBinary(data, (res) => {
      this.props.hideProgress();
      let item = { title: res.data.value.list[0].server, value: res.data.value.list[0].id };
      this.setState({
        severBinaryTitle: item.title
      })
    }, (error) => {
      this.props.hideProgress();
    })
  };
  handleClickItemDropdown = (item, idDropdown) => {
    if (idDropdown === 'cia-model') {
      this.setState({
        modelBinaryTitle: item.title,
      });
      searchBinary.modelId = item.value;
      this.getTypeByModel()
    }
    if (idDropdown === 'cia-type') {
      this.setState({
        typeBinaryTitle: item.title,
      });
      searchBinary.type = item.value;
    }
    if (idDropdown === 'cia-module') {
      this.setState({
        moduleBinaryTitle: item.title,
      });
      searchBinary.moduleId = item.value;
    }
    if (idDropdown === 'cia-version') {
      this.setState({
        versionBinaryTitle: item.title,
      });
      searchBinary.versionId = item.value;
      this.CkeckImformation(item.index);
    }
  };

  CkeckImformation = (data) => {
    this.setState({
      codetypeBinaryTitle: this.state.listCodeTypeBinary[data].title,
      qbServerBinaryTitle: this.state.listQBServerBinary[data].title,
      qbIDBinaryTitle: this.state.listQBIDBinary[data].title,
      pathBinaryTitle: this.state.listPathBinary[data].title,
      commmitBinaryTitle: this.state.listCommitBinary[data].title
    });
  };

  getAllCheckBuildBinary = (data) => {
    this.props.showProgress();
    BinaryService.getAllCheckBuilFromBinary(data, (res) => {
      if (res.data.value.totalCount) {
        this.setState({
          listBuildLog : {list: res.data.value.list, pageNum : 0},
          totalCount: res.data.value.totalCount,
          TotalTCPage: Math.ceil(res.data.value.totalCount / 10) !== 0 ? Math.ceil(res.data.value.totalCount / 10) : 1
        });
        if (data.versionId) {
          let checkBuilding = false;
          for (let i = 0; i < res.data.value.list.length; i++) {
            if (res.data.value.list[i].status === 'RUNNING' || res.data.value.list[i].status === 'New') {
              checkBuilding = true;
              break;
            }
          }
          if (checkBuilding) {
            this.props.actionModal('Message', 'Another user is building this test binary. ' +
              'Please wait until the building process is completed then try again.', true, () => {
            }, () => {
            });
            if(!isPolling){
              this.pollingBuildTestBinary();
            }
          } else {
            this.props.actionModal('Message', 'This build was created by another user. You want to rebuild?', true, () => {
              this.buildTestBinary(data);
            }, () => {
            });
          }
        }
      } else {
        this.buildTestBinary(data);
      }
      this.props.hideProgress();
    }, (error) => {
      this.props.hideProgress();
    })
  };

  pollingBuildTestBinary = () => {
    BinaryService.getAllCheckBuilFromBinary(pageShow, (res) => {
      this.setState({
        listBuildLog:{list: res.data.value.list, pageNum: pageShow.pageNum},
        TotalTCPage: Math.ceil(res.data.value.totalCount / 10) !== 0 ? Math.ceil(res.data.value.totalCount / 10) : 1
      });
      let checkBuilding = false;
      for (let i = 0; i < res.data.value.list.length; i++) {
        if (res.data.value.list[i].status === 'RUNNING' || res.data.value.list[i].status === 'New') {
          checkBuilding = true;
          break;
        }
      }
      if (checkBuilding) {
        isPolling = true;
        this.setTimeOut = setTimeout(this.pollingBuildTestBinary, 5000);
      } else {
        isPolling = false;
      }
    }, () => {
    });
  };

  buildTestBinary = (data) => {
    BinaryService.builFromBinary(data, (res) => {
      if (!isPolling) {
        this.pollingBuildTestBinary();
      }
    }, (res) => {
    })
  };
  checkQuickBuild = (data, pageShow)=>{
    BinaryService.checkQuickBuild(data, (res) => { 
      if (res.data != '') {
        this.getAllCheckBuildBinary(pageShow);
      } else {
        this.props.showAlert("Configuration quickbuild unavaliable");
      }
    }, (res) => {})
  };

  onClickCheckBuild = () => {
    checkQuickBuildData.modelId = searchBinary.modelId;
    checkQuickBuildData.moduleId = searchBinary.moduleId;
    checkQuickBuildData.versionId = searchBinary.versionId;
    checkQuickBuildData.pageNum = 0;
    this.checkQuickBuild("/root"+this.state.pathBinaryTitle.substr(1),checkQuickBuildData);
  };

  handleChangeTCPage = (pageNumber) => {
    this.setState({
      currentTCPage: pageNumber
    });
    pageShow.pageNum = pageNumber - 1;
    if (pageNumber === 1) {
      isPolling = false;
    }
    this.pollingBuildTestBinary(pageShow);
  };


  clearType = () => {
    this.setState({
      typeBinaryTitle: 'Search type',
      listTypeBinary: [],
    });
    searchBinary.type = null;
  };

  clearModuleName = () => {
    this.setState({
      moduleBinaryTitle: 'Enter Module Name'
    });
    searchBinary.moduleId = null;
  };

  clearVersion = () => {
    this.setState({
      versionBinaryTitle: 'Enter Version'
    })
  };
  clearAllLabel = () => {
    this.setState({
      codetypeBinaryTitle: 'Java',
      listCodeTypeBinary: [],
      qbServerBinaryTitle: 'Enter QB Sever',
      listQBServerBinary: [],
      qbIDBinaryTitle: '',
      listQBIDBinary: [],
      severBinaryTitle: '',
      pathBinaryTitle: '',
      listPathBinary: [],
      commmitBinaryTitle: '',
      listCommitBinary: [],
    })
  };
  clearDropDownFunc = (idDropdown) => {
    if (idDropdown === 'cia-model') {
      this.clearType();
      this.clearModuleName();
      this.clearVersion();
      this.clearAllLabel()
    }
    if (idDropdown === 'cia-type') {
      this.clearModuleName();
      this.clearVersion();
      this.clearAllLabel()
    }
    if (idDropdown === 'cia-module') {
      this.clearVersion();
      this.clearAllLabel()
    }
    if (idDropdown === 'cia-verson') {
      this.clearAllLabel()
    }
  };
  pickModel = (item) => {
    this.clearDropDownFunc('cia-model');
    this.setState({
      modelBinaryTitle: item.title,
    });
    searchBinary.modelId = item.value;
    this.getTypeByModel()
  };

  onHandleClick = (item) => {
    this.clearVersion();
    this.clearAllLabel();
    this.setState({
      moduleBinaryTitle: item.title,
    });
    searchBinary.moduleId = item.value;
  };

  onHandleClickVersion = (item) => {
    this.clearAllLabel();
    this.setState({
      versionBinaryTitle: item.title
    });
    searchBinary.versionId = item.value;
    this.CkeckImformation(item.index);
  };

  render() {
    return (
      <div>
        <ProgressModal />
        <Header />
        <div className="content">
          <div className="content-title">
            <div className="content-title-text cia-title">Buil Test Binary</div>
            <div className="content-title-square"></div>
          </div>

          <div className="content-border"></div>

          <div className="content-body">
            <div className="module-info">
              <div className="module-info-title cia-title-small"><span>Module Info</span></div>
              <div className="row module-info-content">
                <div className=" medium col-lg-2"><span className="cia-label">Model</span>
                  <div className=''><PickModelListComponent
                    pickModel={this.pickModel}
                    modelTitle={this.state.modelBinaryTitle}
                  /></div>
                </div>
                <div className=" medium col-lg-2 "><span className="cia-label">Type</span>
                  <ComponentDropdown title={this.state.typeBinaryTitle}
                    iddropdown="cia-type" className=""
                    listSearchStatus={this.state.listTypeBinary}
                    handleClickItemDropdown={this.handleClickItemDropdown}
                  />
                </div>
                <ModuleComponent pickModule={this.onHandleClick}
                                 modelId={searchBinary.modelId}
                                 type={searchBinary.type}
                                 moduleTitle={this.state.moduleBinaryTitle}/>
                <VersionComponent pickVersion={this.onHandleClickVersion}
                                  modelId={searchBinary.modelId}
                                  title="Version"
                                  moduleId={searchBinary.moduleId}
                                  type={searchBinary.type}
                                  setLable={this.setLable}
                                  isSetLable={true}
                                  versionTitle={this.state.versionBinaryTitle}/>
                <div className=" small col-lg-2"><span className="  cia-label">Code Type</span>
                  <input type="text" className="cia-text" value={this.state.codetypeBinaryTitle} />
                </div>
              </div>

              <div className="row module-info-content">
                <div className=" medium col-lg-2"><span className=" padding-5 cia-label">QB Server</span>
                  <div className=""><input type="text" className=" cia-text"
                    value={this.state.qbServerBinaryTitle} /></div>
                </div>
                <div className=" medium col-lg-2"><span className=" cia-label">QB ID</span>
                  <div className=""><input type="text" className=" cia-text"
                    value={this.state.qbIDBinaryTitle} /></div>
                </div>
                <div className=" medium col-lg-3"><span className=" padding-0 cia-label">Server</span>
                  <div className=" padding-0"><input type="text" className=" cia-text"
                    value={this.state.severBinaryTitle} /></div>
                </div>
                <div className=" medium col-lg-3"><span className=" cia-label">Path</span>
                  <div className=""><input type="text" className=" cia-text"
                    value={this.state.pathBinaryTitle} /></div>
                </div>
                <div className=" small col-lg-2"><span className=" cia-label">CL/Commit</span>
                  <input type="text" className="cia-text " value={this.state.commmitBinaryTitle} />
                </div>
              </div>
            </div>
          </div>

          <div className="border-check-build">
            <button className="btn btn-check-build btn-primary" onClick={this.onClickCheckBuild}> Check & Build</button>
          </div>

          <div className="border-latest-build cia-title"><span>Latest Build</span></div>
          <div className="table-binary">
            <BinaryTable listBuildLog={this.state.listBuildLog} />
          </div>
          <div className="pagination-body">
          {this.state.listBuildLog.list && this.state.listBuildLog.list.length > 0 &&
              <ComponentPagination
                totalCount ={this.state.totalCount}
                pageNum={this.state.listBuildLog.pageNum}
                currentPage={this.state.currentTCPage}
                totalPages={this.state.TotalTCPage}
                onChange={this.handleChangeTCPage}
              />
            }
          </div>
        </div>
      </div>

    );
  }
}

const mapStateToProps = (state) => ({
  listCategory: state.application.share.listCategory,
  setSearchText: state.application.share.functionSetSearchText,
  isShowProgress: state.application.share.progressModal.isShow
});


const mapDispatchToProps = dispatch => {
  return {
    actionModal: (title, message, isShow, successCallBack, failCallBack, disableSubmitBtn) => {
      dispatch(actionModal(title, message, isShow, successCallBack, failCallBack, disableSubmitBtn));
    },
    redirectPage: url => {
      dispatch(push(url));
    },
    setLoadToolFunc: (func) => {
      dispatch(loadToolFunc(func));
    },
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    },
    reloadToolPage: (func) => {
      dispatch(reloadToolPage(func));
    },
    showAlert: (message) => {
      dispatch(showAlert(message));
    }
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(BuildTestBinary);