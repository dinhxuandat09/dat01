import React from 'react'
import { connect } from 'react-redux';
import { push } from 'redux-router';

class AppRedirect extends React.Component {
  constructor(props) {
    super(props);
    this.props.redirectPage('/main');
  }

  render() {
    return (<div></div>)
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    redirectPage: (url) => {
      dispatch(push(url));
    }
  }
};

export default connect(null, mapDispatchToProps)(AppRedirect);