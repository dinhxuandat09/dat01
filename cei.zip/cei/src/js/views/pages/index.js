export { default as MainPage } from './MainPage';
export { default as PageNotFound } from './PageNotFound';
export { default as BuildTestBinary } from './BuildTestBinary/BuildTestBinary';
export { default as CodeDiff } from './CodeDiff/CodeDiff';
export { default as CIAReport } from './CIAReport/CIAReport';
export { default as UploadTestLog} from './UploadTestLog/UploadTestLog';
export { default as SearchResultPage} from './Search/SearchResultPage';