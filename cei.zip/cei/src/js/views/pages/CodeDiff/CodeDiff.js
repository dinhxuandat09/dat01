import React from 'react';
import { connect } from "react-redux";
import { push } from "redux-router";
import '../../../../public/styles/commons/share/body.scss';
import '../../../../public/styles/pages/CodeDiff.scss';
import Header from '../../components/share/header';
import ProgressModal from '../../components/progressModal/ProgressModal';
import * as commonService from '../../../service/commonService';
import * as codeDiffService from '../../../service/codeDiff/codeDiff';
import ComponentDropdown from '../../components/ComponentDropdown';
import '../../../../public/styles/pages/CIATable.scss';
import CodeDiffTable from './codeDiffTable';
import PickModelListComponent from '../../components/pickModelListComponent/pickModelListComponent';
import PickModuleListComponent from '../../components/pickModelListComponent/pickModuleListComponent';
import { showProgress, hideProgress } from "../../../actions/share";
import VersionComponent from '../../components/moduleInfoComponent/versionComponent';
import TargetVersionComponent from '../../components/moduleInfoComponent/targetVersionComponent';
import ComponentPagination from '../../components/ComponentPagination';
let SearchCIA = {};
let listSearchStatus = [];

class CodeDiff extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      listModelCIA: [],
      TypeCIATitle: 'Enter Type',
      listTypeCIA: [],
      BaseVersionCIATitle: 'Enter Version',
      listBaseVersionCIA: [],
      targetVersionCIATitle: 'Enter Version',
      listTargetVersionCIA: [],
      baseVersionInfo: {
        qbServer: '',
        path: '',
        cl: '',
        qbServerList: [],
        pathList: [],
        clList: []
      },
      targetVersionInfo: {
        qbServer: '',
        path: '',
        cl: '',
        qbServerList: [],
        pathList: [],
        clList: []
      },
      codeDiffTable: {
        list: [],
        pageNum: '',
      },
      TotalCodeDiffPage: 1,
      currentCodeDiffPage: 1,
      totalCount: 0,
    }
  }


  componentWillMount() {
    this.props.showProgress();
    commonService.getModel(null, (res) => {
      this.props.hideProgress();
      this.setState({
        listModelCIA: res.data.value.list
      })
    }, (error) => {
      this.props.hideProgress();
    });
    this.getAllCodeDiff();
  };

  componentWillUnmount() {
    clearTimeout(this.timeOut);
  };

  clearDropDownFunc = (idDropdown) => {
    if (idDropdown === 'cia-model') {
      this.clearDataType();
      this.clearDataModule();
      this.clearDataBaseVersion();
      this.clearDataTargetVersion()
    }
    if (idDropdown === 'cia-type') {
      this.clearDataModule();
      this.clearDataBaseVersion();
      this.clearDataTargetVersion()
    }
  };

  clearDataType = () => {
    SearchCIA.type = '';
    this.setState({
      TypeCIATitle: 'Enter Type',
      listTypeCIA: [],
    })
  };

  clearDataModule = () => {
    SearchCIA.moduleName = '';
  };
  clearDataBaseVersion = () => {
    SearchCIA.baseVersionId = '';
    SearchCIA.baseCL = '';
    SearchCIA.basePath = '';
    SearchCIA.baseServer = '';
    this.setState({
      BaseVersionCIATitle: 'Enter Version',
      listBaseVersionCIA: [],
      baseVersionInfo: {
        qbServer: '',
        path: '',
        cl: '',
        qbServerList: [],
        pathList: [],
        clList: []
      },
    })
  };
  clearDataTargetVersion = () => {
    SearchCIA.baseVersionId = '';
    SearchCIA.baseCL = '';
    SearchCIA.basePath = '';
    SearchCIA.baseServer = '';
    this.setState({
      targetVersionCIATitle: 'Enter Version',
      listTargetVersionCIA: [],
      targetVersionInfo: {
        qbServer: '',
        path: '',
        cl: '',
        qbServerList: [],
        pathList: [],
        clList: []
      }
    })
  };

  handleClickItemDropdown = (item, idDropdown) => {
    this.clearDropDownFunc(idDropdown);
    if (idDropdown === 'cia-type') {
      this.setState({
        TypeCIATitle: item.title,
      });
      SearchCIA.type = item.value;
    }
  };

  handleClickModuleItem = (item) => {
    SearchCIA.moduleName = item;
    this.clearDataBaseVersion();
    this.clearDataTargetVersion();
    this.getVersionByModule();
  };

  handleSelectVersion = (item) => {
    this.clearDataTargetVersion();
    this.setState({
      BaseVersionCIATitle: item.title,
    });
    SearchCIA.baseVersionId = item.value;
    SearchCIA.baseCL = this.state.baseVersionInfo.clList[item.index].title;
    SearchCIA.basePath = this.state.baseVersionInfo.pathList[item.index].title;
    SearchCIA.baseServer = this.state.baseVersionInfo.qbServerList[item.index].title;
    item.cl = this.state.baseVersionInfo.clList[item.index].title;
    item.path = this.state.baseVersionInfo.pathList[item.index].title;
    item.qbServer = this.state.baseVersionInfo.qbServerList[item.index].title;
    this.setVersionInfo(item, 'base');
    this.getTargetVersion();
  };

  handleSelectTargetVersionItem = (item) => {
    this.setState({
      targetVersionCIATitle: item.title,
    });
    SearchCIA.targetVersionId = item.value;
    SearchCIA.targetCL = item.cl;
    SearchCIA.targetPath = item.path;
    SearchCIA.targetServer = item.qbServer;
    this.setVersionInfo(item, 'target');
  };

  setLable = (codetypeList, qbserverList, qbidList, pathList, clList) => {
    let baseVersion = {};
    baseVersion.qbServerList = qbserverList;
    baseVersion.pathList = pathList;
    baseVersion.clList = clList;
    this.setState({
      baseVersionInfo: baseVersion
    });
  };

  getTypeByModel = () => {
    let Data = {
      modelId: SearchCIA.appModelId,
    };
    this.props.showProgress();
    commonService.getTypeByModel(Data, (res) => {
      this.props.hideProgress();
      let DropdownList = [];
      for (let i = 0; i < res.data.length; i++) {
        let DropdownItem = { title: res.data[i], value: res.data[i] };
        DropdownList.push(DropdownItem);
      }
      this.setState({
        listTypeCIA: DropdownList
      })
    }, (error) => {
      this.props.hideProgress();
    })
  };

  getVersionByModule = (codetypeList, qbserverList, qbidList, pathList, clList) => {
    let Data = {
      moduleName: SearchCIA.moduleName,
    };
    this.props.showProgress();
    commonService.getVersionByModule(Data, (res) => {
      this.props.hideProgress();
      let versionList = [];
      for (let i = 0; i < res.data.value.list.length; i++) {
        let versionItem = {
          title: res.data.value.list[i].version,
          value: res.data.value.list[i].id,
          codeType: res.data.value.list[i].codeType,
          qbServer: res.data.value.list[i].qbServer,
          qbId: res.data.value.list[i].qbId,
          path: res.data.value.list[i].path,
          cl: res.data.value.list[i].cl
        };
        versionList.push(versionItem);
      }
      this.setState({
        listBaseVersionCIA: versionList
      })
    }, (error) => {
      this.props.hideProgress();
    })
  };

  getTargetVersion = () => {
    let versionList = [];
    for (let i = 0; i < this.state.listBaseVersionCIA.length; i++) {
      if (this.state.listBaseVersionCIA[i].value !== SearchCIA.baseVersionId) {
        versionList.push(this.state.listBaseVersionCIA[i]);
      }
    }
    this.setState({
      listTargetVersionCIA: versionList
    })
  };

  setVersionInfo = (versionInfo, type) => {
    if (type === 'base') {
      this.setState({
        baseVersionInfo: versionInfo
      })
    } else {
      this.setState({
        targetVersionInfo: versionInfo
      })
    }
  };

  createCodeDiff = () => {
    this.setState({
      currentCodeDiffPage: 1
    });
    this.props.showProgress();
    codeDiffService.createCodeDiff(SearchCIA, (res) => {
      this.props.hideProgress();
      this.getAllCodeDiff();
    }, (error) => {
      this.props.hideProgress();
    })
  };

  handleChangeCodeDiffPage = (pageNumber) => {
    this.setState({
      currentCodeDiffPage: pageNumber
    });
    let data = {
      pageNum: null
    };
    data.pageNum = pageNumber - 1;
    this.getAllCodeDiff(data);
  };

  getAllCodeDiff = (data) => {
    clearTimeout(this.timeOut);
    this.props.showProgress();
    codeDiffService.getAllCodeDiff(data, (res) => {
      this.props.hideProgress();
      let page = 0;
      if (data != 'undefined' && data != null) {
        page = data.pageNum;
      }
      this.setState({
        codeDiffTable: { list: res.data.list, pageNum: page },
        totalCount: res.data.totalCount,
        TotalCodeDiffPage: Math.ceil(res.data.totalCount / 10) !== 0 ? Math.ceil(res.data.totalCount / 10) : 1
      });

      let checkLoad;
      for (let i = 0; i < res.data.list.length; i++) {
        checkLoad = false;
        if (res.data.list[i].reportFile == null || res.data.list[i].reportFile == 'undefined') {
          checkLoad = true;
          break;
        }
      }
      if (checkLoad) {
        this.timeOut = setTimeout(this.getAllCodeDiffRunning, 4000);
      }
    }, () => {
      this.props.hideProgress();
    })
  };
  getAllCodeDiffRunning = (data) => {

    codeDiffService.getAllCodeDiff(data, (res) => {
      let page = 0;
      if (data != 'undefined' && data != null) {
        page = data.pageNum;
      }
      this.setState({
        codeDiffTable: { list: res.data.list, pageNum: page },
        TotalCodeDiffPage: Math.ceil(res.data.totalCount / 10) !== 0 ? Math.ceil(res.data.totalCount / 10) : 1
      });

      let checkLoad;
      for (let i = 0; i < res.data.list.length; i++) {
        checkLoad = false;
        if (res.data.list[i].reportFile == null || res.data.list[i].reportFile == 'undefined') {
          checkLoad = true;
          break;
        }
      }
      if (checkLoad) {
        this.timeOut = setTimeout(this.getAllCodeDiffRunning, 4000);
      }
    }, () => {
    })
  };

  pickModel = (item) => {
    this.clearDropDownFunc('cia-model');
    SearchCIA.appModelId = item.value;
    this.getTypeByModel()
  };

  clearModuleList = () => {
    this.clearDataType();
    this.clearDataModule();
    this.child.getAllListModule()
  };

  render() {
    return (
      <div>
        <ProgressModal />
        <Header />
        <div className="content">
          <div className="content-title">
            <div className="content-title-text cia-title">Code Diff</div>
            <div className="content-title-square"></div>
          </div>

          <div className="content-body">
            <div className="module-info module-info-codediff">
              <div className="module-info-title info-title-codediff "><span className="cia-title-small">Module Info</span>
              </div>
              <div className="row module-info-codediff-title">
                <div className="col-lg-3 "><span className=" cia-label">Model</span>
                  <div className="">
                    <PickModelListComponent
                      clearModuleList={this.clearModuleList}
                      pickModel={this.pickModel}/>
                  </div>
                </div>

                <div className="col-lg-3 "><span className=" cia-label">Type</span>
                  <ComponentDropdown title={this.state.TypeCIATitle} iddropdown="cia-type"
                    handleClickItemDropdown={this.handleClickItemDropdown}
                    className="" listSearchStatus={this.state.listTypeCIA} />
                </div>
                <div className="col-lg-3 "><span className=" cia-label">Module Name</span>
                  <div className="">
                    <PickModuleListComponent
                      onRef={instance => { this.child  = instance; }}
                      pickModule={this.handleClickModuleItem}
                      modelId={SearchCIA.appModelId}
                      type={SearchCIA.type}/>
                  </div>
                </div>
              </div>
              <div className="row label-diffcode info-content-codediff">
                <div className=" col-lg-3 medium-codediff"><span className=""></span></div>
                <div className=" col-lg-3 medium-codediff"><span className="">Version</span></div>
                <div className=" col-lg-3 medium-codediff"><span>Server</span></div>
                <div className=" col-lg-3 medium-codediff"><span>Path</span></div>
                <div className=" col-lg-3 medium-codediff"><span>CL/Commit</span></div>
              </div>
              <div className="row module-info-content info-content-codediff medium-codediff">
                <div className="medium-codediff col-lg-3">
                  <span className="span-version">Base Code</span>
                </div>
                <div className="medium-codediff col-lg-3">
                  <VersionComponent pickVersion={this.handleSelectVersion}
                    title=""
                    modelId={SearchCIA.appModelId}
                    moduleName={SearchCIA.moduleName}
                    type={SearchCIA.type}
                    isSetLable={true}
                    setLable={this.setLable}
                    versionTitle={this.state.BaseVersionCIATitle} />
                </div>
                <div className="col-lg-3 medium-codediff">
                  <input type="text" className="input-codediff cia-text"
                    value={this.state.baseVersionInfo.qbServer}></input>
                </div>
                <div className="col-lg-3 medium-codediff">
                  <input type="text" className="input-codediff cia-text"
                    value={this.state.baseVersionInfo.path}></input>
                </div>
                <div className="col-lg-3 medium-codediff">
                  <input type="text" className="input-codediff cia-text"
                    value={this.state.baseVersionInfo.cl}></input>
                </div>
              </div>

              <div className="row module-info-content info-content-codediff">
                <div className="medium-codediff col-lg-3">
                  <span className="span-version">Target Code</span>
                </div>
                <div className="medium-codediff col-lg-3">
                  <TargetVersionComponent pickVersion={this.handleSelectTargetVersionItem}
                    title=""
                    versionId={SearchCIA.baseVersionId}
                    targetVersionList={this.state.listTargetVersionCIA}
                    versionTitle={this.state.targetVersionCIATitle} />
                </div>
                <div className="col-lg-3 medium-codediff">
                  <input type="text" className="input-codediff cia-text"
                    value={this.state.targetVersionInfo.qbServer}></input>
                </div>
                <div className=" col-lg-3 medium-codediff">
                  <input type="text" className="input-codediff cia-text"
                    value={this.state.targetVersionInfo.path}></input>
                </div>
                <div className=" col-lg-3 medium-codediff">
                  <input type="text" className="input-codediff cia-text"
                    value={this.state.targetVersionInfo.cl}></input>
                </div>
              </div>
            </div>
          </div>

          <div className="border-compare border-check-build">
            <button className="btn-check-build btn btn-primary" onClick={this.createCodeDiff}> Compare</button>
          </div>

          <div className="border-latest-comparision border-latest-build"><span className="cia-title">Module Info</span>
          </div>
          <div className="content-table table-codediff">
            <CodeDiffTable tableData={this.state.codeDiffTable} />
          </div>
          <div className="pagination-body">
            {this.state.codeDiffTable && this.state.codeDiffTable.list.length > 0 &&
              <ComponentPagination
                totalCount={this.state.totalCount}
                pageNum={this.state.codeDiffTable.pageNum}
                currentPage={this.state.currentCodeDiffPage}
                totalPages={this.state.TotalCodeDiffPage}
                onChange={this.handleChangeCodeDiffPage}
              />
            }
          </div>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return {
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    }
  };
};


export default connect(null, mapDispatchToProps)(CodeDiff);