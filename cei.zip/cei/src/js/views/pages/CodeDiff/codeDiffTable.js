import React from 'react';
import { connect } from "react-redux";
import { push } from "redux-router";
import '../../../../public/styles/pages/CodiffTable.scss';
import Ic_Running from '../../../../public/images/ic_loading.gif';
class CodeDiffTable extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>
        {this.props.tableData && this.props.tableData.list.length > 0 &&
          <table className="table table-striped table-codediff">
            <tr>
              <th className="td-model">Model</th>
              <th className="td-server">Server</th>
              <th className="td-modulename">Module Name</th>
              <th className="td-base">Base Version</th>
              <th className="td-target">Target Version</th>
              <th className="td-report">Report</th>
            </tr>
            {this.props.tableData.list.map((data, idx) => {
              return <tr key={idx}>
                <td>{data.modelName}</td>
                <td>{data.baseServer}</td>
                <td>{data.moduleName}</td>
                <td>{data.baseVersionName}</td>
                <td>{data.targetVersionName}</td>
                <td>
                   {data.reportFile && data.reportFile.name}
                   {!data.reportFile &&  <img src={Ic_Running} alt="Processing" className="running-img" />}
                   {!data.reportFile && <span>  Running</span>}
                </td>
              </tr>;
            })}
          </table>
        }
      </div>
    );
  }
}

export default CodeDiffTable;