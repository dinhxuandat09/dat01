import React from 'react';
import { connect } from "react-redux";
import { push } from "redux-router";
import '../../../../public/styles/commons/share/body.scss';
import '../../../../public/styles/pages/UploadTestLog.scss';
import Header from '../../components/share/header';
import { loadToolFunc, reloadToolPage } from "../../../actions/share";
import { showProgress, hideProgress, actionModal } from "../../../actions/share";
import ProgressModal from '../../components/progressModal/ProgressModal';
import { DropdownButton, MenuItem, Button } from 'react-bootstrap';
import * as UploadTestLogService from '../../../service/UploadTestLogService';
import * as commonService from '../../../service/commonService';
import PickModelListComponent from '../../components/pickModelListComponent/pickModelListComponent';
import PickModuleListComponent from '../../components/pickModelListComponent/pickModuleListComponent';
import Ic_Delete from '../../../../public/images/icons/ic_delete1.png';
import Ic_UploadLog from '../../../../public/images/icons/ic_upload.png';
import { showAlert } from "../../../actions/share";
import ModuleComponent from '../../components/moduleInfoComponent/moduleComponent';
import VersionComponent from '../../components/moduleInfoComponent/versionComponent';
import ComponentPagination from '../../components/ComponentPagination';
let uploadTestLogParams = {};
class UploadTestLog extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      typeList: [],
      versionList: [],
      tcSuitList: [],
      dropdownType: "Select type",
      dropdownVersion: "Select version",
      dropdownTCSuit: "Select TC suit",
      listTestLog: [],
      currentPage: 1,
      totalPage: 1,
      disabledConfirmBtn: true,
      totalCount: 0
    };
  }
  componentWillMount() {
    this.getAllUploadTestLog();
    this.setState({ disabledConfirmBtn: true });
    uploadTestLogParams.pageNum = 0;
  };
  checkButtonConfirm = () => {
    if (this.state.dropdownType != 'Select type') {
      this.setState({ disabledConfirmBtn: false });
    }
  };
  handleSelectModel = (item) => {
    uploadTestLogParams.modelId = item.value;
    this.clearDataType();
    this.clearDataModule();
    this.clearDataVersion();
    this.clearDataTCSuit();
    this.getType();
  };
  handleSelectType = (item) => () => {
    this.setState({
      dropdownType: item.title,
    });
    uploadTestLogParams.typeId = item.value;
    this.clearDataModule();
    this.clearDataVersion();
    this.clearDataTCSuit();
  };
  handleSelectModule = (item) => {
    uploadTestLogParams.moduleName = item;
    this.clearDataVersion();
    this.clearDataTCSuit();
    this.getVersion();
    this.checkButtonConfirm();
  };
  handleSelectVersion = (item) => {
    this.setState({
      dropdownVersion: item.title
    });
    uploadTestLogParams.versionId = item.value;
    this.clearDataTCSuit();
    this.getTcSuit();
  };
  handleSelectTCBuilt = (item) => () => {
    this.setState({
      dropdownTCSuit: item.title
    });
    uploadTestLogParams.tcId = item.value
  };

  clearDataType = () => {
    this.setState({
      dropdownType: "Select type",
      typeList: []
    });
    uploadTestLogParams.typeId = null;
  };

  clearDataModule = () => {
    uploadTestLogParams.moduleName = null;
  };

  clearDataVersion = () => {
    this.setState({
      dropdownVersion: "Select version"
    });
    uploadTestLogParams.versionId = null;
  };
  clearDataTCSuit = () => {
    this.setState({
      dropdownTCSuit: "Select TC suit",
      tcSuitList: []
    });
    uploadTestLogParams.tcId = null;
  };
  handleConfirm = () => {
    this.getAllUploadTestLog();
  };
  handleUploadFile = () => {
    document.getElementById('upload-test-log').click();
  };
  onUpload = () => {
    let file = document.getElementById('upload-test-log').files;
    let filteredFile = Array.prototype.filter.call(file, fi => {
      if (fi.name.includes('.zip')) {
        return fi;
      }
    });
    if (filteredFile && filteredFile.length > 0) {
      let form = new FormData();
      form.append("file", filteredFile[0], filteredFile[0].name);
      let data = {};
      data.file = form;
      data.modelId = uploadTestLogParams.modelId;
      data.moduleName = uploadTestLogParams.moduleName;
      data.testSuitId = uploadTestLogParams.tcId;
      data.versionId = uploadTestLogParams.versionId;
      if (!data.moduleName || !data.versionId || !uploadTestLogParams.tcId) {
        this.props.showAlert("Please select all fields Module Name, Version, TC Suit!");
        document.getElementById('upload-test-log').value = null;
        return;
      }
      this.props.showProgress();
      UploadTestLogService.uploadMultiTestLogs(data, (response) => {
        this.props.hideProgress();
        this.props.showAlert("Uploaded successfully");
        this.getAllUploadTestLog();
      }, (error) => {
        this.props.hideProgress();
        this.props.showAlert("Upload fail");
      });
    }

    document.getElementById('upload-test-log').value = null;
  };

  handleUploadSingleLog = () => {
    document.getElementById('upload-single-test-log').click();
  };

  onUploadLog = () => {
    let file = document.getElementById('upload-single-test-log').files;
    let filteredFile = Array.prototype.filter.call(file, fi => {
      if (fi.name.includes('.txt')) {
        return fi;
      }
    });
    if (filteredFile && filteredFile.length > 0) {
      let form = new FormData();
      form.append("file", filteredFile[0], filteredFile[0].name);
      let data = {};
      data.file = form;
      data.modelId = uploadTestLogParams.modelId;
      data.moduleName = uploadTestLogParams.moduleName;
      data.versionId = uploadTestLogParams.versionId;
      data.testSuitId = uploadTestLogParams.tcId;
      data.versionId = uploadTestLogParams.versionId;
      if (!data.moduleName || !data.versionId || !uploadTestLogParams.tcId) {
        this.props.showAlert("Please select all fields Module Name, Version, TC Suit!");
        document.getElementById('upload-single-test-log').value = null;
        return;
      }
      this.props.showProgress();
      UploadTestLogService.uploadTestLog(data, (response) => {
        this.props.hideProgress();
        this.props.showAlert("Uploaded successfully");
        this.getAllUploadTestLog();
      }, (error) => {
        this.props.hideProgress();
        this.props.showAlert("Upload fail");
      });
    }
    document.getElementById('upload-single-test-log').value = null;
  };

  handleDeleteLog = (id) => () => {
    this.props.showProgress();
    UploadTestLogService.deleteLog(id, (response) => {
      this.props.hideProgress();
      this.props.showAlert("Deleted successfully");
      this.getAllUploadTestLog();
    }, (error) => {
      this.props.hideProgress();
      this.props.showAlert("Delete fail");
    });
  };

  getAllUploadTestLog = () => {
    let data = {
      pageSize: 10,
      modelId: uploadTestLogParams.modelId,
      moduleName: uploadTestLogParams.moduleName,
      versionId: uploadTestLogParams.versionId,
      testSuitId: uploadTestLogParams.tcId,
      pageNum: uploadTestLogParams.pageNum
    };
    this.props.showProgress();
    UploadTestLogService.getUploadTestLog(data, (response) => {
      this.setState({
        listTestLog: response.data.list,
        totalCount: response.data.totalCount,
        totalPage: Math.ceil(response.data.totalCount / 10) !== 0 ? Math.ceil(response.data.totalCount / 10) : 1
      });
      this.props.hideProgress();
    }, (error) => {
      this.props.hideProgress();
    });
  };

  handleChangePage = (pageNumber) => {
    uploadTestLogParams.pageNum = pageNumber - 1;
    this.setState({
      currentPage: pageNumber
    });
    this.getAllUploadTestLog();
  };

  getType = () => {
    let data = {
      modelId: uploadTestLogParams.modelId
    };
    commonService.getTypeByModel(data, (res) => {
      let DropdownList = [];
      for (let i = 0; i < res.data.length; i++) {
        let DropdownItem = { title: res.data[i], value: res.data[i] };
        DropdownList.push(DropdownItem);
      }
      this.setState({
        typeList: DropdownList
      })
    }, (error) => {

    })
  };

  getVersion = () => {
    let data = {
      moduleName: uploadTestLogParams.moduleName
    };
    commonService.getVersionByModule(data, (res) => {
      let DropdownList = [];
      for (let i = 0; i < res.data.value.list.length; i++) {
        let DropdownItem = { title: res.data.value.list[i].version, value: res.data.value.list[i].id };
        DropdownList.push(DropdownItem);
      }
      this.setState({
        versionList: DropdownList
      })
    }, (error) => {

    })
  };

  getTcSuit = () => {
    let data = {
      modelId: uploadTestLogParams.modelId,
      moduleName: uploadTestLogParams.moduleName
    };
    commonService.getTcSuitByModel(data, (res) => {
      let DropdownList = [];
      for (let i = 0; i < res.data.list.length; i++) {
        let DropdownItem = { title: res.data.list[i].name, value: res.data.list[i].id };
        DropdownList.push(DropdownItem);
      }
      this.setState({
        tcSuitList: DropdownList
      })
    }, (error) => {

    });
  };

  clearModuleList = () => {
    this.clearDataType();
    this.clearDataModule();
    this.child.getAllListModule()
  };

  render() {
    return (
      <div>
        <ProgressModal />
        <Header />
        <div className="content">
          <div className="upload-test-log-wrapper">

            <div className="content-title">
              <div className="content-title-text">Upload Test Log</div>
              <div className="content-title-square"></div>
            </div>
            <div className="upload-test-log-content">
              <div className="module-info">
                <div className="cia-title-small">Module Info</div>
                <div className="upload-form row">
                  <div className=" medium col-lg-4">

                    <span className="cia-label ">Model</span>
                    <div className="">
                      <PickModelListComponent
                        clearModuleList={this.clearModuleList}
                        pickModel={this.handleSelectModel}/>
                      </div>
                    </div>
                    <div className="small  col-lg-4">
                      <span className="cia-label ">Type</span>
                      <div className="">
                        <DropdownButton title={this.state.dropdownType} id="dropdown-log-type">
                          {
                            this.state.typeList.map((item, index) => {
                              return <MenuItem key={index} className="dropdown-item"
                                               onClick={this.handleSelectType(item)}>{item.title}</MenuItem>
                            })
                          }
                        </DropdownButton>
                      </div>
                    </div>
                  <div className="medium col-lg-3 module-info-component-wrapper">
                    <span className=" cia-label">Module Name</span>
                    <div className="">
                      <PickModuleListComponent
                        onRef={instance => { this.child  = instance; }}
                        pickModule={this.handleSelectModule}
                        modelId={uploadTestLogParams.modelId}
                        type={uploadTestLogParams.typeId}/>
                    </div>
                  </div>
                  <VersionComponent pickVersion={this.handleSelectVersion}
                    title="Version"
                    modelId={uploadTestLogParams.modelId}
                    moduleName={uploadTestLogParams.moduleName}
                    type={uploadTestLogParams.typeId}
                    isSetLable={false}
                    versionTitle={this.state.dropdownVersion} />
                  <div className="medium  col-lg-4">
                    <span className="cia-label ">TC Suit</span>
                    <div className=" padding-0">
                      <DropdownButton title={this.state.dropdownTCSuit} id="dropdown-log-built"
                        className="model-dropdown">
                        {
                          this.state.tcSuitList.map((item, index) => {
                            return <MenuItem key={index} className="dropdown-item"
                              onClick={this.handleSelectTCBuilt(item)}>{item.title}</MenuItem>
                          })
                        }
                      </DropdownButton>
                    </div>
                  </div>
                  <button disabled={this.state.disabledConfirmBtn} onClick={this.handleConfirm} className="btn btn-primary btn-confirm">Confirm</button>
                </div>

              </div>
              <br />
              <div hidden>
                <input type="file" id="upload-test-log" onChange={this.onUpload} accept=".zip" />
              </div>
              <button onClick={this.handleUploadFile} className="btn btn-primary btn-upload">Upload Zip File for Test
                  Log
                </button>
              <br />
              <div className="file-list">
                <div className="cia-title">Test Log File List</div>
                <hr />
                <div className="table-up-load-test">
                  {this.state.listTestLog && this.state.listTestLog.length > 0 &&
                    <table className="table table-striped">
                      <tbody>
                        <tr>
                          <th className="td-id">TC ID</th>
                          <th className="td-name">TC Name</th>
                          <th className="td-creator">Creator</th>
                          <th className="td-date">Date</th>
                          <th className="td-file">TC Files</th>

                        </tr>
                        {this.state.listTestLog.map((data, idx) => {
                          return <tr key={idx}>
                            <td>{data.tcId}</td>
                            <td>{data.name}</td>
                            <td>{data.createBy}</td>
                            <td>{data.date}</td>
                            {data.fileLog && data.fileLog.name && <td className="tc-file">
                              {data.fileLog.name}
                              <img className="delete-tc-file-icon" src={Ic_Delete} alt="Delete icon"
                                onClick={() => this.props.actionModal('Delete File', 'Are you sure?', true, this.handleDeleteLog(data.fileLog.id), () => { })} />
                            </td>}
                            {!data.fileLog && <td className="tc-file">
                              <span>No log</span>
                              <img className="delete-tc-file-icon" src={Ic_UploadLog} alt="upload icon"
                                onClick={this.handleUploadSingleLog} />
                              <div hidden>
                                <input type="file" id="upload-single-test-log" onChange={this.onUploadLog} accept=".txt" />
                              </div>
                            </td>}
                          </tr>;
                        })}
                      </tbody>
                    </table>
                  }
                </div>
              </div>
            </div>
          </div>
          <div className="pagination-body">
            {this.state.listTestLog && this.state.listTestLog.length > 0 &&
              <ComponentPagination
                totalCount={this.state.totalCount}
                pageNum={uploadTestLogParams.pageNum}
                currentPage={this.state.currentPage}
                totalPages={this.state.totalPage}
                onChange={this.handleChangePage}
              />}
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  listCategory: state.application.share.listCategory,
  setSearchText: state.application.share.functionSetSearchText,
  isShowProgress: state.application.share.progressModal.isShow
});


const mapDispatchToProps = dispatch => {
  return {
    actionModal: (title, message, isShow, successCallBack, failCallBack) => {
      dispatch(actionModal(title, message, isShow, successCallBack, failCallBack));
    },
    redirectPage: url => {
      dispatch(push(url));
    },
    setLoadToolFunc: (func) => {
      dispatch(loadToolFunc(func));
    },
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    },
    reloadToolPage: (func) => {
      dispatch(reloadToolPage(func));
    },
    showAlert: (permissions) => {
      dispatch(showAlert(permissions));
    }
  };
};


export default connect(mapStateToProps, mapDispatchToProps)(UploadTestLog);
