import React from 'react';
import {connect} from "react-redux";
import {push} from "redux-router";
import ProgressModal from '../../components/progressModal/ProgressModal';
import Header from '../../components/share/header';
import ComponentDropdown from '../../components/ComponentDropdown';
import {getSearchResult} from '../../../service/searchService';
import '../../../../public/styles/pages/searchPage.scss';
import UltimatePagination from "react-ultimate-pagination-bootstrap-4";

const list_sort_type = [
  {title: 'All', value: 'all'},
  {title: 'Model', value: 'model'},
  {title: 'Type', value: 'type'},
  {title: 'Base Version', value: 'baseVersion'},
  {title: 'Target Version', value: 'targetVersion'}
]
class SearchResultPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      sortType: list_sort_type[0],
      searchResult: [],
      currentTCPage: 1,
      TotalTCPage: 0
    }
  }

  componentWillMount() {
    this.getResultData(this.props.params.searchKey, 0, this.state.sortType.value);
  }

  componentWillUpdate(nextProps, nextState) {
    if (nextProps.params.searchKey !== this.props.params.searchKey) {
      this.getResultData(nextProps.params.searchKey, 0, list_sort_type[0].value);
      this.setState({
        sortType: list_sort_type[0],
        currentTCPage: 1
      });
    }
  }

  handleSelectSortType = (item, idDropdown) => {
    this.setState({
      sortType: item,
      currentTCPage: 1
    });
    this.getResultData(this.props.params.searchKey, 0, item.value)
  }

  getResultData = (key, pageNum, sortType) => {
    let data = {
      pageNum: pageNum,
      query: key,
      orderBy: 'ascending',
      sortBy: sortType
    };
    getSearchResult(data, (response) => {
      this.setState({
        searchResult: response.data.value.list,
        TotalTCPage: Math.ceil(response.data.value.totalCount / 10) !== 0 ? Math.ceil(response.data.value.totalCount / 10) : 1
      });
    }, (error) => {
    });
  }
  handleChangeTCPage = (pageNumber) => {
    this.setState({
      currentTCPage: pageNumber
    });
    this.getResultData(this.props.params.searchKey, pageNumber-1, this.state.sortType.value)
  };
  _onToogleShowDetailSearchResult = (item) => e => {
    const linkPageCiaReportDetail = `#/CIAReport?${item.model},${item.type},${item.module},${item.baseVersion},${item.targetVersion},${item.id}`
    window.open(linkPageCiaReportDetail);
  }
  render() {
    return (
      <div>
        <ProgressModal />
        <Header />
        <div className="search-content">
          <div className="2 col-lg-12">
            <ComponentDropdown title={this.state.sortType.title}
                               iddropdown="searchSortDropDown"
                               className="right sort-in-search  col-lg-2"
                               listSearchStatus={list_sort_type}
                               handleClickItemDropdown={this.handleSelectSortType}
            />
            <span className="right cia-label">Filter by</span>
          </div>
          <div>
            {this.state.searchResult && this.state.searchResult.length > 0 ?
              <div className="table-wrapper">
                <table className="table table-striped">
                  <tr className="table-header">
                    <th className="text-center">No</th>
                    <th className="text-center">Model</th>
                    <th className="text-center">Type</th>
                    <th className="text-center">Module Name</th>
                    <th className="text-center">Base Version</th>
                    <th className="text-center">Target Version</th>
                  </tr>
                  {this.state.searchResult.map((data, idx) => {
                    return <tr key={idx}>
                      <td className="text-center">{idx}</td>
                      <td className="padding-15 name-model" onClick={this._onToogleShowDetailSearchResult(data)}>{data.model}</td>
                      <td className="padding-15">{data.type}</td>
                      <td className="padding-15">{data.module}</td>
                      <td className="padding-15">{data.baseVersion}</td>
                      <td className="padding-15">{data.targetVersion}</td>
                    </tr>;
                  })}
                </table>
              </div>
              : <div className="text-center">No result</div>
            }

          </div>
          <div className="pagination-body">
            {this.state.searchResult && this.state.searchResult.length > 0 &&
            <UltimatePagination
              currentPage={this.state.currentTCPage}
              totalPages={this.state.TotalTCPage}
              onChange={this.handleChangeTCPage}
            />
            }
          </div>
        </div>

      </div>
    )
  }
}

export default SearchResultPage;
