import React from 'react';
import {connect} from "react-redux";
import {push} from "redux-router";
import '../../../../public/styles/pages/CIAReportTCTable.scss';

class CIAReportTCTable extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      this.props.tableData && this.props.tableData.list.length > 0 &&
        <table className="table table-striped">
          <tr className="table-header">
          <th className=" td-no">No</th>
          <th className=" td-model">Model</th>
          <th className=" td-module">Module Name</th>
          <th className=" td-base">Base Version</th>
          <th className=" td-target">Target Version</th>
          <th className=" td-id">TC ID</th>
          </tr>
          {this.props.tableData.list.map((data, idx) => {
            return <tr key={idx}>
              <td className="text-center">{idx + this.props.tableData.pageNum*10 + 1}</td>
              <td>{data.model}</td>
              <td>{data.module}</td>
              <td>{data.baseVersion}</td>
              <td>{data.targetVersion}</td>
              <td>{data.tcId}</td>
            </tr>;
          })}
        </table>
    );
  }
}

export default CIAReportTCTable;