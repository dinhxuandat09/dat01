import React from 'react';
import Header from '../../components/share/header';
import '../../../../public/styles/pages/CIAReport.scss';
import {Tabs, Tab} from 'react-bootstrap';
import * as commonService from '../../../service/commonService';
import * as CIAService from '../../../service/CIAReport/CIAReport';
import ComponentDropdown from '../../components/ComponentDropdown';
import ConfirmModal from '../../components/confirmModal/confirmModal';
import CIAReportMethodTable from './CIAReportMethodTable';
import CIAReportTCTable from './CIAReportTCTable';
import PickModelListComponent from '../../components/pickModelListComponent/pickModelListComponent';
import UltimatePagination from "react-ultimate-pagination-bootstrap-4";
import ExportAll from '../../../../public/images/icons/ic_excel-all.png';
import {actionModal} from "../../../actions/share";
import {connect} from "react-redux";
import {showProgress, hideProgress} from '../../../actions/share';
import {push} from "redux-router";
import ModuleComponent from '../../components/moduleInfoComponent/moduleComponent';
import VersionComponent from '../../components/moduleInfoComponent/versionComponent';
import TargetVersionComponent from '../../components/moduleInfoComponent/targetVersionComponent';

let SearchCIAReport = {};
let CIAReportMethodData = {};
let CIAReportTCData = {};
let reportId = null;

class CIAReport extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      modelCIAReportTitle: 'Enter Model',
      listModelCIAReport: [],
      TypeCIAReportTitle: 'Enter Type',
      listTypeCIAReport: [],
      ModuleCIAReportTitle: 'Enter Module Name',
      listModuleCIAReport: [],
      BaseVersionCIAReportTitle: 'Enter Version',
      listBaseVersionCIAReport: [],
      targetVersionCIAReportTitle: 'Enter Version',
      listTargetVersionCIAReport: [],
      MethodReport: {
        list: [],
        pageNum: ''
      },
      TCReport: {
        list: [], pageNum: '',
      },
      TotalMethodPage: 1,
      currentMethodPage: 1,
      TotalTCPage: 1,
      currentTCPage: 1,
      tcTabIndex: 1,
      isShowDetailSearchResult: false
    };
    if (this.props.location.search) {
      const searchParam = this.props.location.search.split("?");
      const listModuleInfo = searchParam[1].split(",")
      this.state = {
        ...this.state,
        modelCIAReportTitle: listModuleInfo[0],
        TypeCIAReportTitle: listModuleInfo[1],
        ModuleCIAReportTitle: listModuleInfo[2],
        BaseVersionCIAReportTitle: listModuleInfo[3],
        targetVersionCIAReportTitle: listModuleInfo[4],
        isShowDetailSearchResult: true
      };
      reportId = listModuleInfo[5]
    }
  }

  componentWillMount() {
    this.props.showProgress();
    commonService.getModel(null, (res) => {
      this.props.hideProgress();
      this.setState({
        listModelCIAReport: res.data.value.list
      })
    }, (error) => {
      this.props.hideProgress();
    });
  };

  componentDidMount() {
    this.onClickTab();
    document.getElementById("cia-report-tc-tabs-tab-1")
      .setAttribute("style", "border-top: 1px solid #3899ec;border-right: 1px solid #3899ec;border-left: 1px solid #3899ec");
  };

  clearDropDownFunc = (idDropdown) => {
    if (idDropdown === 'cia-model') {
      this.clearDataType();
      this.clearDataModule();
      this.clearDataBaseVersion();
      this.clearDataTargetVersion()
    }
    if (idDropdown === 'cia-type') {
      this.clearDataModule();
      this.clearDataBaseVersion();
      this.clearDataTargetVersion()
    }
  };

  clearDataType = () => {
    this.setState({
      TypeCIAReportTitle: 'Enter Type',
      listTypeCIAReport: [],
    })
  };

  clearDataModule = () => {
    this.setState({
      ModuleCIAReportTitle: 'Enter Module Name',
      listModuleCIAReport: [],
    })
  };
  clearDataBaseVersion = () => {
    this.setState({
      BaseVersionCIAReportTitle: 'Enter Version',
      listBaseVersionCIAReport: [],
    })
  };
  clearDataTargetVersion = () => {
    this.setState({
      targetVersionCIAReportTitle: 'Enter Version',
      listTargetVersionCIAReport: [],
    })
  };

  pickModel = (item) => {
    this.clearDropDownFunc('cia-model');
    this.setState({
      modelCIAReportTitle: item.title,
    });
    SearchCIAReport.modelId = item.value;
    this.getTypeByModel()
  };

  handleClickItemDropdown = (item, idDropdown) => {
    this.clearDropDownFunc(idDropdown);
    if (idDropdown === 'cia-type') {
      this.setState({
        TypeCIAReportTitle: item.title,
      });
      SearchCIAReport.type = item.value;
      this.getListModuleByModel();
    }
  };

  handleClickModuleItem = (item) => {
    this.clearDataBaseVersion();
    this.clearDataTargetVersion();
    this.setState({
      ModuleCIAReportTitle: item.title,
    });
    SearchCIAReport.moduleId = item.value;
    this.getVersionByModule();
  };

  handleSelectVersionItem = (item) => {
    this.clearDataTargetVersion();
    this.setState({
      BaseVersionCIAReportTitle: item.title,
    });
    SearchCIAReport.baseVersionId = item.value;
    this.getTargetVersion();
  };

  handleSelectTargetVersionItem = (item) => {
    this.setState({
      targetVersionCIAReportTitle: item.title,
    });
    SearchCIAReport.targetVersionId = item.value;
  };

  getTypeByModel = () => {
    let Data = {
      modelId: SearchCIAReport.modelId,
    };
    this.props.showProgress();
    commonService.getTypeByModel(Data, (res) => {
      this.props.hideProgress();
      let DropdownList = [];
      for (let i = 0; i < res.data.length; i++) {
        let DropdownItem = {title: res.data[i], value: res.data[i]};
        DropdownList.push(DropdownItem);
      }
      this.setState({
        listTypeCIAReport: DropdownList
      })
    }, (error) => {
      this.props.hideProgress();
    })
  };

  getListModuleByModel = () => {
    let Data = {
      modelId: SearchCIAReport.modelId,
      type: SearchCIAReport.type
    };
    this.props.showProgress();
    commonService.getModulesByModel(Data, (res) => {
      this.props.hideProgress();
      let modulesList = [];
      for (let i = 0; i < res.data.value.list.length; i++) {
        let moduleItem = {title: res.data.value.list[i].name, value: res.data.value.list[i].id};
        modulesList.push(moduleItem);
      }
      this.setState({
        listModuleCIAReport: modulesList
      })
    }, (error) => {
      this.props.hideProgress();
    })
  };

  getVersionByModule = () => {
    let Data = {
      moduleId: SearchCIAReport.moduleId,
    };
    this.props.showProgress();
    commonService.getVersionByModule(Data, (res) => {
      this.props.hideProgress();
      let versionList = [];
      for (let i = 0; i < res.data.value.list.length; i++) {
        let varsionItem = {title: res.data.value.list[i].version, value: res.data.value.list[i].id};
        versionList.push(varsionItem);
      }
      this.setState({
        listBaseVersionCIAReport: versionList
      })
    }, (error) => {
      this.props.hideProgress();
    })
  };

  getTargetVersion = () => {
    let versionList = [];
    for (let i = 0; i < this.state.listBaseVersionCIAReport.length; i++) {
      if (this.state.listBaseVersionCIAReport[i].value !== SearchCIAReport.baseVersionId) {
        versionList.push(this.state.listBaseVersionCIAReport[i]);
      }
    }
    this.setState({
      listTargetVersionCIAReport: versionList
    })
  };
  clearStyleTab = () => {
    document.getElementById("cia-report-tc-tabs-tab-1").setAttribute("style", "border:none");
    document.getElementById("cia-report-tc-tabs-tab-2").setAttribute("style", "border:none");
    document.getElementById("cia-report-tc-tabs-tab-3").setAttribute("style", "border:none");
  };

  clearStyleMethodTab = () => {
    document.getElementById("cia-report-method-tabs-tab-1")
      .setAttribute("style", "border-top:none; border-right:none;border-left:none;border-bottom: 1px solid #ddd");
    document.getElementById("cia-report-method-tabs-tab-2")
      .setAttribute("style", "border-top:none; border-right:none;border-left:none;border-bottom: 1px solid #ddd");
    document.getElementById("cia-report-method-tabs-tab-3")
      .setAttribute("style", "border-top:none; border-right:none;border-left:none;border-bottom: 1px solid #ddd");
    document.getElementById("cia-report-method-tabs-tab-4")
      .setAttribute("style", "border-top:none; border-right:none;border-left:none;border-bottom: 1px solid #ddd");
    document.getElementById("cia-report-method-tabs-tab-5")
      .setAttribute("style", "border-top:none; border-right:none;border-left:none;border-bottom: 1px solid #ddd");
  };

  showReport = () => {
    this.props.showProgress();
    if (this.state.isShowDetailSearchResult) {
      this.handleClickTCTab(1);
      this.clearStyleTab();
      document.getElementById("cia-report-tc-tabs-tab-1")
        .setAttribute("style", "border-top: 1px solid #3899ec;border-right: 1px solid #3899ec;border-left: 1px solid #3899ec");
      this.setState({isShowDetailSearchResult: false})
    } else {
      CIAService.getCIAReport(SearchCIAReport, (res) => {
        this.props.hideProgress();
        reportId = res.data;
        this.handleClickTCTab(1);
        this.clearStyleTab();
        document.getElementById("cia-report-tc-tabs-tab-1")
          .setAttribute("style", "border-top: 1px solid #3899ec;border-right: 1px solid #3899ec;border-left: 1px solid #3899ec");
      }, (error) => {
        this.props.hideProgress();
        this.props.actionModal('Message', error.response.data.message, true, () => {
          if (error.response.data.description === '3' || error.response.data.description === "1") {
            this.props.redirectPage('/UploadTestLog');
          }
          if (error.response.data.description === '4' || error.response.data.description === '5') {
            this.props.redirectPage('/CodeDiff');
          }
        }, () => {
        })
      });
    }
  };

  getMethodReport = (data) => {
    this.props.showProgress();
    CIAService.getMethodReport(data, (res) => {
      this.props.hideProgress();
      this.setState({
        MethodReport: {list: res.data.value.list, pageNum: data.pageNum},
        TotalMethodPage: Math.ceil(res.data.value.totalCount / 10) !== 0 ? Math.ceil(res.data.value.totalCount / 10) : 1
      });
    }, () => {
      this.props.hideProgress();
    })
  };

  getTCReport = (data) => {
    this.props.showProgress();
    CIAService.getTCReport(data, (res) => {
      this.props.hideProgress();
      this.setState({
        TCReport: {list: res.data.value.list, pageNum: data.pageNum},
        TotalTCPage: Math.ceil(res.data.value.totalCount / 10) !== 0 ? Math.ceil(res.data.value.totalCount / 10) : 1
      })
    }, () => {
      this.props.hideProgress();
    })
  };

  handleClickMethodTab = (index) => {
    if (reportId) {
      CIAReportMethodData.reportId = reportId;
      CIAReportMethodData.pageNum = 0;
      if (index === 1) {
        CIAReportMethodData.type = 'New'
      }
      if (index === 2) {
        CIAReportMethodData.type = 'Effected'
      }
      if (index === 3) {
        CIAReportMethodData.type = 'Not Effected'
      }
      if (index === 4) {
        CIAReportMethodData.type = 'Remove'
      }
      if (index === 5) {
        CIAReportMethodData.type = 'unchanged'
      }
      this.setState({
        currentMethodPage: 1
      });
      this.getMethodReport(CIAReportMethodData)
    }
    if (index === 1) {
      this.clearStyleMethodTab();
      document.getElementById("cia-report-method-tabs-tab-1")
        .setAttribute("style", "border-top: 1px solid #ddd;border-right: 1px solid #ddd;border-left: 1px solid #ddd;border-bottom: 1px solid #fff");
    }
    if (index === 2) {
      this.clearStyleMethodTab();
      document.getElementById("cia-report-method-tabs-tab-2")
        .setAttribute("style", "border-top: 1px solid #ddd;border-right: 1px solid #ddd;border-left: 1px solid #ddd;border-bottom: 1px solid #fff");
    }
    if (index === 3) {
      this.clearStyleMethodTab();
      document.getElementById("cia-report-method-tabs-tab-3")
        .setAttribute("style", "border-top: 1px solid #ddd;border-right: 1px solid #ddd;border-left: 1px solid #ddd;border-bottom: 1px solid #fff");
    }
    if (index === 4) {
      this.clearStyleMethodTab();
      document.getElementById("cia-report-method-tabs-tab-4")
        .setAttribute("style", "border-top: 1px solid #ddd;border-right: 1px solid #ddd;border-left: 1px solid #ddd;border-bottom: 1px solid #fff");
    }
    if (index === 5) {
      this.clearStyleMethodTab();
      document.getElementById("cia-report-method-tabs-tab-5")
        .setAttribute("style", "border-top: 1px solid #ddd;border-right: 1px solid #ddd;border-left: 1px solid #ddd;border-bottom: 1px solid #fff");
    }
  };

  handleClickTCTab = (index) => {
    if (reportId) {
      CIAReportTCData.reportId = reportId;
      CIAReportTCData.pageNum = 0;
      if (index === 1) {
        CIAReportTCData.typeTc = null
      }
      if (index === 2) {
        CIAReportTCData.typeTc = 'Effected'
      }
      if (index === 3) {
        CIAReportTCData.typeTc = 'Not Effected'
      }
      this.setState({
        currentTCPage: 1
      });
      this.getTCReport(CIAReportTCData)
    }
    if (index === 1) {
      this.handleClickMethodTab(1);
      document.getElementById("cia-report-method-tabs-tab-1").setAttribute("style", "cursor: pointer; opacity: 1");
      document.getElementById("cia-report-method-tabs-tab-2").setAttribute("style", "cursor: not-allowed; opacity: 0.5");
      document.getElementById("cia-report-method-tabs-tab-3").setAttribute("style", "cursor: not-allowed; opacity: 0.5");
      document.getElementById("cia-report-method-tabs-tab-4").setAttribute("style", "cursor: not-allowed; opacity: 0.5");
      document.getElementById("cia-report-method-tabs-tab-5").setAttribute("style", "cursor: not-allowed; opacity: 0.5");
    } else if (index === 2) {
      this.handleClickMethodTab(2);
      document.getElementById("cia-report-method-tabs-tab-1").setAttribute("style", "cursor: not-allowed; opacity: 0.5");
      document.getElementById("cia-report-method-tabs-tab-2").setAttribute("style", "cursor: pointer; opacity: 1");
      document.getElementById("cia-report-method-tabs-tab-3").setAttribute("style", "cursor: pointer; opacity: 1");
      document.getElementById("cia-report-method-tabs-tab-4").setAttribute("style", "cursor: pointer; opacity: 1");
      document.getElementById("cia-report-method-tabs-tab-5").setAttribute("style", "cursor: not-allowed; opacity: 0.5");
    } else {
      this.handleClickMethodTab(5);
      document.getElementById("cia-report-method-tabs-tab-1").setAttribute("style", "cursor: not-allowed; opacity: 0.5");
      document.getElementById("cia-report-method-tabs-tab-2").setAttribute("style", "cursor: not-allowed; opacity: 0.5");
      document.getElementById("cia-report-method-tabs-tab-3").setAttribute("style", "cursor: not-allowed; opacity: 0.5");
      document.getElementById("cia-report-method-tabs-tab-4").setAttribute("style", "cursor: not-allowed; opacity: 0.5");
      document.getElementById("cia-report-method-tabs-tab-5").setAttribute("style", "cursor: pointer; opacity: 1");
    }
    this.setState({
      tcTabIndex: index
    });
  };

  handleChangeMethodPage = (pageNumber) => {
    this.setState({
      currentMethodPage: pageNumber
    });
    CIAReportMethodData.pageNum = pageNumber - 1;
    this.getMethodReport(CIAReportMethodData);
  };

  handleChangeTCPage = (pageNumber) => {
    this.setState({
      currentTCPage: pageNumber
    });
    CIAReportTCData.pageNum = pageNumber - 1;
    this.getTCReport(CIAReportTCData);
  };

  onClickTab = () => {
    document.getElementById("cia-report-tc-tabs-tab-1").addEventListener("click", () => {
      this.clearStyleTab();
      document.getElementById("cia-report-tc-tabs-tab-1")
        .setAttribute("style", "border-top: 1px solid #3899ec;border-right: 1px solid #3899ec;border-left: 1px solid #3899ec");
    });
    document.getElementById("cia-report-tc-tabs-tab-2").addEventListener("click", () => {
      this.clearStyleTab();
      document.getElementById("cia-report-tc-tabs-tab-2")
        .setAttribute("style", "border-top: 1px solid #e45000;border-left: 1px solid #e45000; border-right: 1px solid #e45000");
    });
    document.getElementById("cia-report-tc-tabs-tab-3").addEventListener("click", () => {
      this.clearStyleTab();
      document.getElementById("cia-report-tc-tabs-tab-3")
        .setAttribute("style", "border-top: 1px solid #267d03;border-left: 1px solid #267d03;border-right: 1px solid #267d03");
    });
  };

  render() {
    return (
      <div className="cia-report-detail-wrapper">
        <Header/>
        <ConfirmModal/>
        <div className="content-title">
          <div className="content-title-text cia-title">CIA Report</div>
          <div className="content-title-square"></div>
        </div>
        <div className="cia-report-search-component">
          <div className="cia-title-small">Module info</div>
          <div className="cia-search-wrapper row">
            <div className=" medium col-lg-2">
              <span className="cia-label">Model</span>
              <div className=''><PickModelListComponent
                pickModel={this.pickModel}
                modelTitle={this.state.modelCIAReportTitle}
              /></div>
            </div>
            <div className=" small col-lg-2">
              <span className="cia-label  padding-0">Type</span>
              <ComponentDropdown title={this.state.TypeCIAReportTitle}
                iddropdown="cia-type" className=""
                listSearchStatus={this.state.listTypeCIAReport}
                handleClickItemDropdown={this.handleClickItemDropdown}
              />
            </div>
            <ModuleComponent pickModule={this.handleClickModuleItem}
                             modelId={SearchCIAReport.modelId}
                             type={SearchCIAReport.type}
                             moduleTitle={this.state.ModuleCIAReportTitle}/>
            <VersionComponent pickVersion={this.handleSelectVersionItem}
                              title="Base Version"
                              modelId={SearchCIAReport.moduleId}
                              moduleId={SearchCIAReport.moduleId}
                              type={SearchCIAReport.type}
                              isSetLable={false}
                              versionTitle={this.state.BaseVersionCIAReportTitle} />
            <TargetVersionComponent pickVersion={this.handleSelectTargetVersionItem}
                                    title="Target Version"
                                    versionId={SearchCIAReport.baseVersionId}
                                    targetVersionList={this.state.listBaseVersionCIAReport}
                                    versionTitle={this.state.targetVersionCIAReportTitle}/>

          </div>
        </div>
        <button className="btn btn-primary btn-show-report" onClick={this.showReport}>Show report</button>
        <div className="cia-report-search-component">
          <div className="cia-title">Report</div>
          <Tabs defaultActiveKey={1} className="cia-tabs" animation={false} id="cia-report-tc-tabs"
            onSelect={this.handleClickTCTab}>
            <Tab eventKey={1} title="All TC" tabClassName="cia-report-tc-1" />
            <Tab eventKey={2} title="Affected TC" tabClassName="cia-report-tc-2" />
            <Tab eventKey={3} title="Not affected TC" tabClassName="cia-report-tc-3" />
            <div className="cia-report-table-container">
              <CIAReportTCTable tableData={this.state.TCReport}/>
            </div>
            <div className="pagination-body">
              {this.state.TCReport && this.state.TCReport.list.length > 0 &&
                <UltimatePagination
                  currentPage={this.state.currentTCPage}
                  totalPages={this.state.TotalTCPage}
                  onChange={this.handleChangeTCPage}
                />
              }
            </div>
          </Tabs>
          <div className="export-all-button">
            <img src={ExportAll} alt="Excell all"/> Export All
            </div>
          <Tabs defaultActiveKey={1} className="cia-tabs method" animation={false} id="cia-report-method-tabs"
            onSelect={this.handleClickMethodTab}>
            <Tab eventKey={1} title="New Method" className="cia-report-method-tabs-1"
              disabled={this.state.tcTabIndex === 2 || this.state.tcTabIndex === 3} />
            <Tab eventKey={2} title="Modefied Method (Covered TC)"
              disabled={this.state.tcTabIndex === 3} />
            <Tab eventKey={3} title="Modefied Method (Uncovered TC)"
              disabled={this.state.tcTabIndex === 3} />
            <Tab eventKey={4} title="Remove Method"
              disabled={this.state.tcTabIndex === 3} />
            <Tab eventKey={5} title="Unchanged Method"
              disabled={this.state.tcTabIndex === 2} />
            <CIAReportMethodTable tableData={this.state.MethodReport}/>
            <div className="pagination-body">
              {this.state.MethodReport && this.state.MethodReport.list.length > 0 &&
                <UltimatePagination
                  currentPage={this.state.currentMethodPage}
                  totalPages={this.state.TotalMethodPage}
                  onChange={this.handleChangeMethodPage}
                />
              }
            </div>
          </Tabs>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return {
    actionModal: (title, message, isShow, successCallBack, failCallBack, disableSubmitBtn) => {
      dispatch(actionModal(title, message, isShow, successCallBack, failCallBack, disableSubmitBtn));
    },
    redirectPage: url => {
      dispatch(push(url));
    },
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    },
  };
};

export default connect(null, mapDispatchToProps)(CIAReport);