import {Modal,Button} from 'react-bootstrap';
import  React from "react";
import {connect} from 'react-redux';
import '../../../../public/styles/commons/alertModal/AlertModal.scss';
import {actionModal, closeModal, confirmCallBack} from "../../../actions/share";

class ConfirmModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showModal: true
    };
  }
  close = () => {
    this.props.hideModal();
    this.props.failCallBack();

  };

  confirm = () => {
    this.props.hideModal();
    this.props.successCallBack();
  };

  render() {
    return (
      <div className="alert-popup-container">
        <Modal dialogClassName="alert-modal" show={this.props.isShow} onHide={this.close}>
          <Modal.Header>{this.props.title}</Modal.Header>
          <Modal.Body>
            <div>{this.props.message}</div>
          </Modal.Body>
          <Modal.Footer>
            <button className="btn btn-default" onClick={this.close}>Close</button>
            <button className="btn btn-primary" onClick={this.confirm} disabled={this.props.disableSubmitBtn}>OK</button>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}
const mapStateToProps= function (state) {
  return ({
    isShow: state.application.share.confirmModal.isShow,
    message: state.application.share.confirmModal.message,
    title: state.application.share.confirmModal.title,
    successCallBack: state.application.share.confirmModal.successCallBack,
    failCallBack: state.application.share.confirmModal.failCallBack,
    disableSubmitBtn: state.application.share.confirmModal.disableSubmitBtn,
  });
};

const mapDispatchToProps = function (dispatch) {
  return({
    confirmCallBack: (value) => {
      dispatch(confirmCallBack(value));
    },
    actionModal: (message, isShow, successCallback, failCallBack) => {
      dispatch(actionModal(message, isShow, successCallback, failCallBack));
    },
    hideModal: () => {
      dispatch(closeModal());
    }
  })
};

export default connect(mapStateToProps,mapDispatchToProps)(ConfirmModal);