import React from 'react';
import '../../../../public/styles/commons/LeftNavigationBar/AppLogo.scss'
import ConfirmModal from '../confirmModal/confirmModal';
import {connect} from 'react-redux';
import {push} from 'redux-router';
import Avatar from '../LeftNavigationBar/Avatar';
import {actionModal} from "../../../actions/share";
import IconCIAPortal from "../../../../public/images/icons/logo_cia.png"

class AppMenu extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="wrap-menu-x">
        <ConfirmModal/>
        <div className="logo-app">
          <div className="icon-app">
            <img src={IconCIAPortal} height={34} width={76} alt="CIA Portal"/>
          </div>
          <Avatar/>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
});

const mapDispatchToProps = (dispatch) => {
  return {
    redirectPage: (url) => {
      dispatch(push(url));
    },
    actionModal: (title, message, isShow, successCallBack, failCallBack) => {
      dispatch(actionModal(title, message, isShow, successCallBack, failCallBack));
    },
  }
};

export default connect(mapStateToProps, mapDispatchToProps)(AppMenu);
