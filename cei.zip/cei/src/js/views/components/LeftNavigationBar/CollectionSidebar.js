import React from "react";
import {connect} from 'react-redux';
import {push} from "redux-router";
import AppLogo from './AppLogo';
import MainLeftSidebar from './MainLeftSidebar';
import {makeGetRequest, makeDeleteRequest, makePutRequest} from '../../../../js/utils/cuiResource';
import {Button} from 'react-bootstrap';
import '../../../../public/styles/commons/LeftNavigationBar/CollectionSidebar.scss';

class CollectionSidebar extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="root-sidebar">
        <AppLogo />
        <MainLeftSidebar/>
      </div>
    )
  }
}

const mapDispatchToProps = dispatch => {
  return {
    redirectPage: url => {
      dispatch(push(url));
    },
    showAlert: (message) => {
      dispatch(showAlert(message));
    }
  };
};

export default connect(null, mapDispatchToProps)(CollectionSidebar);