import React, {Component} from 'react';
import {connect} from "react-redux";
import {push} from "redux-router";
import PropTypes from 'prop-types';
import IconUser from '../../../../public/images/icons/user_default.png';
import '../../../../public/styles/commons/LeftNavigationBar/AppLogo.scss';
import * as CookieService from '../../../utils/cookieService';
import {actionModal, reloadAvatar} from "../../../actions/share";
import Modal from "react-bootstrap";
import {makeGetRequest} from "../../../utils/cuiResource";

class Avatar extends Component {

  constructor(props) {
    super(props);
    this.state = {
      userName: CookieService.get('userID'),
      isShowDropdown: false,
      avatarImg: null
    }
  }

  componentWillMount() {
    this.loadOrUpdateAvatar();
    this.props.reloadAvatar(this.loadOrUpdateAvatar);
  }

  getImages = (image) => {
    if(image.storeName) {
      let config = {
        url: '/api/tools/files',
        params: {
          file: image.storeName
        },
        transformResponse: data => {
          return {tmp: data}
        },
        responseType: 'arraybuffer'
      };
      makeGetRequest(config, (response) => {
        const convertImg = new Blob([response.data.tmp], {type: image.type});
        const fileReader = new FileReader();
        let fileCreate = {
          id: image.id,
          name: image.filename,
          filename: image.filename,
          filesize: image.filesize,
          size: image.filesize,
          type: image.type,
          storeName: image.storeName,
        };

        fileReader.onloadend = e => {
          this.setState({
            avatarImg: {src: e.target.result}
          }, () => {
            this.setState({})
          });
        };
        fileReader.readAsDataURL(convertImg);
      }, (failCallBack) => {

      });
    } else {
      this.setState({
        avatarImg: this.props.userAvatar,
      })
    }
  };

  upDateUserName = (newName) => {
    this.setState({
      userName: newName
    });
  }

  loadOrUpdateAvatar = () => {
/*    let userId=CookieService.get("userID");

    let config={
      url:'/api/users/'+userId,
    };
    makeGetRequest(config,(response)=>{
      this.upDateUserName(response.data.value.login);
      this.getImages(response.data.value.avatar)
    }, () => {
    });*/
  };

  hideDropdown = () => {
    this.setShowDropdown(false)();
  };

  setShowDropdown = (isShow) => (e) => {
    this.setState({
      isShowDropdown: isShow
    }, () => {
      if (this.state.isShowDropdown) {
        window.addEventListener('click', this.hideDropdown);
      } else {
        window.removeEventListener('click', this.hideDropdown);
      }
    });
    if(e) {
      e.stopPropagation();
    }
  };

  openDropdown = (e) => {
    this.setShowDropdown(e.target.className !== 'user-item')(e);
  };

  render() {
    return (
      <div className="user-avatar-box" onClick={this.openDropdown}>
        <img className="user-avatar" src={this.props.userAvatar} height={68} width={68} alt="avatar"/>
        <div className="user-name">{this.state.userName}</div>
      </div>
    );
  }
}

Avatar.propTypes = {
  userAvatar: PropTypes.string,
  userName: PropTypes.string
}

Avatar.defaultProps = {
  userAvatar: IconUser,
  userName: 'User Name'
}

const mapStateToProps = (state) => ({
  permissions: state.application.system.user.permissions,
  functionGetDiffUpload: state.application.share.getDiffUpload
});

const mapDispatchToProps = dispatch => {
  return {
    redirectPage: url => {
      dispatch(push(url));
    },
    actionModal: (title, message, isShow, successCallBack, failCallBack) => {
      dispatch(actionModal(title, message, isShow, successCallBack, failCallBack));
    },
    reloadAvatar: (func) => {
      dispatch(reloadAvatar(func));
    }
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Avatar);