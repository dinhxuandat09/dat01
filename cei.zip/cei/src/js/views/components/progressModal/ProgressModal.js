import '../../../../public/styles/commons/progressModal/ProgressModal.scss';
import React from "react";
import connect from "react-redux/es/connect/connect";
import {Modal} from 'react-bootstrap';

class ProgressModal extends React.Component {
  render() {
    return(
      <div>
        <Modal dialogClassName="progress-modal" show={this.props.isShowProgress}>
          <Modal.Body>
          </Modal.Body>
        </Modal>
      </div>
    )
  }
}

const mapStateToProps = function (state) {
  return (
    {isShowProgress : state.application.share.progressModal.isShow}
  )
}

export default connect(mapStateToProps,null)(ProgressModal)