import React from 'react';
import {connect} from "react-redux";
import {push} from "redux-router";
import '../../../../public/styles/pages/CIATable.scss';
import '../../../../public/styles/pages/PickModelListComponent.scss';
import * as commonService from '../../../service/commonService';
import {Modal, Button} from 'react-bootstrap';
import UltimatePagination from "react-ultimate-pagination-bootstrap-4";
import {showProgress, hideProgress} from '../../../actions/share';
import Ic_Close from '../../../../public/images/icons/ic_close_black.png'

let CIAModuleData = {
  pageSize: 8,
  pageNum: 0
};

class PickModuleListComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      listModule: [],
      currentPage: 1,
      TotalPage: 1,
      searchText: '',
      showModuleList: false
    }
  }

  componentDidMount() {
    this.props.onRef(this)
  }

  componentWillMount() {
    this.props.onRef(undefined)
    CIAModuleData.moduleName = null;
    this.getListModule(CIAModuleData);
  };

  componentWillReceiveProps(nextProps) {
    if (nextProps.modelId !== this.props.modelId && nextProps.modelId) {
      this.setState({
        searchText: ''
      })
    }
    if (nextProps.type !== this.props.type && nextProps.type) {
      CIAModuleData.modelId = this.props.modelId;
      CIAModuleData.type = nextProps.type;
      this.getListModule(CIAModuleData);
    }
  }

  getAllListModule() {
    this.setState({
      searchText: ''
    });
    CIAModuleData.modelId = '';
    CIAModuleData.type = '';
    this.getListModule(CIAModuleData);
  };

  getListModule = (data) => {
    commonService.getModulesByModel(data, (res) => {
      this.setState({
        listModule: res.data.value.list,
        TotalPage: Math.ceil(res.data.value.totalCount / 8) !== 0 ? Math.ceil(res.data.value.totalCount / 8) : 1
      });
    }, (error) => {
    });
  };

  handlePickModule = (item) => e => {
    this.setState({
      searchText: item,
      showModuleList: false
    });
    this.props.pickModule(item)
  };

  handleChangePage = (page) => {
    this.setState({
      currentPage: page
    });
    CIAModuleData.pageNum = page - 1;
    this.getListModule(CIAModuleData);
  };

  handleChangeSearchText = () => e => {
    this.setState({
      searchText: e.target.value
    });
    CIAModuleData.moduleName = e.target.value
    this.handleSearchModule();
  };

  handleSearchModule = () => {
    CIAModuleData.pageNum = 0;
    this.setState({
      currentPage: 1
    });
    this.getListModule(CIAModuleData);
  };

  openModalModuleList = () => {
    this.setState({
      showModuleList: true
    });
    this.ClosePopUpClickOutSize();
    this.handleChangeSearchText();
  };

  ClosePopUpClickOutSize = () => {
    $(document).unbind("click touch");
    $(document).on('click touch', (event) => {
      if (!$(event.target).parents().addBack().is('.model-list-container')) {
        if (event.target.id != "input-component")
          this.setState({showModuleList: false});
        $(document).unbind("click touch");
      }
    });
  };

  close = () => {
    this.setState({
      showModuleList: false
    })
  };

  render() {
    return (
      <div>
        <input type="text" className="cia-text" id="input-component"
               onClick={this.openModalModuleList}
               value={this.state.searchText} onChange={this.handleChangeSearchText()}
               placeholder="Enter Module Name"
        />
        {this.state.showModuleList &&
        <div className="model-list-container" onClick={(e) => e.stopPropagation()}>
          <div className="model-list-body-container">
            {this.state.listModule && this.state.listModule.length > 0 &&
            <div className="table-wrapper">
              <table className="table table-striped">
                <tbody>
                <tr className="table-header">
                  <th className="text-center">Module Name</th>
                </tr>
                {this.state.listModule.map((item, idx) => {
                  return <tr key={idx} onClick={this.handlePickModule(item)}>
                    <td className="padding-15">{item}</td>
                  </tr>;
                })}
                </tbody>
              </table>
              <UltimatePagination
                currentPage={this.state.currentPage}
                totalPages={this.state.TotalPage}
                onChange={this.handleChangePage}
              />
            </div>
            }
            {!this.state.listModule || this.state.listModule.length == 0 &&

            <div className="empty-data"><span className="text-center">Data Do Not Exist !. Please Input Again</span>
            </div>}
          </div>
        </div>
        }
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return {
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    }
  };
};

export default connect(null, mapDispatchToProps)(PickModuleListComponent);