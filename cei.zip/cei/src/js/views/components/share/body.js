import React from 'react'
import ToolCard from '../toolCard/ToolCard.js'
import '../../../../public/styles/commons/share/body.scss';
class Body extends React.Component {
  render() {
    let listToolCard = [{id:"1"},{id:"2"},{id:"3"},{id:"4"},{id:"5"},{id:"6"},{id:"7"},{id:"8"},{id:"9"},{id:"10"},{id:"11"},{id:"12"}];
    return (
      <div className="body">
        { listToolCard.map(function(element) {
            return <ToolCard key={element.id}/>
          })
        }
      </div>
    );
  }
}

export default Body;
