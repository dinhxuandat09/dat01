import React from 'react';

class TargetVersionComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      valueInput: '',
      isShowSuggest: false,
      selected: -1,
      listVersionBinary: []
    };
    this.onHandleSuggest = this.onHandleSuggest.bind(this);
  }

  handleCloseSuggest = (e) => {
    if (this.nodeInput && !this.nodeInput.contains(e.target)) {
      this.setShowSuggest(false)();
    }
  };

  componentWillUpdate(nextProps, nextState) {
    if (nextState.isShowSuggest !== this.state.isShowSuggest) {
      if (!this.state.isShowSuggest) {
        window.addEventListener('click', this.handleCloseSuggest);
      } else {
        window.removeEventListener('click', this.handleCloseSuggest);
      }
    }
  }

  setShowSuggest = (isShow) => () => {
    this.setState({
      isShowSuggest: isShow
    })
  };

  openVersionList = () => {
    if (this.props.versionId) {
      this.setShowSuggest(true)();
      this.getVersionByModule(this.state.valueInput);
    }
  };

  onHandleSuggest(e) {
    this.setState({
      selected: -1,
      isShowSuggest: true,
      valueInput: e.target.value
    });
    if (e.target.value) {
      if (this.props.versionId) {
        this.getVersionByModule(e.target.value);
      }
    } else {
      this.setState({
        isShowSuggest: false,
        listVersionBinary: []
      });
    }
  };

  onHandleClick = (item) => e => {
    this.setState({
      valueInput: ''
    });
    this.props.pickVersion(item);
  };

  getVersionByModule = (versionName) => {
    let versionList = [];
    for (let i = 0; i < this.props.targetVersionList.length; i++) {
      if (this.props.targetVersionList[i].value !== this.props.versionId &&
          this.props.targetVersionList[i].title.indexOf(versionName) !== -1) {
        versionList.push(this.props.targetVersionList[i]);
      }
    }
    this.setState({
      listVersionBinary: versionList
    })
  };

  render() {
    return (
        <div className=" medium col-lg-3 module-info-component-wrapper">
          <span className=" padding-0 cia-label">{this.props.title}</span>
          <input ref={nodeInput => this.nodeInput = nodeInput} className="form-control input-module"
                 onChange={this.onHandleSuggest} value={this.state.valueInput}
                 onClick={this.openVersionList} placeholder={this.props.versionTitle} />
          {this.state.listVersionBinary.length > 0 && this.state.isShowSuggest && <ul className="search-suggest">
            {this.state.listVersionBinary.map((item, index) => <li
                className={this.state.selected == item.id ? "search-item selected-item" : "search-item"}
                key={'module-item' + index} onClick={this.onHandleClick(item)}>{item.title}</li>)
            }
          </ul>}
        </div>
    );
  }
}

export default TargetVersionComponent;