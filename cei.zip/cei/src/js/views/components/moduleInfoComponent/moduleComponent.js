import React from 'react';
import * as commonService from '../../../service/commonService';

class ModuleComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      valueInput: '',
      isShowSuggest: false,
      selected: -1,
      listModuleBinary: []
    };
    this.onHandleSuggest = this.onHandleSuggest.bind(this);
  }

  handleCloseSuggest = (e) => {
    if (!this.nodeInput.contains(e.target)) {
      this.setShowSuggest(false)();
    }
  };

  componentWillUpdate(nextProps, nextState) {
    if (nextState.isShowSuggest !== this.state.isShowSuggest) {
      if (!this.state.isShowSuggest) {
        window.addEventListener('click', this.handleCloseSuggest);
      } else {
        window.removeEventListener('click', this.handleCloseSuggest);
      }
    }
  }

  setShowSuggest = (isShow) => () => {
    this.setState({
      isShowSuggest: isShow
    })
  };

  openModuleList = () => {
    if (this.props.modelId) {
      this.setShowSuggest(true)();
      this.getListModuleByModel(this.state.valueInput);
    }
  };

  onHandleSuggest(e) {
    this.setState({
      selected: -1,
      isShowSuggest: true,
      valueInput: e.target.value
    });
    if (e.target.value) {
      if (this.props.modelId && this.props.type) {
        this.getListModuleByModel(e.target.value);
      }
    } else {
      this.setState({
        isShowSuggest: false,
        listModuleBinary: []
        // moduleBinaryTitle: "Enter Module Name"
      });
    }
  };

  onHandleClick = (item) => e => {
    this.setState({
      valueInput: ''
    });
    this.props.pickModule(item);
  };

  getListModuleByModel = (moduleName) => {
    let data = {
      modelId: this.props.modelId,
      type: this.props.type
    };
    if (moduleName) {
      data.moduleName = moduleName;
    }
    commonService.getModulesByModel(data, (res) => {
      let modulesList = [];
      for (let i = 0; i < res.data.value.list.length; i++) {
        let item = {title: res.data.value.list[i].name, value: res.data.value.list[i].id};
        modulesList.push(item);
      }
      this.setState({
        listModuleBinary: modulesList
      })
    }, (error) => {
    })
  };

  render() {
    return (
        <div className=" medium col-lg-3 module-info-component-wrapper">
          <span className=" padding-0 cia-label">Module Name</span>
          <input ref={nodeInput => this.nodeInput = nodeInput} className="form-control input-module"
                 onChange={this.onHandleSuggest} value={this.state.valueInput}
                 onClick={this.openModuleList} placeholder={this.props.moduleTitle}/>
          {this.state.listModuleBinary.length > 0 && this.state.isShowSuggest && <ul className="search-suggest">
            {this.state.listModuleBinary.map((item, index) => <li
                className={this.state.selected == item.id ? "search-item selected-item" : "search-item"}
                key={'module-item' + index} onClick={this.onHandleClick(item)}>{item.title}</li>)
            }
          </ul>}
        </div>
    );
  }
}

export default ModuleComponent;