import React from 'react';
import * as commonService from '../../../service/commonService';

class VersionComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      valueInput: '',
      isShowSuggest: false,
      selected: -1,
      listVersionBinary: []
    };
    this.onHandleSuggest = this.onHandleSuggest.bind(this);
  }

  handleCloseSuggest = (e) => {
    if (this.nodeInput && !this.nodeInput.contains(e.target)) {
      this.setShowSuggest(false)();
    }
  };

  componentWillUpdate(nextProps, nextState) {
    if (nextState.isShowSuggest !== this.state.isShowSuggest) {
      if (!this.state.isShowSuggest) {
        window.addEventListener('click', this.handleCloseSuggest);
      } else {
        window.removeEventListener('click', this.handleCloseSuggest);
      }
    }
  }

  setShowSuggest = (isShow) => () => {
    this.setState({
      isShowSuggest: isShow
    })
  };

  openVersionList = () => {
    if (this.props.moduleName) {
      this.setShowSuggest(true)();
      this.getVersionByModule(this.state.valueInput);
    }
  };

  onHandleSuggest(e) {
    this.setState({
      selected: -1,
      isShowSuggest: true,
      valueInput: e.target.value
    });
    if (e.target.value) {
      if (this.props.moduleName) {
        this.getVersionByModule(e.target.value);
      }
    } else {
      this.setState({
        isShowSuggest: false,
        listVersionBinary: []
      });
    }
  };

  onHandleClick = (item) => e => {
    this.setState({
      valueInput: ''
    });
    this.props.pickVersion(item);
  };

  getVersionByModule = (versionName) => {
    let data = {
      moduleName: this.props.moduleName,
    };
    if(this.props.modelId && this.props.type){
      data.modelId = this.props.modelId;
      data.type = this.props.type;
    }
    if (versionName) {
      data.versionName = versionName;
    }
    commonService.getVersionByModule(data, (res) => {
      let versionList = [];
      let codetypeList = [];
      let qbserverList = [];
      let qbidList = [];
      let pathList = [];
      let clList = [];
      for (let i = 0; i < res.data.value.list.length; i++) {
        let varsionItem = { title: res.data.value.list[i].version, value: res.data.value.list[i].id, index: i };
        let codetypeitem = { title: res.data.value.list[i].codeType };
        let qbserveritem = { title: res.data.value.list[i].qbServer };
        let qbiditem = { title: res.data.value.list[i].qbId };
        let pathitem = { title: res.data.value.list[i].path };
        let clitem = { title: res.data.value.list[i].cl };
        versionList.push(varsionItem);
        codetypeList.push(codetypeitem);
        qbserverList.push(qbserveritem);
        qbidList.push(qbiditem);
        pathList.push(pathitem);
        clList.push(clitem);
      }
      this.setState({
        listVersionBinary: versionList
      });
      if (this.props.isSetLable) {
        this.props.setLable(codetypeList, qbserverList, qbidList, pathList, clList);
      }
    }, (error) => {
    })
  };

  render() {
    return (
      <div className="medium col-lg-3 module-info-component-wrapper">
        <span className="padding-0 cia-label">{this.props.title}</span>
        <input ref={nodeInput => this.nodeInput = nodeInput} className="form-control input-module"
          onChange={this.onHandleSuggest} value={this.state.valueInput}
          onClick={this.openVersionList} placeholder={this.props.versionTitle} />
        {this.state.listVersionBinary.length > 0 && this.state.isShowSuggest && <ul className="search-suggest">
          {this.state.listVersionBinary.map((item, index) => <li
            className={this.state.selected == item.id ? "search-item selected-item" : "search-item"}
            key={'module-item' + index} onClick={this.onHandleClick(item)}>{item.title}</li>)
          }
        </ul>}
      </div>
    );
  }
}

export default VersionComponent;