import {Modal,Button} from 'react-bootstrap';
import  React from "react";
import {connect} from 'react-redux';
import '../../../../public/styles/commons/alertModal/AlertModal.scss';
import {hideAlert, showAlert} from "../../../actions/share";

class AlertModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showModal: true
    };
  }
  close = () => {
    if (this.props.callBackFunc) {
      this.props.callBackFunc();
    }
    this.props.hideAlert();
  };

  render() {
    return (
      <div className="alert-popup-container">
        <Modal dialogClassName="alert-modal" show={this.props.isShow} onHide={this.close}>
          <Modal.Header>
            <div>Message</div>
          </Modal.Header>
          <Modal.Body>
            <div>{this.props.message}</div>
          </Modal.Body>
          <Modal.Footer>
            <Button className="btn btn-default" onClick={this.close}>Close</Button>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}
const mapStateToProps= function (state) {
  return ({
    isShow: state.application.share.alertPopup.isShow,
    message: state.application.share.alertPopup.message,
    callBackFunc: state.application.share.alertPopup.successFnc,
  });
};

const mapDispatchToProps = function (dispatch) {
  return({
    hideAlert: () => {
      dispatch(hideAlert());
    },
    showAlert: () => {
      dispatch(showAlert());
    }
  })
};

export default connect(mapStateToProps,mapDispatchToProps)(AlertModal);