import { OPEN_DIALOG, CLOSE_DIALOG } from '../utils/constants/actiontypes';
import createReducer from '../utils/create-reducer';

const initialState = {
  isOpen: false,
  props: {},
};

const dialogHandler = {
  [OPEN_DIALOG]: (state, action) => ({ ...state, isOpen: true, props: action.payload }),
  [CLOSE_DIALOG]: (state, action) => initialState
}

export default createReducer(initialState, dialogHandler);
