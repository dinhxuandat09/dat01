export { default as en } from './en.json';
export { default as ko } from './kr.json';
export { default as ja } from './jp.json';
export { default as zh } from './cn.json';
