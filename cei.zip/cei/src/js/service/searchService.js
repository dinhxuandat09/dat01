import { isUndefinedOrNull, isFunction } from 'lodash';
import { makeGetRequest } from '../utils/cuiResource';

export function getSearchResult(data, successCallback, failCallback) {
  let config = {
    url: '/api/_search/reports',
    params: {
      pageSize: 10000,
    }
  }
  config.params = Object.assign({}, config.params, data);
  makeGetRequest(config, (response) => {
    successCallback(response);
  }, (error) => {
    failCallback(error);
  })
}