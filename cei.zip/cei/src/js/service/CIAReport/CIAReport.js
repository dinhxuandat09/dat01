import { isUndefinedOrNull, isFunction } from 'lodash';
import {makeGetRequest} from '../../utils/cuiResource';

export function getCIAReport(data, successCallBack, failCallBack) {
  let config = {
    url: 'api/reports/getId',
    params: {
      modelId: null,
      moduleId: null,
      baseVersionId: null,
      TargetVersionId: null
    }
  };
  config.params = Object.assign({}, config.params, data);
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}

export function getMethodReport(data, successCallBack, failCallBack) {
  let config = {
    url: 'api/reports/method',
    params: {
      pageNum: null,
      pageSize: 10,
      reportId: null,
      type: null
    }
  };
  config.params = Object.assign({}, config.params, data);
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}

export function getTCReport(data, successCallBack, failCallBack) {
  let config = {
    url: 'api/reports/tc',
    params: {
      pageNum: 0,
      pageSize: 10,
      reportId: null,
      typeTc: null
    }
  };
  config.params = Object.assign({}, config.params, data);
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}