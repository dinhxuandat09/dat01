const webpack = require('webpack');
const path = require('path');

const DashboardPlugin = require('webpack-dashboard/plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const autoprefixer = require('autoprefixer');
const LiveReloadPlugin = require('webpack-livereload-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

const nodeEnv = process.env.NODE_ENV || 'development';
const isProduction = nodeEnv === 'production' || nodeEnv === 'staging' || nodeEnv === 'dev';

const jsSourcePath = path.join(__dirname, './src/js');
const buildPath = path.join(__dirname, './build');
const imgPath = path.join(__dirname, './src/public/images');
const sourcePath = path.join(__dirname, './src');
// var BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
// Common plugins
const plugins = [
  // new BundleAnalyzerPlugin({ analyzerMode: 'static' }),
  new webpack.optimize.CommonsChunkPlugin({ name: 'vendor', minChunks: Infinity, filename: 'vendor.js' }),
  new webpack.DefinePlugin({ 'process.env': { NODE_ENV: JSON.stringify(isProduction ? 'production' : 'development'), } }),
  new webpack.NamedModulesPlugin(),
  new HtmlWebpackPlugin({ template: path.join(sourcePath, 'index.html'), path: buildPath, filename: 'index.html' }),
  new webpack.LoaderOptionsPlugin({ options: { postcss: [autoprefixer({ browsers: ['last 3 version', 'ie >= 10'] })], context: sourcePath } })];

// Common rules
const rules = [{
  test: /\.(js|jsx)$/,
  exclude: /node_modules/,
  use: [{
    loader: 'babel-loader',
    options: { presets: ['babel-preset-es2015', 'babel-preset-react', 'babel-preset-stage-0'].map(require.resolve) }
  }]
},
{ test: /\.svg$/, use: [{ loader: 'svg-sprite-loader', options: { name: 'icon-[name]', prefixize: true } }] },
{ test: /\.(jpe?g|png|gif)$/i, use: [{ loader: 'url-loader', options: { limit: 10000 } }] },
{ test: /\.(eot|ttf|woff|woff2)$/, loader: 'file-loader?name=font/[name].[ext]' }];

if (isProduction) {
  // Production plugins
  plugins.push(
    new webpack.LoaderOptionsPlugin({ minimize: true, debug: false }),
    new webpack.optimize.UglifyJsPlugin({
      compress: {
        warnings: false,
        screw_ie8: true,
        conditionals: true,
        unused: true,
        comparisons: true,
        sequences: true,
        dead_code: true,
        evaluate: true,
        if_return: true,
        join_vars: true
      },
      output: { comments: false }
    }),
    new CopyWebpackPlugin([
      { from: imgPath, to: buildPath + '/images' },
      { from: sourcePath + '/public/favicon.ico', to: buildPath }]),
    new ExtractTextPlugin('style.css')
  );

  // Production rules for scss
  rules.push({ test: /\.scss$/, loader: ExtractTextPlugin.extract({ fallback: 'style-loader', use: 'css-loader!postcss-loader!sass-loader' }) });
} else {
  // Development plugins
  plugins.push(
    new DashboardPlugin(),
    new webpack.HotModuleReplacementPlugin(),
    //new LiveReloadPlugin({ appendScriptTag: true }),
    new ExtractTextPlugin('style.css')
  );
  // Development rules
  rules.push({ test: /\.scss$/, loader: ExtractTextPlugin.extract({ fallback: 'style-loader', use: 'css-loader!sass-loader' }) });
}

var conf = {
  devtool: isProduction ? 'cheap-module-source-map' : 'inline-sourcemap',
  context: jsSourcePath,
  entry: {
    app: './index.js',
    vendor: [
      'babel-polyfill',
      'react-dom',
      'react-redux',
      'isomorphic-fetch',
      'react',
      'react-router',
      'redux'
    ]
  },
  output: { path: buildPath, publicPath: '', filename: 'app.js', chunkFilename: "[name].bundle.js" },
  module: { rules },
  resolve: {
    extensions: ['.webpack-loader.js', '.web-loader.js', '.loader.js', '.js', '.jsx'],
    modules: [path.resolve(__dirname, 'node_modules'), jsSourcePath]
  },
  plugins,
  devServer: {
    contentBase: './source/public',
    historyApiFallback: true,
    port: 8080,
    compress: isProduction,
    inline: !isProduction,
    hot: !isProduction,
    disableHostCheck: true,
    host: 'cia.sec.samsung.net',
    stats: {
      assets: true,
      children: false,
      chunks: false,
      hash: false,
      modules: false,
      publicPath: false,
      timings: true,
      version: false,
      warnings: true,
      colors: {
        green: '\u001b[32m'
      }
    },
    proxy: [{
      context: [
        '/oauth',
        '/api',
        '/management',
        '/swagger-resources',
        '/v2/api-docs',
        '/h2-console'
      ],
      target: 'http://107.113.53.54:9090',
      secure: false
    }]
  }
};
module.exports = conf;