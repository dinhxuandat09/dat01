const getTextButtonColors = (theme, type) => {
  switch (type) {
  case 'primary':
    return {
      border: theme.primaryColor,
      background: theme.primaryColor,
      text: theme.alternateTextColor,
    };
  default:
    return {
      border: theme.borderColor,
      background: 'transparent',
      text: theme.primaryColor,
    }
  }
}

export default getTextButtonColors;
