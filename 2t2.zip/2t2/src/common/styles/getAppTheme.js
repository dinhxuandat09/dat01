import {
  PRIMARY_COLOR_NOTES,
  PRIMARY_COLOR_GALLERY,
  PRIMARY_COLOR_DRIVE,
  PRIMARY_COLOR_CALENDAR,
  PRIMARY_COLOR_CONTACTS,
  PRIMARY_COLOR_DEFAULT,
  CANVAS_COLOR,
  OVERLAY_COLOR,
  MODAL_COLOR,
  MENU_COLOR,
  TOOLTIP_COLOR,
  HOVER_COLOR,
  BORDER_COLOR,
  SHADOW_COLOR,
  TEXT_COLOR_DEFAULT,
  TEXT_COLOR_ALTERNATE,
} from '../constants/colors';

const getAppTheme = function(appName) {
  let primaryColor;

  switch (appName) {
  case 'Notes':
    primaryColor = PRIMARY_COLOR_NOTES;
    break;
  case 'Gallery':
    primaryColor = PRIMARY_COLOR_GALLERY;
    break;
  case 'Drive':
    primaryColor = PRIMARY_COLOR_DRIVE;
    break;
  case 'Calendar':
    primaryColor = PRIMARY_COLOR_CALENDAR;
    break;
  case 'Contacts':
    primaryColor = PRIMARY_COLOR_CONTACTS;
    break;
  default:
    primaryColor = PRIMARY_COLOR_DEFAULT;
    break;
  }

  return {
    primaryColor,
    canvasColor: CANVAS_COLOR,
    overlayColor: OVERLAY_COLOR,
    modalColor: MODAL_COLOR,
    menuColor: MENU_COLOR,
    tooltipColor: TOOLTIP_COLOR,
    hoverColor: HOVER_COLOR,
    borderColor: BORDER_COLOR,
    shadowColor: SHADOW_COLOR,
    textColor: TEXT_COLOR_DEFAULT,
    alternateTextColor: TEXT_COLOR_ALTERNATE,
  };
}

export default getAppTheme;
