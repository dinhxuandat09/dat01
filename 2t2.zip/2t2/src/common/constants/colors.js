export const PRIMARY_COLOR_NOTES    = 'rgba(244, 106, 78, 1)';
export const PRIMARY_COLOR_GALLERY  = 'rgba(255, 195, 15, 1)';
export const PRIMARY_COLOR_DRIVE    = 'rgba(144, 101, 243, 1)';
export const PRIMARY_COLOR_CALENDAR = 'rgba(44, 197, 219, 1)';
export const PRIMARY_COLOR_CONTACTS = 'rgba(254, 144, 9, 1)';
export const PRIMARY_COLOR_DEFAULT  = 'rgba(24, 138, 232, 1)';

export const CANVAS_COLOR  = 'rgba(249, 250, 251, 1)';
export const OVERLAY_COLOR = 'rgba(0, 0, 0, .5)';
export const MODAL_COLOR   = 'rgba(255, 255, 255, 1)';
export const MENU_COLOR    = 'rgba(255, 255, 255, 1)';
export const TOOLTIP_COLOR = 'rgba(255, 255, 255, 1)';
export const HOVER_COLOR   = 'rgba(0, 0, 0, .1)';

export const BORDER_COLOR = 'rgba(200, 200, 200, 1)';
export const SHADOW_COLOR = 'rgba(0, 0, 0, .2)';

export const TEXT_COLOR_DEFAULT    = 'rgba(0, 0, 0, .73)';
export const TEXT_COLOR_ALTERNATE  = 'rgba(255, 255, 255, 1)';
