export const BREAKPOINT_DESKTOP = '@media screen and (min-width: 1025px)';
export const BREAKPOINT_TABLET  = '@media screen and (min-width: 768px) and (max-width: 1024px)';
export const BREAKPOINT_MOBILE  = '@media screen and (min-width: 320px) and (max-width: 767px)';
