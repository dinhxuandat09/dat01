import React from 'react'
import '../../public/styles/commons/uploadFile/uploadFile.scss';
import Cloud_Ic from '../../public/images/icons/ic_upload.png'
class UploadFile extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      isShowDialog: false,
      files: []
    };
  }

  componentWillReceiveProps(nextProps) {
    if(nextProps.listFile && nextProps.listFile.length >= 0){
      this.setState((prevState) => {
        return ({ ...prevState, files: nextProps.listFile})
      })
    }
  }

  componentDidMount() {
    let dropZone = document.getElementById(this.props.id);
    dropZone.ondrop = (e) => {
      e.preventDefault();
      this.className = 'upload-file';
      let files = e.dataTransfer.files;
      let uploadFiles = Array.prototype.filter.call(files, file => {
        if (file.name.split('.').pop() === 'doc' || file.name.split('.').pop() === 'xls' ||
            file.name.split('.').pop() === 'docx' || file.name.split('.').pop() === 'xlsx' ||
            file.name.split('.').pop() === 'pptx' || file.name.split('.').pop() === 'rtf' ||
            file.name.split('.').pop() === 'txt' || file.name.split('.').pop() === 'xml' ||
            file.name.split('.').pop() === 'PNG' || file.name.split('.').pop() === 'JPG' ||
            file.name.split('.').pop() === 'ppt' || file.name.split('.').pop() === 'png' ||
            file.name.split('.').pop() === 'jpg' || file.name.split('.').pop() === 'git' ||
            file.name.split('.').pop() === 'mp4' || file.name.split('.').pop() === '7z' ||
            file.name.split('.').pop() === 'zip' || file.name.split('.').pop() === 'pdf' ||
            file.name.indexOf(".zip.") > 0 || file.name.indexOf(".7z.") > 0) {
          return file;
        }
      });
      let arr = [...this.state.files, ...uploadFiles];
      this.setState({
        isShowDialog: false,
        files: arr
      });
      this.props.watchChangeFile([...arr]);
    };
    dropZone.ondragover = () => {
      this.className = 'upload-file';
      this.setState({
        isShowDialog: true
      });
      return false;
    };

    dropZone.ondragleave = () => {
      this.className = 'upload-file';
      this.setState({
        isShowDialog: false
      });
      return false;
    }
  }

  upload = () => {
    let imgId = this.props.click;
    document.getElementById(imgId).click();
  };

  onUpload = () => {
    let files = document.getElementById(this.props.click).files;
    let uploadFiles = Array.prototype.filter.call(files, file => {
      if (file.name.split('.').pop() === 'doc' || file.name.split('.').pop() === 'xls' ||
          file.name.split('.').pop() === 'ppt' || file.name.split('.').pop() === 'png' ||
          file.name.split('.').pop() === 'jpg' || file.name.split('.').pop() === 'git' ||
          file.name.split('.').pop() === 'JPG' || file.name.split('.').pop() === 'PNG' ||
          file.name.split('.').pop() === 'mp4' || file.name.split('.').pop() === '7z' ||
          file.name.split('.').pop() === 'docx' || file.name.split('.').pop() === 'xlsx' ||
          file.name.split('.').pop() === 'pptx' || file.name.split('.').pop() === 'rtf' ||
          file.name.split('.').pop() === 'txt' || file.name.split('.').pop() === 'xml' ||
          file.name.split('.').pop() === 'zip' || file.name.split('.').pop() === 'pdf' ||
          file.name.indexOf(".zip.") > 0 || file.name.indexOf(".7z.") > 0
      ) {
        return file;
      }
    });
    this.props.watchChangeFile([...uploadFiles]);
    let arr = [...this.state.files, ...uploadFiles];
    this.setState({
      files: arr
    });
    this.props.watchChangeFile([...arr]);
  };

  removeFile = (index) => () => {
    let fileList = [];
    for (let i = 0; i < this.state.files.length; i++) {
      if (i !== index) {
        fileList.push(this.state.files[i]);
      }
    }
    this.setState({
      files: fileList
    });
    this.props.watchChangeFile([...fileList]);
    let fileId = this.props.click;
    document.getElementById(fileId).value = null;
  };

  bytesToSize = (bytes) => {
    var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes == 0) return '0 Byte';
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
    return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
  };

  render() {
    const {fileType, id, click} = this.props;
    let fileName = [];
    if(this.state.files && this.state.files.length){
      for (let i = 0; i < this.state.files.length; i++) {
        if(this.state.files[i] && this.state.files[i].name){
          fileName.push(<div className="file-list-component" key={'fileName-' + i}>
            <div className="upload-files" data-toggle="tooltip" data-placement="top" title={this.state.files[i].name}>{this.state.files[i].name}</div>
            <div className="file-size-icon"><p className="file-size">{this.bytesToSize(this.state.files[i].size)}</p>
              <span className="glyphicon glyphicon-remove remove-file" onClick={this.removeFile(i)}></span></div>
            <br/></div>);
        }
      }
    }
    return (
        <div className="upload-file" id={id}>
          <div hidden>
            <input type="file" id={click} onChange={this.onUpload} multiple
                   accept=".doc, .docx, .xlsx, .pptx, .rtf, .txt, .xml, .xls, .ppt, .png, .jpg, .gif, .mp4, .pdf, .zip, .7z, .zip.*, .7z.*"/>
          </div>
          <div className="upload-drop-zone">
            <img className="cloud-icon" src={Cloud_Ic}/>
            <div className="upload-file-drop">Drop {fileType} here or <a className="upload-file-browse" id="button_file"
                                                                         onClick={this.upload}>Browse</a></div>
          </div>
          {this.state.isShowDialog === true && <div className="upload-image-drag-on">File(s) dragovered</div>}
          <div className="files-list">{fileName}</div>
        </div>
    );
  }
}

export default UploadFile;