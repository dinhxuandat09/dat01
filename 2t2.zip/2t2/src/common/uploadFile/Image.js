import React from 'react'
import '../../public/styles/commons/uploadFile/uploadFile.scss';
import Ic_Delete from '../../public/images/icons/ic_del.png';

class Image extends React.Component {

  constructor(props) {
    super(props);
  }

  removeImage = () => {
    this.props.removeImg(this.props.ind)
  };

  render() {
    const { src } = this.props;
    return (
      <div className="images">
        <div className="thumbnail-image">
          <img src={src} alt="image" />
        </div>
        <img  className="remove-icon" src={Ic_Delete} onClick={this.removeImage}/>
      </div>
    );
  };
}
export default Image;