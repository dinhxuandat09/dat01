import { isUndefinedOrNull, isFunction } from 'lodash';
import {makeGetRequest, makePostRequest, makeDeleteRequest, makePutRequest} from '../utils/cuiResource';


export function getTestCaseByTCSuit(data, successCallBack, failCallBack) {
  let config = {
    url: 'api/test-cases/getAll',
    params: {
      testSuitId:'',
      sortBy: null,
      orderBy: 'descending',
      pageNum: 0,
      pageSize: 8
    }
  };
  config.params = Object.assign({}, config.params, data);
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}

export function uploadTestCases (data, successCallback, failCallback) {
  let config = {
    url: '/api/test-cases/upFile',
    params: {
      moduleName: data.moduleName,
      testSuitId: data.testSuitId,
      acceptDelete: data.acceptDelete
    },
    data: data.file
  };
  makePostRequest(config, (response) => {
    successCallback(response);
  }, (error) => {
    failCallback(error);
  });
}

export function deleteTestCase (ids, acceptDelete, successCallback, failCallback) {
  let config = {
    url: '/api/test-cases',
    params: {
      ids: ids,
      acceptDelete : acceptDelete
    }
  };
  makeDeleteRequest(config, (response) => {
    successCallback(response);
  }, (error) => {
    failCallback(error);
  });
}

export function exportTestCasesList(data, successCallBack, failCallBack) {
  let config = {
    url: 'api/test-cases/export',
    params: {
      testSuitId:data.testSuitId
    },
    headers: {'Content-Type': "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"},
    responseType: "arraybuffer"
  };
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}

export function getListSetting(successCallBack, failCallBack) {
  let config = {
    url: 'api/settings'
  };
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}

export function getListTestSuite(params, successCallBack, failCallBack) {
  let config = {
    url: 'api/test-suits/search',
    params: params
  };
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}

export function updateListSetting (data, successCallback, failCallback) {
  let config = {
    url: 'api/settings',
    data: data
  };
  makePostRequest(config, (response) => {
    successCallback(response);
  }, (error) => {
    failCallback(error);
  });
}

export function addNewTestSuite (data, successCallback, failCallback) {
  let config = {
    url: 'api/test-suits',
    data: data
  };
  makePostRequest(config, (response) => {
    successCallback(response);
  }, (error) => {
    failCallback(error);
  });
}

export function updateTestCase (data, successCallback, failCallback) {
  let config = {
    url: 'api/test-cases',
    data: data
  };
  makePutRequest(config, (response) => {
    successCallback(response);
  }, (error) => {
    failCallback(error);
  });
}

export function getListSuggest(data,successCallBack, failCallBack) {
  let config = {
    url: 'api/test-cases/suggest',
    params: {
      testCaseID: data.testCaseID,
      type: data.type,
      query: data.searchKey
    }
  };
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}

export function updateTestSuite (params, successCallback, failCallback) {
  let config = {
    url: 'api/test-suits',
    data: params
  };
  makePutRequest(config, (response) => {
    successCallback(response);
  }, (error) => {
    failCallback(error);
  });
}
