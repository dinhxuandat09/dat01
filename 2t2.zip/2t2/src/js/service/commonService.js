import { isUndefinedOrNull, isFunction } from 'lodash';
import {makeGetRequest} from '../utils/cuiResource';


export function getModel(data, successCallBack, failCallBack) {
  let config = {
    url: 'api/models',
    params: {
      sortBy: null,
      orderBy: 'descending',
      pageNum: 0,
      pageSize: null
    }
  };
  config.params = Object.assign({}, config.params, data);
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}

export function getTypeByModel(data, successCallBack, failCallBack) {
  let config = {
    url: 'api/models/type/modules',
    params: {
      sortBy: null,
      orderBy: 'descending',
      pageNum: null,
      pageSize: null,
      modelId: null,
    }
  };
  config.params = Object.assign({}, config.params, data);
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}

export function getModulesByModel(data, successCallBack, failCallBack) {
  let config = {
    url: 'api/modules',
    params: {
      sortBy: null,
      orderBy: 'ascending',
      pageNum: null,
      pageSize: null,
      modelId: null,
      moduleName: null,
      type: null
    }
  };
  config.params = Object.assign({}, config.params, data);
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}

export function getVersionByModule(data, successCallBack, failCallBack) {
  let config = {
    url: 'api/versions',
    params: {
      sortBy: null,
      orderBy: 'descending',
      pageNum: null,
      pageSize: null,
      moduleId: null,
      moduleName: null,
      versionName: null
    }
  };
  config.params = Object.assign({}, config.params, data);
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}

export function getTcSuitByModel (data, successCallBack, failCallBack) {
  let config = {
    url: 'api/test-suits/search',
    params: {
      sortBy: null,
      orderBy: 'descending',
      pageNum: null,
      pageSize: null,
      modelId: null,
      moduleId: null,
      versionId: null,
    }
  };
  config.params = Object.assign({}, config.params, data);
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}

export function getServerFromBinary(data, successCallBack, failCallBack) {
  let config = {
    url: 'api/build-logs/lastest',
    params: {
      modelId: null,
      versionId: null,
      pageNum: null,
      pageSize: null,
      moduleId: null,
    }
  };
  config.params = Object.assign({}, config.params, data);
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}