import { isUndefinedOrNull, isFunction } from 'lodash';
import {makeGetRequest, makePostRequest} from '../../utils/cuiResource';

export function getAllCheckBuilFromBinary(data, successCallBack, failCallBack) {
    let config = {
      url: 'api/build-logs/lastest',
      params: {
        modelId: null,
        versionId: null,
        pageNum: null,
        pageSize: 10,
        moduleId: null,
      }
    };
    config.params = Object.assign({}, config.params, data);
    makeGetRequest(config, (response) => {
      successCallBack(response);
    }, (error) => {
      failCallBack(error);
    })
  }
export function checkQuickBuild(data,successCallBack,failCallBack){
  let config={
    url:'/api/qb/getQbId',
    params:{
      path:data,
    }
  };
  makeGetRequest(config,(response)=>{successCallBack(response);},(error)=>{failCallBack(error);})
};
export function builFromBinary(data, successCallBack, failCallBack) {
  let config = {
    url: '/api/build-logs',
    data: {
      modelId: null,
      moduleId: null,
      server: null,
      versionId: null
    }
  };
  config.data = Object.assign({}, config.data, data);
  makePostRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}