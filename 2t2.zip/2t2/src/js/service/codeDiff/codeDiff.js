import { isUndefinedOrNull, isFunction } from 'lodash';
import { makeGetRequest, makePostRequest } from '../../utils/cuiResource';

export function createCodeDiff(data, successCallBack, failCallBack) {
  let config = {
    url: '/api/reports',
    data: {
      codeDiffDTO: {},
      modelId: data.appModelId,
      moduleId: data.moduleId,
      name: data.name,
      type: data.type,
      versionId:data.targetVersionId
    }
  };
  config.data.codeDiffDTO = Object.assign({}, config.data.codeDiffDTO, data);
  makePostRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}

export function getAllCodeDiff(data, successCallBack, failCallBack) {
  let config = {
    url: '/api/code-diffs/search',
    params: {
      modelId: null,
      searchText: null,
      pageNum: 0,
      pageSize: 10,
      sortBy: 'createdDate',
      sortOrder: 'descending',
      baseVersionId: null,
      targetVersionId: null
    }
  };
  config.params = Object.assign({}, config.params, data);
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}