import React from 'react'
import {DropdownButton, MenuItem} from 'react-bootstrap';
import {connect} from 'react-redux';
import {push} from 'redux-router';
import '../../../public/styles/pages/ComponentDropdown.scss';
class ComponentDropdown extends React.Component {
  constructor(props) {
    super(props);
    this.state =  {
      dropdownIsOpen : false
    }
  }

  toggleDropdown = () => this.setState({dropdownIsOpen: !this.state.dropdownIsOpen});

  selectDropdown = (item) => e =>{
    this.setState({dropdownIsOpen: !this.state.dropdownIsOpen});
    this.props.handleClickItemDropdown(item, this.props.iddropdown);
  };
  render() {
    return (
      <div className={this.props.className}>
        <DropdownButton title={this.props.title} id={this.props.iddropdown} onToggle = {this.toggleDropdown}
                        open = {this.state.dropdownIsOpen} disabled={this.props.listSearchStatus.length === 0 ? true : false}>
          {this.props.listSearchStatus.map((item, index) => {
            return <MenuItem eventKey={index}
                             className={'menu-item'}
                             key={'sub-item'+index}
                             onClick={this.selectDropdown(item)}
                             target="_blank">{item.title}</MenuItem>;
          })}
        </DropdownButton>
      </div>
    );
  }
}


export default ComponentDropdown;