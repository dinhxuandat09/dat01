import css from '../../../../public/styles/commons/loading/LoadingService.scss';
import $ from 'jquery';

let isLoading = false;
export function show(content) {
  let message = '<div class="progress-background" id="progress-icon"><div class="icon-background">'
    + '<div class="global-progress-title">' + content + '</div>'
    + '<div class="global-progress-icon img spinner big" style="background: url(\'./images/icons/img_loading.gif\') no-repeat"></div></div></div>';
  if (!isLoading) {
    isLoading = !isLoading;
    $(document.body).append(message);
  }
};
export function hide() {
  if (isLoading) {
    isLoading = !isLoading;
    $('#progress-icon').remove();
  }
};