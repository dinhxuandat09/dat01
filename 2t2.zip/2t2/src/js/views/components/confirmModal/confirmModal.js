import {Modal,Button} from 'react-bootstrap';
import  React from "react";
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import '../../../../public/styles/commons/alertModal/AlertModal.scss';
import {closeModal} from "../../../actions/share";

class ConfirmModal extends React.Component {
  constructor(props) {
    super(props);
  }
  close = () => {
    this.props.hideModal();
    this.props.failCallBack();

  };

  confirm = () => {
    this.props.hideModal();
    this.props.successCallBack();
  };

  render() {
    return (
      <div className="alert-popup-container">
        <Modal dialogClassName="alert-modal" show={this.props.isShow} onHide={this.close}>
          <Modal.Header>{this.props.title}</Modal.Header>
          <Modal.Body>
            <div>{this.props.message}</div>
          </Modal.Body>
          <Modal.Footer>
            <button className="btn btn-default" onClick={this.close}>Close</button>
            <button className="btn btn-primary" onClick={this.confirm} disabled={this.props.disableSubmitBtn}>{this.props.submitText}</button>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}
ConfirmModal.defaultProps = {
  submitText: 'OK',
  successCallBack: () => {},
  failCallBack: () => {}
};
const mapStateToProps= function (state) {
  return ({
    isShow: state.application.share.confirmModal.isShow,
    message: state.application.share.confirmModal.message,
    title: state.application.share.confirmModal.title,
    successCallBack: state.application.share.confirmModal.successCallBack,
    failCallBack: state.application.share.confirmModal.failCallBack,
    disableSubmitBtn: state.application.share.confirmModal.disableSubmitBtn,
    submitText: state.application.share.confirmModal.submitText,
  });
};

const mapDispatchToProps = function (dispatch) {
  return({
    hideModal: () => {
      dispatch(closeModal());
    }
  })
};

export default connect(mapStateToProps,mapDispatchToProps)(ConfirmModal);