import React from 'react';

export default class TextArea extends React.Component {

  constructor(props, context) {
    super(props, context);

    // Set initial State
    this.state = {
      value: this.props.item.value,
    };

    this.onChange = this.onChange.bind(this);
  }

  onChange(e){
    const value = e.target.value;
    this.setState({
      value: value
    });
    this.props.setNewValueForTc(this.props.item.code, value);
  }

  render() {
    return (
      <div className="text-area-box">
        <label>{this.props.item.name}</label>
        <textarea className="tc-textarea" onChange={this.onChange} value={this.state.value||''}></textarea>
      </div>
    );
  }
}
