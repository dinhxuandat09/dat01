import React from 'react'
import {DropdownButton, MenuItem} from 'react-bootstrap';
import {connect} from 'react-redux';
import {push} from 'redux-router';
import '../../../public/styles/pages/ComponentPagination.scss';
import UltimatePagination from "react-ultimate-pagination-bootstrap-4";
class ComponentPagination extends React.Component {
  constructor(props) {
    super(props);
    this.state =  {
        dropdownIsOpen : false
    }
  }
  render() {
      let pageNum ;
    if((this.props.pageNum+1)*10 > this.props.totalCount){
         pageNum = this.props.totalCount;       
    }else{
         pageNum = (this.props.pageNum+1)*10;
    }
    return (
      <div>
         <div className="total-pagination">
             {this.props.pageNum*10+1} - {pageNum}  of  {this.props.totalCount}
         </div>
         <UltimatePagination
                currentPage={this.props.currentPage}
                totalPages={this.props.totalPages}
                onChange={this.props.onChange}
              />
       </div>
    );
  }
}


export default ComponentPagination;