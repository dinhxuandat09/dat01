import React from 'react';
import {connect} from "react-redux";
import {push} from "redux-router";
import onClickOutside from "react-onclickoutside";
import '../../../../public/styles/pages/CIATable.scss';
import '../../../../public/styles/pages/PickModelListComponent.scss';
import * as commonService from '../../../service/commonService';
import {Modal, Button} from 'react-bootstrap';
import UltimatePagination from "react-ultimate-pagination-bootstrap-4";
import {showProgress, hideProgress} from '../../../actions/share';
import Ic_Close from '../../../../public/images/icons/ic_close_black.png'
import {setTimeout, clearTimeout} from 'timers';

let CIAModuleData = {
  pageSize: 8,
  pageNum: 0
};

class PickModuleListComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      listModule: [],
      currentPage: 1,
      TotalPage: 1,
      searchText: '',
      showModuleList: false
    }
    if (this.props.moduleInit) {
      this.state = {
        ...this.state,
        searchText: this.props.moduleInit
      }
    }
  }

  componentWillMount() {
    CIAModuleData.moduleName = null;
    CIAModuleData.pageNum = 0;
    this.getListModule(CIAModuleData);
    if(this.props.moduleName){
      this.setState({
        searchText: this.props.moduleName
      })
    }
  };

  componentWillReceiveProps(nextProps) {
    if (nextProps.modelId !== this.props.modelId  || nextProps.type !== this.props.type) {
      this.setState({
        searchText: ''
      });
      CIAModuleData.moduleName = null;
      if (nextProps.modelId === '') {
        CIAModuleData.modelId = null;
        CIAModuleData.type = null;
        this.getListModule(CIAModuleData);
      }
      if (nextProps.type && nextProps.modelId) {
        CIAModuleData.modelId = nextProps.modelId;
        CIAModuleData.type = nextProps.type;
        this.getListModule(CIAModuleData);
      }
    }
  }

  getAllListModule() {
    this.setState({
      searchText: ''
    });
    CIAModuleData.modelId = '';
    CIAModuleData.type = '';
    this.getListModule(CIAModuleData);
  };

  getListModule = (data) => {
    commonService.getModulesByModel(data, (res) => {
      this.setState({
        listModule: res.data.value.list,
        TotalPage: Math.ceil(res.data.value.totalCount / 8) !== 0 ? Math.ceil(res.data.value.totalCount / 8) : 1
      });
    }, (error) => {
    });
  };

  handlePickModule = (item) => e => {
    this.setState({
      searchText: item,
      showModuleList: false
    });
    this.props.pickModule(item);
    CIAModuleData.pageNum = 0;
    this.setState({
      currentPage: 1
    });
    CIAModuleData.moduleName = item;
    this.getListModule(CIAModuleData);
  };

  handleChangePage = (page) => {
    this.setState({
      currentPage: page
    });
    CIAModuleData.pageNum = page - 1;
    this.getListModule(CIAModuleData);
  };
  clearTimeoutModule = () => {
    clearTimeout(this.timeoutModule);
    this.timeoutModule = null;
  }
  handleChangeSearchText = () => e => {
    this.setState({
      searchText: e.target.value
    });
    CIAModuleData.moduleName = e.target.value;
    this.clearTimeoutModule();
    clearTimeout(this.timeoutModule);
    let textSearch = e.target.value
    this.timeoutModule = setTimeout( () => {
      this.handleSearchModule(textSearch);
    }, 250);

    if (!e.target.value) {
      //this.props.clearDataWithEmptyModule();
    }
  };

  handleSearchModule = (value) => {
    CIAModuleData.pageNum = 0;
    this.setState({
      currentPage: 1
    });
    this.getListModule(CIAModuleData);
    this.props.pickModule(value);
  };

  openModalModuleList = () => {
    this.setState({
      showModuleList: true
    });
  };

  handleClickOutside = () => {
    this.setState({ showModuleList: false });
  };

  close = () => {
    this.setState({
      showModuleList: false
    })
  };
  render() {
    return (
      <div>
        <input type="text" className="cia-text" id="input-component-module"
               disabled={this.props.disabled}
               onClick={this.openModalModuleList}
               value={this.state.searchText}
               onPaste={this.handleChangeSearchText()}
               onChange={this.handleChangeSearchText()}
               placeholder="Enter Module Name"
        />
        {this.state.showModuleList &&
        <div className={`model-list-container popup-module ${!this.state.listModule || this.state.listModule.length == 0 ? "show-warning" : ""}`}
             onClick={(e) => e.stopPropagation()}>
          <div className="model-list-body-container">
            {this.state.listModule && this.state.listModule.length > 0 &&
            <div className="table-wrapper">
              <table className="table table-striped">
                <tbody>
                <tr className="table-header">
                  <th className="text-center">Module Name</th>
                </tr>
                {this.state.listModule.map((item, idx) => {
                  return <tr key={idx} onClick={this.handlePickModule(item)}>
                    <td className="padding-15">{item}</td>
                  </tr>;
                })}
                </tbody>
              </table>
              <UltimatePagination
                currentPage={this.state.currentPage}
                totalPages={this.state.TotalPage}
                onChange={this.handleChangePage}
              />
            </div>
            }
            {!this.state.listModule || this.state.listModule.length == 0 &&

            <div className="empty-data"><span className="text-center">Data do not exist ! Please input again</span>
            </div>}
          </div>
        </div>
        }
      </div>
    );
  }
}

PickModuleListComponent.defaultProps = {
  disabled: false,
};

const mapDispatchToProps = dispatch => {
  return {
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    }
  };
};

export default connect(null, mapDispatchToProps)(onClickOutside(PickModuleListComponent));