import React from "react";
import { connect } from "react-redux";
import { push } from "redux-router";
import "../../../../public/styles/commons/LeftNavigationBar/MainLeftSidebar.scss";
import "../../../../public/styles/commons/LeftNavigationBar/CollectionSidebar.scss";
import { makeGetRequest } from "../../../utils/cuiResource";
import { setListCategory } from "../../../actions/share";
import SVMCIcon from "../../../../public/images/icons/logo_svmc.png";
import {showAlert} from "../../../../js/actions/share";
import AlertModal from '../../../../js/views/components/alertModal/AlertModal'
import { router } from "react-router/lib/PropTypes";

class MainLeftSidebar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      menuItems: [
        {
          text: "HOME",
          path: "/Home"
        },
        {
          text: "Build Test Binary",
          path: "/BuildTestBinary"
        },
        {
          text: "Upload Test Log",
          path: "/UploadTestLog"
        },
        {
          text: "Code Diff",
          path: "/CodeDiff"
        },
        {
          text: "CIA Report",
          path: "/CIAReport"
        },
        {
          text: "TC Management",
          path: "/TCManagement"
        },
        {
          text: "Community",
          path: "/Community"
        }
      ]
    };
    this.createMenuItems = this.createMenuItems.bind(this);
  }

  componentDidMount() {
    this.state.menuItems.map((item, indx) => {
      this.props.router.location.pathname === item.path ? document.getElementById(item.path).classList.add("change-page") : document.getElementById(item.path).classList.remove("change-page");
    })
  };

  handleClickMenuItem = (path) => () => {
    if(path === '/Home') {
      this.props.showAlert("Under Development");
    }if( path ==='/Community'){
      window.open('http://mosaic.sec.samsung.net/kms/ciatool.club', '_blank'); 
    } 
    else {
      this.state.menuItems.map((item, indx) => {
        path === item.path ? document.getElementById(item.path).classList.add("change-page") : document.getElementById(item.path).classList.remove("change-page");
      });
      this.props.redirectPage(path);
    }
  };

  createMenuItems(listMenu) {
    return listMenu.map((item, index) => (
      <div className="menu-item" id={item.path} key={index} onClick={this.handleClickMenuItem(item.path)}>
        <img src={item.icon} className={`menu-icon-${index}`} />
        {item.text}
      </div>
    ));
  }

  render() {
    return (
      <div className="main-left-sidebar">
        <AlertModal />
        <div className="menu-list">
          {this.createMenuItems(this.state.menuItems)}
          <img src={SVMCIcon} className="svmc-icon" alt="SVMC icon" />
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  application: state.application,
  router: state.router,
  listCategory: state.application.share.listCategory,
  permissions: state.application.system.user.permissions,
});

const mapDispatchToProps = dispatch => {
  return {
    redirectPage: url => {
      dispatch(push(url));
    },
    setListCategory: (list = []) => {
      dispatch(setListCategory(list));
    },
    showAlert: (message) => {
      dispatch(showAlert(message));
    },
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(MainLeftSidebar);

const MENU_ITEM = [];