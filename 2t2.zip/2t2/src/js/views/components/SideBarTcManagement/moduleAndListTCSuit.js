import React from "react";
import {Modal} from 'react-bootstrap';
import ic_arrow from "../../../../public/images/icons/ic_arrow.png";
import {getTcSuitByModel} from '../../../service/commonService';
import '../../../../public/styles/commons/alertModal/AlertModal.scss';

class ModuleAndTCSuit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      TCSuitList: [],
      isOpenListTCSuit: false,
      isContextMenu: false,
      left: 0,
      currentName: '',
      isRename: false,
      isDisable: true,
      value: ''
    };
  }

  componentWillReceiveProps(nextProps) {
    if(nextProps.moduleName !== this.props.moduleName){
      this.setState({
        TCSuitList: [],
        isOpenListTCSuit: false
      })
    }
  }

  switchOpenListTCSuit = () => {
    this.setState((prevState) => ({
      isOpenListTCSuit: !prevState.isOpenListTCSuit
    }));
    if(this.state.TCSuitList.length <= 0)
      this.getTCSuiteByModuleName();
  };
  getTCSuiteByModuleName = () => {
    let data = {
      moduleName: this.props.moduleName
    };
    getTcSuitByModel(data, (res) => {
      this.setState({
        TCSuitList: res.data.list
      })
    }, (error) => {
    });
  };
  showListTCSuit = (listTC) => {
    if(listTC){
      return listTC.map((item, index) => (
        <div className="tc-item" key={index}
             onClick={this.returnTCSuitId(item.id, 'click', item.name)}
             onContextMenu={this.returnTCSuitId(item.id, 'context', item.name)}>
          {item.name}
        </div>
      ));
    }
  };
  returnTCSuitId = (id, type, name) => (e)=> {
    e.preventDefault();
    if(type === 'click') this.props.getTCSuitId(id);
    else {
      this.setState({ isContextMenu : true, left: e.pageX - 330, currentName: name });
    }
  };
  onClickModuleItem = (type) => ()=> {
    if(type === 'rename') {
      this.setState({ isRename: true, isContextMenu : false, left: 0 });
    } else {
      //implement delete item
      this.setState({ isContextMenu : false, left: 0 });
    }
  };
  onChange = () => (e) => {
    if(e.target.value.trim() !== '') {
      this.setState({ isDisable: false, value: e.target.value.trim() });
    } else {
      this.setState({ isDisable: true });
    }
  };
  onClick = (type) => {
    if(type === 'close') this.setState({ isRename: false });
    else {
      this.setState({ isRename: false });
      //implement rename action
    }
  };
  render() {
    return (
      <div className="main-menu-title">
        <img src={ic_arrow} className={`${this.state.isOpenListTCSuit && 'rotate-90'}`} onClick={this.switchOpenListTCSuit}/>
        <span>{this.props.moduleName}</span>
        {(this.state.TCSuitList.length > 0 && this.state.isOpenListTCSuit) && this.showListTCSuit(this.state.TCSuitList)}
        {this.state.isContextMenu &&
          <ul className="custom-menu" style={{ left: this.state.left}}>
            <li onClick={this.onClickModuleItem('rename')}>Rename</li>
            <li onClick={this.onClickModuleItem('delete')}>Delete</li>
          </ul>
        }
        {this.state.isRename &&
          <div className="alert-popup-container">
            <Modal dialogClassName="alert-modal" show={true} onHide={() => this.onClick('close')}>
              <Modal.Header>Rename</Modal.Header>
              <Modal.Body>
                <div className="content-modal-container">
                    <div className="text-content-modal">Current name:</div>
                    <input className="input-container" type="text" value={this.state.currentName} readOnly/>
                  <div className="new-name-container">
                    <div className="text-content-modal">New name:</div>
                    <input className="input-container" type="text" autoFocus onChange={this.onChange()}/></div>
                </div>
              </Modal.Body>
              <Modal.Footer>
                <button className="btn btn-default" onClick={() => this.onClick('close')}>Close</button>
                <button className="btn btn-primary" onClick={() => this.onClick('ok')} disabled={this.state.isDisable}>Rename</button>
              </Modal.Footer>
            </Modal>
          </div>
        }
      </div>
    )
  }
}

export default ModuleAndTCSuit;