import React from "react";
import {connect} from 'react-redux';
import {push} from "redux-router";
import image_search from "../../../../public/images/icons/ic_search.png";
import ic_arrow from "../../../../public/images/icons/ic_arrow.png";
import * as commonService from '../../../service/commonService';
import ModuleAndListTCSuit from './moduleAndListTCSuit';

//import '../../../../public/styles/commons/LeftNavigationBar/CollectionSidebar.scss';

class SideBarTcManagement extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      searchText: '',
      moduleList: [],
      isOpenListModule: false
    };
  }
  componentWillMount () {
    let data = {
      moduleName: ''
    };
    this.getListModule(data);
  }
  getListModule = (data) => {
    commonService.getModulesByModel(data, (res) => {
      this.setState({
        moduleList: res.data.value.list
      });
    }, (error) => {
    });
  };

  handleChangeSearchText = (e) => {
    this.setState({
      searchText: e.target.value,
    });
  };

  createSideBarItem = (listItem) => {
    if(listItem){
      return listItem.map((item, index) => (
          <ModuleAndListTCSuit moduleName={item} key={index} getTCSuitId={this.props.getTCSuitId}/>
      ));
    }
  };

  handleClickMainMenuItem = (id) => e => {
    let sideBarItem = [];
    this.state.moduleList.map((item, index) => {
      item.showTC = item.id === id;
      sideBarItem.push(item);
    });
    this.setState({
      moduleList: sideBarItem
    })
  };

  handleSearch = () =>{
    let data = {
      moduleName: this.state.searchText
    }
    this.getListModule(data);
  };
  onEnter = (e) =>{
    const key = e.which || e.keyCode;
    if(key === 13){
      this.handleSearch();
    }
  }
  switchOpenListModule = () => {
    this.setState((prevState) => ({
      isOpenListModule: !prevState.isOpenListModule
    }))
  }

  render() {
    return (
      <div className="TC-management-sideBar">
        <div className="search-module-box">
        <img src={ic_arrow} className={this.state.isOpenListModule ? 'rotate rotate-90':'rotate'} onClick={this.switchOpenListModule}/>
          <span>MODULE</span>
          <input type="text" className="cia-text tc-search-box"
                 value={this.state.searchText} onChange={this.handleChangeSearchText}
                 onKeyDown={this.onEnter}
                 placeholder="Search Module"
          />
          <img className="search-icon" src={image_search} width={22} height={22} onClick={this.handleSearch} />
        </div>
        {
          this.state.isOpenListModule &&
          <div className="module-list">
            {this.createSideBarItem(this.state.moduleList)}
          </div>
        }
      </div>
    )
  }
}

export default SideBarTcManagement;