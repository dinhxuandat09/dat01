import React from 'react';
import {getListSuggest} from '../../../service/TCManagementService';

export default class AutoCompleteText extends React.Component {

  constructor(props, context) {
    super(props, context);

    // Set initial State
    this.state = {
      value: this.props.item.value,
      autocompleteData: []
    };

    this.onChange = this.onChange.bind(this);
    this.retrieveData = this.retrieveData.bind(this);
  }
  componentDidUpdate() {
    if(this.state.autocompleteData.length > 0)
      document.addEventListener('click',this.removeListSuggest)
    else document.removeEventListener('click',this.removeListSuggest)
  }
  componentWillUnmount(){
    document.removeEventListener('click',this.removeListSuggest)
  }
  removeListSuggest=()=>{
    this.setState({autocompleteData: []})
  }
  retrieveData(searchText){
    // get list data from api
    // using this.props.item.value for url
    let data = {
      testCaseID: this.props.testCaseID,
      type: this.props.item.code,
      searchKey: searchText
    }
    getListSuggest(data, (res)=>{
      this.setState({autocompleteData: res.data})
    },(eror)=>{})
  }

  onChange(e){
    const value = e.target.value;
    this.setState({
      value: value
    });
    this.props.setNewValueForTc(this.props.item.code, value);
    if(!value){
      this.removeListSuggest();
    }
    else
      this.retrieveData(value);
  }

  onSelect = (val) => () =>{
    this.setState({
      value: val
    });
    this.props.setNewValueForTc(this.props.item.code, val);
  }

  render() {
    return (
      <div className="auto-complete-text">
        <label>{this.props.item.name}</label>
        <input type="text" className="cia-text"
               value={this.state.value} onChange={this.onChange}
        />
        {this.state.autocompleteData && this.state.autocompleteData.length > 0 &&
        <div className="list-suggest">
          {this.state.autocompleteData.map((item, idx) => {
            return <div className="suggest-item" key={idx} onClick={this.onSelect(item)}>{item}</div>
          })}
        </div>
        }
      </div>
    );
  }
}
