import React from 'react'
import '../../../../public/styles/commons/searchBar/searchBar.scss';
import { makeGetRequest, makePostRequest } from '../../../utils/cuiResource';
import { showProgress, hideProgress, addFunctionSetSearchText } from "../../../actions/share";
import ProgressModal from '../progressModal/ProgressModal';
import { connect } from "react-redux";
import { push } from 'redux-router';
import image_search from "../../../../public/images/icons/ic_search.png";
import btnDownload from "../../../../public/images/icons/btnDownload.png";
import { fail } from 'assert';

let inputText;
class SearchBar extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      inputText: inputText || '',
      path: ["/Home", "/BuildTestBinary", "/UploadTestLog", "/CodeDiff", "/CIAReport", "/TCManagement", "/Community"]
    }
  }
 
  onChange = (e) => {
    this.setState({
      inputText: e.target.value,
      showbtnRemove : true
    });
    inputText = e.target.value;
  };
  componentDidMount() {
    this.state.path.map((item, indx) => {
      this.props.router.location.pathname === item ? document.getElementById(item).classList.add("change-page") : document.getElementById(item).classList.remove("change-page");
    });
  };
  handleSearch = (e) => {
    this.props.redirectPage('/Search/' + this.state.inputText);
  }

  handleEnterSearch = (e) => {
    const key = e.which || e.keyCode;
    const ENTER = 13;
    if(key === ENTER)
      this.handleSearch();
  };

  handleDownload = () =>{
    let url = '/api/files/apk';
    let iframe=document.createElement("iframe");
    iframe.style.display="none";
    iframe.src=url;
    document.body.appendChild(iframe);
  };

  removeSearchText = () => {
    inputText = '';
    this.setState({
      inputText: ''
    });
  };

  render() {
    return (
      <div className="search-bar">
        <ProgressModal />
        <input className="form-control search-input" placeholder="Search here"
          value={this.state.inputText} type="text"
          onKeyDown={this.handleEnterSearch}
          onChange={this.onChange}/>
        {this.state.inputText && <button className="remove-text-input" type="text" onClick={this.removeSearchText}>X</button>}
        <button type="button" className="btn btn-default search-btn" onClick={this.handleSearch}>
          <img src={image_search} width={32} height={32} ></img>
        </button>
        <button type="button" className="btn btn-default search-btn" onClick={this.handleDownload}>
          <img src={btnDownload} width={32} height={32} ></img>
        </button>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  router: state.router,
});

const mapDispatchToProps = dispatch => {
  return {
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    },
    redirectPage: url => {
      dispatch(push(url));
    },
    addFunctionSetSearchText: (func) => {
      dispatch(addFunctionSetSearchText(func))
    }
  };
};


export default connect(mapStateToProps, mapDispatchToProps)(SearchBar);