import React from "react";
import {connect} from 'react-redux';

class DragAndDrop extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isDragActive: false,
      fileName: null
    };
  }

  onDragLeave = () => {
    this.setState({
      isDragActive: false
    });
  };
  onDragOver =  (e)=> {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';

    this.setState({
      isDragActive: true
    });
  };
  onDrop = (e)=> {
    e.preventDefault();

    this.setState({
      isDragActive: false
    });

    var files;
    if (e.dataTransfer) {
      files = e.dataTransfer.files;
    } else if (e.target) {
      files = e.target.files;
    }
    if (files && files.length > 0) {
      this.setState({
        fileName: files[0].name
      })
      let form = new FormData();
      form.append("file", files[0], files[0].name);
      this.props.returnFile(form);
    }
  }
  onClick = () => {
    document.getElementById('uploadTestCaseFile').click();
  };

  render() {
    let content = <span>Drop zone</span>;
    if(this.state.fileName)
      content = <span>{this.state.fileName}</span>
    else content = this.props.children;
    return(
    <div className={`cia-text ${this.state.isDragActive ? "show-active-dropzone" : ""}`} onClick={this.onClick} onDragLeave={this.onDragLeave} onDragOver={this.onDragOver} onDrop={this.onDrop}>
      <input style={{display: 'none' }} type="file" multiple id="uploadTestCaseFile" onChange={this.onDrop}/>
      {content}
    </div>
    )
  }
}
export default DragAndDrop;