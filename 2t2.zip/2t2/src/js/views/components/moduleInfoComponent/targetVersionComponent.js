import React from 'react';

class TargetVersionComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      valueInput: '',
      isShowSuggest: false,
      selected: -1,
      listVersionBinary: this.props.targetVersionList
    };
    this.onHandleSuggest = this.onHandleSuggest.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if(nextProps.targetVersionList !== this.props.targetVersionList || !nextProps.versionId)
      this.setState({
        listVersionBinary: nextProps.targetVersionList,
        valueInput:'',
        selected: -1
      })
  }

  componentDidUpdate() {
    if(this.state.isShowSuggest) {
      document.addEventListener('click',this.closePopUp)
    }
    else
      document.removeEventListener('click', this.closePopUp);
  }
  componentWillUnmount() {
    document.removeEventListener('click', this.closePopUp);
  }

  closePopUp = () => {
    this.setShowSuggest(false);
  }

  setShowSuggest = (isShow)  => {
    this.setState({
      isShowSuggest: isShow
    })
  };

  openVersionList = () => {
      this.setShowSuggest(true);
  };

  onHandleSuggest(e) {
    this.setState({
      isShowSuggest: true,
      valueInput: e.target.value
    });
    if (e.target.value) {
      if (this.props.versionId) {
        this.getVersionByModule(e.target.value);
      }
    }
    else {
      this.setState({
        listVersionBinary: this.props.targetVersionList
      })
    }
  };

  onHandleClick = (item) => e => {
    this.setState({
      valueInput: item.version,
      selected: item.id
    });
    this.setShowSuggest(false);
    this.props.pickVersion(item);
  };

  getVersionByModule = (versionName) => {
    let versionList = [];
    for (let i = 0; i < this.props.targetVersionList.length; i++) {
      if (this.props.targetVersionList[i].id !== this.props.versionId &&
          this.props.targetVersionList[i].version.indexOf(versionName) !== -1) {
        versionList.push(this.props.targetVersionList[i]);
      }
    }
    this.setState({
      listVersionBinary: versionList
    })
  };

  render() {
    return (
        <div className=" medium col-lg-3 module-info-component-wrapper">
          <span className=" padding-0 cia-label">{this.props.title}</span>
          <input ref={nodeInput => this.nodeInput = nodeInput} className="form-control input-module"
                 onChange={this.onHandleSuggest} value={this.state.valueInput}
                 onClick={this.openVersionList} placeholder='Select version' />
          {this.state.listVersionBinary.length > 0 && this.state.isShowSuggest && <ul className="search-suggest">
            {this.state.listVersionBinary.map((item, index) => <li
                className={this.state.selected == item.id ? "search-item selected-item" : "search-item"}
                key={'module-item' + index} onClick={this.onHandleClick(item)}>{item.version}</li>)
            }
          </ul>}
        </div>
    );
  }
}

export default TargetVersionComponent;