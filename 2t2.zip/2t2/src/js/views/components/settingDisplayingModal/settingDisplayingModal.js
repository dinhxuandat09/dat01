/**
 * Created by sev_user on 1/16/2018.
 */
import {Modal,Button} from 'react-bootstrap';
import  React from "react";
import {connect} from 'react-redux';
import '../../../../public/styles/commons/alertModal/AlertModal.scss';
import Checkbox from './Checkbox';

let listItemSelected = [];
class SettingDisplayingModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }
  componentWillMount() {
    listItemSelected = this.props.listSetting;
  }
  close = () => {
    this.props.showSettingDisplay(false)();
  };

  confirm = (e) => {
    e.preventDefault();
    this.props.setNewListFromSetting(listItemSelected);
    this.props.showSettingDisplay(false)();
  };
  toggleCheckbox = (index) => {
    if (listItemSelected[index].value) {
      listItemSelected[index].value = false;
    } else {
      listItemSelected[index].value = true;
    }
  };
  generateItem = () =>{
    return (
    this.props.listSetting.map((item, index)=>{
      return(
      <Checkbox
        item={item}
        handleCheckboxChange={this.toggleCheckbox}
        key={index}
      />
      )
    }))
  }

  render() {
    return (
      <div className="alert-popup-container">
        <Modal dialogClassName="alert-modal setting-display" show={true}>
          <Modal.Header>Setting up displaying</Modal.Header>
          <Modal.Body>
            {this.generateItem()}
          </Modal.Body>
          <Modal.Footer>
            <button className="btn btn-default" onClick={this.close}>Cancel</button>
            <button className="btn btn-primary" onClick={this.confirm}>Save</button>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}

export default SettingDisplayingModal;