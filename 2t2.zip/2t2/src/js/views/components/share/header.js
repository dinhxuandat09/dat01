import React from 'react';
import SearchBar from '../searchBar/searchBar';
import '../../../../public/styles/commons/share/header.scss';
import {makeGetRequest} from '../../../utils/cuiResource';
import ProgressModal from '../progressModal/ProgressModal.js'
import {hideProgress, showProgress} from "../../../actions/share";
import {connect} from "react-redux";

class Header extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <div className="header">
        <ProgressModal/>
        <SearchBar className="search-bar"/>
      </div>
    );
  }
}

const mapDispatchToProps = function (dispatch) {
  return (
    { showProgress: () => {dispatch(showProgress())},
      hideProgress: () => {dispatch(hideProgress())}
    }
  )
}

export default connect(null,mapDispatchToProps) (Header);