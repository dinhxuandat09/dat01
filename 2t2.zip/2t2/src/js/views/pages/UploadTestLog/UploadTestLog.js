import React from 'react';
import { connect } from "react-redux";
import { push } from "redux-router";
import '../../../../public/styles/commons/share/body.scss';
import '../../../../public/styles/pages/UploadTestLog.scss';
import Header from '../../components/share/header';
import { loadToolFunc, reloadToolPage } from "../../../actions/share";
import { showProgress, hideProgress, actionModal, removeDataTransfer } from "../../../actions/share";
import ProgressModal from '../../components/progressModal/ProgressModal';
import { DropdownButton, MenuItem, Button } from 'react-bootstrap';
import * as UploadTestLogService from '../../../service/UploadTestLogService';
import * as commonService from '../../../service/commonService';
import PickModelListComponent from '../../components/pickModelListComponent/pickModelListComponent';
import PickModuleListComponent from '../../components/pickModelListComponent/pickModuleListComponent';
import Ic_Delete from '../../../../public/images/icons/ic_delete1.png';
import Ic_UploadLog from '../../../../public/images/icons/ic_upload.png';
import { showAlert } from "../../../actions/share";
import ComponentPagination from '../../components/ComponentPagination';
import PickVersionListComponent from '../../components/moduleInfoComponent/PickVersionComponent';
import ComponentDropdown from '../../components/ComponentDropdown';
class UploadTestLog extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      typeList: [],
      tcSuitList: [],
      dropdownType: "Select type",
      dropdownTCSuit: "Select TC Suite",
      listTestLog: [],
      currentPage: 1,
      totalPage: 1,
      disabledConfirmBtn: true,
      totalCount: 0,
      versionInfo: {
        version: ''
      },

      disableModel: true,
      disableModule: true,
      disableVersion: true,
      disableTCSuite: true,

      uploadTestLogParams: {
        modelId: null,
        moduleName: '',
        type: '',
        versionId: '',
      }
    };
  }
  componentWillMount() {
    this.setState({ disabledConfirmBtn: true });
    //uploadTestLogParams.pageNum = 0;
    if(this.props.dataTransferCIA && this.props.dataTransferCIA.moduleName) {
      this.transferDataFromProps();
    }
    this.getType();
  };

  changeDataSearch = (keyData, value, objData) => {
    let obj = {};
    if(objData){
      obj = objData
    } else {
      obj[keyData] = value;
    }
    this.setState((prevState) => {
      return {uploadTestLogParams: {...prevState.uploadTestLogParams, ...obj}};
    });
  };

  transferDataFromProps = () => {
    let modelName = null;
    let dropdownType = "Select type";
    let uploadTestLogParams = {};
    uploadTestLogParams.moduleName = this.props.dataTransferCIA.moduleName;
    uploadTestLogParams.versionId = this.props.dataTransferCIA.baseVersion.id;
    if(this.props.dataTransferCIA.model){
      uploadTestLogParams.modelId = this.props.dataTransferCIA.model.value;
      uploadTestLogParams.typeId = this.props.dataTransferCIA.type.value;
      modelName = this.props.dataTransferCIA.model.title;
      dropdownType = this.props.dataTransferCIA.type.value;
    }

    this.setState({
      modelName: modelName,
      dropdownType: dropdownType,
      moduleName: uploadTestLogParams.moduleName,
      versionInfo: this.props.dataTransferCIA.baseVersion,
    }, ()=> {
      this.changeDataSearch(null, null, uploadTestLogParams);
      this.getTcSuit();
      this.props.removeDataTransfer()
    })
  };

  handleSelectModel = (item) => {
    this.changeDataSearch('modelId', item.value);
    //uploadTestLogParams.modelId = item.value;
    this.clearDataModule();
    this.clearDataVersion();
    this.clearDataTCSuit();
  };
  handleSelectType = (item)  => {
    this.setState({
      disableModel: false,
      disableModule: false,
      disableVersion: false,
      disableTCSuite: false,
      dropdownType: item.title,
    });
    this.changeDataSearch('typeId', item.value);
  };
  handleSelectModule = (item) => {
    this.changeDataSearch('moduleName', item);
    this.clearDataVersion();
    this.clearDataTCSuit();
    this.getVersion();
  };

  pickVersion = (item) => {
    this.changeDataSearch('versionId', item.id);
    this.clearDataTCSuit();
    this.getTcSuit();
  };
  handleSelectTCBuilt = (item) => () => {
    this.setState({
      dropdownTCSuit: item.title,
      disabledConfirmBtn: false
    });
    this.changeDataSearch('tcId', item.value);
  };

  clearDataType = () => {
    this.setState({
      dropdownType: "Select type",
      typeList: []
    });
    this.changeDataSearch('typeId', null);
  };

  clearDataModule = () => {
    this.changeDataSearch('moduleName', null);
  };

  clearDataVersion = () => {
    this.changeDataSearch('versionId', null);
  };
  clearDataTCSuit = () => {
    this.setState({
      dropdownTCSuit: "Select TC Suite",
      tcSuitList: [],
      disabledConfirmBtn: true
    });
    this.changeDataSearch('tcId', null);
  };
  handleConfirm = () => {
    this.getAllUploadTestLog();
  };
  handleUploadFile = () => {
    document.getElementById('upload-test-log').click();
  };
  onUpload = () => {
    let file = document.getElementById('upload-test-log').files;
    let filteredFile = Array.prototype.filter.call(file, fi => {
      if (fi.name.includes('.zip')) {
        return fi;
      }
    });
    if (filteredFile && filteredFile.length > 0) {
      let form = new FormData();
      form.append("file", filteredFile[0], filteredFile[0].name);
      let data = {};
      data.file = form;
      data.modelId = this.state.uploadTestLogParams.modelId;
      data.moduleName = this.state.uploadTestLogParams.moduleName;
      data.testSuitId = this.state.uploadTestLogParams.tcId;
      data.versionId = this.state.uploadTestLogParams.versionId;
      if (!data.moduleName || !data.versionId || !this.state.uploadTestLogParams.tcId) {
        this.props.showAlert("Please select all fields Module Name, Version, TC Suite!");
        document.getElementById('upload-test-log').value = null;
        return;
      }
      this.props.showProgress();
      UploadTestLogService.uploadMultiTestLogs(data, (response) => {
        this.props.hideProgress();
        this.props.showAlert("Uploaded successfully");
        this.getAllUploadTestLog();
      }, (error) => {
        this.props.hideProgress();
        this.props.showAlert("Upload fail");
      });
    }

    document.getElementById('upload-test-log').value = null;
  };

  handleUploadSingleLog = () => {
    document.getElementById('upload-single-test-log').click();
  };

  onUploadLog = () => {
    let file = document.getElementById('upload-single-test-log').files;
    let filteredFile = Array.prototype.filter.call(file, fi => {
      if (fi.name.includes('.txt')) {
        return fi;
      }
    });
    if (filteredFile && filteredFile.length > 0) {
      let form = new FormData();
      form.append("file", filteredFile[0], filteredFile[0].name);
      let data = {};
      data.file = form;
      data.modelId = this.state.uploadTestLogParams.modelId;
      data.moduleName = this.state.uploadTestLogParams.moduleName;
      data.versionId = this.state.uploadTestLogParams.versionId;
      data.testSuitId = this.state.uploadTestLogParams.tcId;
      data.versionId = this.state.uploadTestLogParams.versionId;
      if (!data.moduleName || !data.versionId || !this.state.uploadTestLogParams.tcId) {
        this.props.showAlert("Please select all fields Module Name, Version, TC Suite!");
        document.getElementById('upload-single-test-log').value = null;
        return;
      }
      this.props.showProgress();
      UploadTestLogService.uploadTestLog(data, (response) => {
        this.props.hideProgress();
        this.props.showAlert("Uploaded successfully");
        this.getAllUploadTestLog();
      }, (error) => {
        this.props.hideProgress();
        this.props.showAlert("Upload fail");
      });
    }
    document.getElementById('upload-single-test-log').value = null;
  };

  handleDeleteLog = (id) => () => {
    this.props.showProgress();
    UploadTestLogService.deleteLog(id, (response) => {
      this.props.hideProgress();
      this.props.showAlert("Deleted successfully");
      this.getAllUploadTestLog();
    }, (error) => {
      this.props.hideProgress();
      this.props.showAlert("Delete fail");
    });
  };

  getAllUploadTestLog = () => {
    let data = {
      pageSize: 10,
      modelId: this.state.uploadTestLogParams.modelId,
      moduleName: this.state.uploadTestLogParams.moduleName,
      versionId: this.state.uploadTestLogParams.versionId,
      testSuitId: this.state.uploadTestLogParams.tcId,
      pageNum: this.state.uploadTestLogParams.pageNum
    };
    this.props.showProgress();
    UploadTestLogService.getUploadTestLog(data, (response) => {
      this.setState({
        listTestLog: response.data.list,
        totalCount: response.data.totalCount,
        totalPage: Math.ceil(response.data.totalCount / 10) !== 0 ? Math.ceil(response.data.totalCount / 10) : 1
      });
      this.props.hideProgress();
    }, (error) => {
      this.props.hideProgress();
    });
  };

  handleChangePage = (pageNumber) => {
    this.changeDataSearch('pageNum', pageNumber - 1);
    this.setState({
      currentPage: pageNumber
    });
    this.getAllUploadTestLog();
  };

  getType = () => {
    let data = {
      modelId: this.state.uploadTestLogParams.modelId
    };
    commonService.getTypeByModel(data, (res) => {
      let DropdownList = [];
      for (let i = 0; i < res.data.length; i++) {
        let DropdownItem = { title: res.data[i], value: res.data[i] };
        DropdownList.push(DropdownItem);
      }
      this.setState({
        typeList: DropdownList
      })
    }, (error) => {

    })
  };

  getVersion = () => {
    let data = {
      moduleName: this.state.uploadTestLogParams.moduleName
    };
    commonService.getVersionByModule(data, (res) => {
      let DropdownList = [];
      for (let i = 0; i < res.data.value.list.length; i++) {
        let DropdownItem = { title: res.data.value.list[i].version, value: res.data.value.list[i].id };
        DropdownList.push(DropdownItem);
      }
      this.setState({
        versionList: DropdownList
      })
    }, (error) => {

    })
  };

  getTcSuit = () => {
    let data = {
      modelId: this.state.uploadTestLogParams.modelId,
      moduleName: this.state.uploadTestLogParams.moduleName
    };
    commonService.getTcSuitByModel(data, (res) => {
      let DropdownList = [];
      for (let i = 0; i < res.data.list.length; i++) {
        let DropdownItem = { title: res.data.list[i].name, value: res.data.list[i].id };
        DropdownList.push(DropdownItem);
      }
      this.setState({
        tcSuitList: DropdownList
      })
    }, (error) => {

    });
  };

  clearModuleList = () => {
    this.changeDataSearch('modelId', null);
    this.clearDataModule();
    this.clearDataVersion();
    this.clearDataTCSuit();
  };
  clearDataWithEmptyModule = () => {
    this.clearDataModule();
    this.clearDataVersion();
    this.clearDataTCSuit();
  };

  render() {
    return (
      <div>
        <ProgressModal />
        <Header />
        <div className="content">
          <div className="upload-test-log-wrapper">

            <div className="content-title">
              <div className="content-title-text">Upload Test Log</div>
              <div className="content-title-square"></div>
            </div>
            <div className="upload-test-log-content">
              <div className="module-info">
                <div className="cia-title-small">Module Info</div>
                <div className="upload-form row">
                  <div className=" small col-lg-2 "><span className="cia-label">Type</span>
                    <ComponentDropdown title={this.state.dropdownType}
                                       iddropdown="cia-type" className=""
                                       listSearchStatus={this.state.typeList}
                                       handleClickItemDropdown={this.handleSelectType}
                    />
                  </div>
                  <div className=" medium col-lg-4">
                    <span className="cia-label ">Model</span>
                    <div className="">
                      <PickModelListComponent
                        disabled={this.state.disableModel}
                        modelName={this.state.uploadTestLogParams.modelName}
                        clearModuleList={this.clearModuleList}
                        pickModel={this.handleSelectModel} />
                    </div>
                  </div>
                  <div className="medium col-lg-3 module-info-component-wrapper">
                    <span className=" cia-label">Module Name</span>
                    <div className="">
                      <PickModuleListComponent
                        disabled={this.state.disableModule}
                        moduleName={this.state.uploadTestLogParams.moduleName}
                        pickModule={this.handleSelectModule}
                        modelId={this.state.uploadTestLogParams.modelId}
                        type={this.state.uploadTestLogParams.typeId} />
                    </div>
                  </div>
                  <div className="medium col-lg-2">
                    <span className="cia-label">Version</span>
                    <PickVersionListComponent
                      disabled={this.state.disableVersion}
                      clearVersionData={this.clearDataTCSuit}
                      pickVersion={this.pickVersion}
                      moduleName={this.state.uploadTestLogParams.moduleName}
                      versionName={this.state.versionInfo.version}
                      modelId={this.state.uploadTestLogParams.modelId}
                    />
                  </div>
                  <div className="medium  col-lg-4">
                    <span className="cia-label ">TC Suite</span>
                    <div className=" padding-0">
                      <DropdownButton title={this.state.dropdownTCSuit} id="dropdown-log-built"
                                      className="model-dropdown" disabled={this.state.disableTCSuite}>
                        {
                          this.state.tcSuitList.map((item, index) => {
                            return <MenuItem key={index} className="dropdown-item"
                                             onClick={this.handleSelectTCBuilt(item)}>{item.title}</MenuItem>
                          })
                        }
                      </DropdownButton>
                    </div>
                  </div>
                  <button disabled={this.state.disabledConfirmBtn} onClick={this.handleConfirm} className="btn btn-primary btn-confirm">Confirm</button>
                </div>

              </div>
              <br />
              <div hidden>
                <input type="file" id="upload-test-log" onChange={this.onUpload} accept=".zip" />
              </div>
              <button disabled={this.state.disabledConfirmBtn} onClick={this.handleUploadFile} className="btn btn-primary btn-upload">Upload Zip File for Test
                Log
              </button>
              <br />
              <div className="file-list">
                <div className="cia-title">Test Log File List</div>
                <hr />
                <div className="table-up-load-test">
                  <table className="table table-striped">
                    <tbody>
                    <tr>
                      <th className="td-id">TC ID</th>
                      <th className="td-name">Pre-condition</th>
                      <th className="td-creator">Test Proceduce</th>
                      <th className="td-date">Expected Result</th>
                      <th className="td-file">TC Files</th>
                    </tr>
                    {this.state.listTestLog && this.state.listTestLog.length > 0 && this.state.listTestLog.map((data, idx) => {
                      return <tr key={idx}>
                        <td className="td-id">{data.tcId}</td>
                        <td className="td-name">{data.preCondition}</td>
                        <td className="td-creator">{data.proceduce}</td>
                        <td className="td-date">{data.expectedResult}</td>
                        {data.fileLog && data.fileLog.name && <td className="tc-file">
                          {data.fileLog.name}
                          <img className="delete-tc-file-icon" src={Ic_Delete} alt="Delete icon"
                               onClick={() => this.props.actionModal('Delete File', 'Are you sure?', true, this.handleDeleteLog(data.fileLog.id), () => { })} />
                        </td>}
                        {!data.fileLog && <td className="tc-file">
                          <span>No log</span>
                          <img className="delete-tc-file-icon" src={Ic_UploadLog} alt="upload icon"
                               onClick={this.handleUploadSingleLog} />
                          <div hidden>
                            <input type="file" id="upload-single-test-log" onChange={this.onUploadLog} accept=".txt" />
                          </div>
                        </td>}
                      </tr>;
                    })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <div className="pagination-body">
            {this.state.listTestLog && this.state.listTestLog.length > 0 &&
            <ComponentPagination
              totalCount={this.state.totalCount}
              pageNum={this.state.uploadTestLogParams.pageNum}
              currentPage={this.state.currentPage}
              totalPages={this.state.totalPage}
              onChange={this.handleChangePage}
            />}
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  dataTransferCIA: state.application.share.dataTransferCIA
});

const mapDispatchToProps = dispatch => {
  return {
    actionModal: (title, message, isShow, successCallBack, failCallBack) => {
      dispatch(actionModal(title, message, isShow, successCallBack, failCallBack));
    },
    redirectPage: url => {
      dispatch(push(url));
    },
    setLoadToolFunc: (func) => {
      dispatch(loadToolFunc(func));
    },
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    },
    reloadToolPage: (func) => {
      dispatch(reloadToolPage(func));
    },
    showAlert: (permissions) => {
      dispatch(showAlert(permissions));
    },
    removeDataTransfer: () => {
      dispatch(removeDataTransfer());
    }
  };
};


export default connect(mapStateToProps, mapDispatchToProps)(UploadTestLog);
