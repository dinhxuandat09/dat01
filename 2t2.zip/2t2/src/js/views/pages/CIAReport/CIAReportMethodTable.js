import React from 'react';
import {connect} from "react-redux";
import {push} from "redux-router";
import '../../../../public/styles/pages/CIAReportMethodTable.scss';

class CIAReportMethodTable extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>
        {this.props.tableData && this.props.tableData.list.length > 0 &&
        <div className="table-wrapper">
          <table className="table table-striped">
            <tr className="table-header">
            <th className="td-id">TC ID</th>
            <th className="td-description">Description</th>
            <th className="td-package">Package</th>
            <th className="td-classname">Class</th>
            <th className="td-method">Method</th>
            <th className="td-category">Category</th>
            </tr>
            {this.props.tableData.list.map((data, idx) => {
              return <tr key={idx}>
                <td>{data.tcId !== null? data.tcId.substr(0,data.tcId.length-4):null}</td>
                <td>{data.description}</td>
                <td>{data.packageName}</td>
                <td>{data.className}</td>
                <td>{data.method}</td>
                <td>{data.category}</td>
              </tr>;
            })}
          </table>
        </div>
        }
      </div>
    );
  }
}

export default CIAReportMethodTable;