import React from 'react';
import { connect } from "react-redux";
import { push } from "redux-router";
import '../../../../public/styles/pages/CIAReportTCTable.scss';

class CIAReportTCTable extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      this.props.tableData && this.props.tableData.list.length > 0 &&
      <table className="table table-striped">
        <tr className="table-header">
          <th className=" td-model">Model</th>
          <th className=" td-module">Module Name</th>
          <th className=" td-base">Base Version</th>
          <th className=" td-target">Target Version</th>
          <th className=" td-id">TC ID</th>
          <th className=" td-result">Expected Result</th>
          <th className=" td-cond">Pre-cond</th>
          <th className=" td-test">Test Procedure</th>
        </tr>
        {this.props.tableData.list.map((data, idx) => {
          return <tr key={idx}>
            <td>{data.model !== 'null' ? data.model : ''}</td>
            <td>{data.module}</td>
            <td>{data.baseVersion}</td>
            <td>{data.targetVersion}</td>
            <td>{data.tcId}</td>
            <td className=" td-result">{data.expectedResult}</td>
            <td className=" td-cond">{data.preCond}</td>
            <td className=" td-test">{data.testProcedure}</td>
          </tr>;
        })}
      </table>
    );
  }
}

export default CIAReportTCTable;