import React from 'react';
import {connect} from 'react-redux';
import {push} from "redux-router";
import CollectionSidebar from '../components/LeftNavigationBar/CollectionSidebar';
import {makePostRequest} from '../../utils/cuiResource';
import * as SecurityService from '../../utils/securityService';
import {showAlert} from "../../actions/share";
import * as CookieService from '../../utils/cookieService';

class MainPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      userName: null
    }
  }

  componentWillMount() {
    if(!SecurityService.isLoggedIn()){
      if(!window.navigator.msSaveOrOpenBlob){
        this.props.showAlert("You must use Internet Explorer for using this web page");
        this.props.redirectPage('/PageNotFound');
      } else {
        alert("Please Login Mysingle");
        location.href = 'http://www.samsung.net/portal/default.jsp';
      }
    } else {
      if (this.props.location.pathname === '/') {
        this.getSSO('/BuildTestBinary');
      } else {
        this.getSSO(this.props.location.pathname);
      }
    }
  }

  getSSO = (page) => {
    const config = {
      url: "/api/knox/sso",
      data: EpAdmC.GetSecureBox()
    };
    makePostRequest(config, res => {
      document.cookie = "key_portal=" + res.data.tokenPortal + ";path=/";
      document.cookie = "userID=" + res.data.singleId;
      this.setState({
        userName: res.data.singleId
      }, ()=>{
        this.props.redirectPage(page);
      });
    }, () => {
    })
  };

  render() {
    return (
      <div className="main-content">
        <CollectionSidebar userName={this.state.userName}/>
        <div className="body">{this.props.children}</div>
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return {
    redirectPage: url => {
      dispatch(push(url));
    },
    showAlert: (permissions) => {
      dispatch(showAlert(permissions));
    }
  };
};

const mapStateToProps = (state) => ({
  permissions: state.application.system.user.permissions
});


export default connect(mapStateToProps, mapDispatchToProps)(MainPage);