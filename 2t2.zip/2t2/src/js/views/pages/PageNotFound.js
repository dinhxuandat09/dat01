import React from 'react'
import IconToolPortal from '../../../public/images/icons/logo_cia.png';
import Robot from '../../../public/images/icons/robot.png';
import '../../../public/styles/pages/PageNotFound.scss'

class PageNotFound extends React.Component {
  render() {
    return (
      <div className="page-not-found-wrapper">
        <div className="left-content">
          <img className="tool-hub-logo" src={IconToolPortal} height={34} width={76}/>
          <p><h3>404.</h3>That's an error.</p>
          <p>That requested URL was not found on this server. That’s all we know.</p>
        </div>
        <div className="right-content">
        <img src={Robot}/>
        </div>
      </div>
    )
  }
}

export default PageNotFound;
