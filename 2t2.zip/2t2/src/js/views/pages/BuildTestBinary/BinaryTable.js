import React from 'react';
import { connect } from "react-redux";
import { push } from "redux-router";
import '../../../../public/styles/pages/CIATable.scss';
import Ic_Running from '../../../../public/images/ic_loading.gif';

class BinaryTable extends React.Component {
  constructor(props) {
    super(props);
  }

  handleDownloadBinary = (link) => () => {
    window.open(link, '_blank');
  };

  render() {
    return (
      <div>
        {this.props.listBuildLog.list && this.props.listBuildLog.list.length > 0 &&
          <table className="table table-striped table-binary">
            <tbody>
              <tr>
                <th className="td-model">Model</th>
                <th className="td-sever ">Server</th>
                <th className="td-modulename ">Module Name</th>
                <th className="td-version ">Version</th>
                <th className="td-binarydownload">Binary Download</th>
                <th className="td-status ">Status</th>
              </tr>
              {this.props.listBuildLog.list.map((data, idx) => {
                return <tr key={idx}>
                  <td className="">{data.model}</td>
                  <td className="">{data.server} 1717</td>
                  <td className="">{data.moduleName}</td>
                  <td className="">{data.versionName}</td>
                  {data.binaryId && <td className="">
                    <a className="download-binary cursor-pointer" onClick={this.handleDownloadBinary(data.binaryId)}>Download</a>
                  </td>}
                  {!data.binaryId && <td className=""></td>}
                  {data.status && data.status !== "RUNNING" && <td className="td-no text-capitalize">{data.status.toLowerCase()}</td>}
                  {data.status && data.status === "RUNNING" && <td className="td-no text-capitalize">
                    <img src={Ic_Running} alt="Processing" className="running-img" />
                    {data.status.toLowerCase()}...
                                </td>
                  }
                </tr>;
              })}
            </tbody>

          </table>
        }
      </div>
    );
  }
}

export default BinaryTable;