import React from 'react';
import { connect } from "react-redux";
import { push } from "redux-router";
import '../../../../public/styles/pages/CodiffTable.scss';
import Ic_Running from '../../../../public/images/ic_loading.gif';
import { get } from '../../../utils/cookieService'
class CodeDiffTable extends React.Component {
  constructor(props) {
    super(props);
  }

  handleDownloadReportFile = (file) => () => {
    const tokenPortal = get('key_portal');
    var url = '/api/files/testlog?file=' + file + '&token=' + tokenPortal;
    let iframe = document.createElement("iframe");
    iframe.style.display = "none";
    iframe.src = url;
    document.body.appendChild(iframe);
  }

  render() {
    return (
      <div>
        {this.props.tableData && this.props.tableData.list.length > 0 &&
          <table className="table table-striped table-codediff">
           <tbody>
            <tr>
              <th className="td-model">Model</th>
              <th className="td-modulename">Module Name</th>
              <th className="td-base">Base Version</th>
              <th className="td-target">Target Version</th>
              <th className="td-report">Report</th>
            </tr>
            {this.props.tableData.list.map((data, idx) => {
              return <tr key={idx}>
                <td>{data.modelName}</td>
                <td>{data.moduleName}</td>
                <td>{data.baseVersionName}</td>
                <td>{data.targetVersionName}</td>
                <td>
                  {data.reportFile &&
                    <a className="download-binary cursor-pointer" onClick={this.handleDownloadReportFile(data.reportFile.storeName)}>{data.reportFile.name}</a>
                  }
                  {!data.reportFile && <img src={Ic_Running} alt="Processing" className="running-img" />}
                  {!data.reportFile && <span>  Running</span>}
                </td>
              </tr>;
            })}
             </tbody>
          </table>
        }
      </div>
    );
  }
}

export default CodeDiffTable;