import React from 'react';
import { connect } from "react-redux";
import { push } from "redux-router";
import '../../../../public/styles/commons/share/body.scss';
import '../../../../public/styles/pages/CodeDiff.scss';
import Header from '../../components/share/header';
import ProgressModal from '../../components/progressModal/ProgressModal';
import * as commonService from '../../../service/commonService';
import * as codeDiffService from '../../../service/codeDiff/codeDiff';
import ComponentDropdown from '../../components/ComponentDropdown';
import '../../../../public/styles/pages/CIATable.scss';
import CodeDiffTable from './codeDiffTable';
import PickModelListComponent from '../../components/pickModelListComponent/pickModelListComponent';
import PickModuleListComponent from '../../components/pickModelListComponent/pickModuleListComponent';
import { showProgress, hideProgress, actionModal, showAlert, removeDataTransfer } from "../../../actions/share";
import ComponentPagination from '../../components/ComponentPagination';
import PickVersionListComponent from '../../components/moduleInfoComponent/PickVersionComponent';

let SearchCompare = {
  modelId : '',
  baseVersionId: '',
  targetVersionId: ''
};
class CodeDiff extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      listModelCIA: [],
      TypeCIATitle: 'Enter Type',
      listTypeCIA: [],
      listTargetVersionCIA: [],
      baseVersionId: '',
      baseVersionInfo: {
        id: '',
        qbServer: '',
        path: '',
        cl: '',
        version: ''
      },
      targetVersionInfo: {
        qbServer: '',
        path: '',
        cl: '',
        version: ''
      },
      codeDiffTable: {
        list: [],
        pageNum: '',
      },
      TotalCodeDiffPage: 1,
      currentCodeDiffPage: 1,
      totalCount: 0,

      disableModel: true,
      disableModule: true,
      disableVersion: true,

      SearchCIA: {
        appModelId: null,
        moduleName: '',
        type: '',
        baseVersionId: '',
        baseCL: '',
        basePath: '',
        baseServer: '',
        targetVersionId: '',
        targetCL: '',
        targetPath: '',
        targetServer: ''
      }
    }
  }


  componentWillMount() {
    if (this.props.dataTransferCIA && this.props.dataTransferCIA.moduleName) {
      this.transferDataFromProps();
    }
    this.getTypeByModel();
  };

  componentWillUnmount() {
    clearTimeout(this.timeOut);
  };

  changeDataSearch = (keyData, value, objData) => {
    let obj = {};
    if(objData){
      obj = objData
    } else {
      obj[keyData] = value;
    }
    this.setState((prevState) => {
      return {SearchCIA: {...prevState.SearchCIA, ...obj}};
    });
  };

  transferDataFromProps = () => {
    let SearchCIA = {};
    let modelName = null;
    let dropdownType = "Select type";
    SearchCIA.moduleName = this.props.dataTransferCIA.moduleName;
    SearchCIA.baseVersionId = this.props.dataTransferCIA.baseVersion.id;
    SearchCIA.baseCL = this.props.dataTransferCIA.baseVersion.cl;
    SearchCIA.basePath = this.props.dataTransferCIA.baseVersion.path;
    SearchCIA.baseServer = this.props.dataTransferCIA.baseVersion.qbServer;
    SearchCIA.targetVersionId = this.props.dataTransferCIA.targetVersion.id;
    SearchCIA.targetCL = this.props.dataTransferCIA.targetVersion.cl;
    SearchCIA.targetPath = this.props.dataTransferCIA.targetVersion.path;
    SearchCIA.targetServer = this.props.dataTransferCIA.targetVersion.qbServer;
    if (this.props.dataTransferCIA.model) {
      SearchCIA.appModelId = this.props.dataTransferCIA.model.value;
      SearchCIA.type = this.props.dataTransferCIA.type.value;
      modelName = this.props.dataTransferCIA.model.title;
      dropdownType = this.props.dataTransferCIA.type.value;
    }

    this.setState({
      modelName: modelName,
      TypeCIATitle: dropdownType,
      moduleName: SearchCIA.moduleName,
      baseVersionId: SearchCIA.baseVersionId,
      baseVersionInfo: this.props.dataTransferCIA.baseVersion,
      targetVersionInfo: this.props.dataTransferCIA.targetVersion
    }, () => {
      this.changeDataSearch(null, null, SearchCIA);
      this.props.removeDataTransfer();
    })
  };

  clearDataModule = () => {
    this.changeDataSearch('moduleName', null);
    //SearchCIA.moduleName = '';
  };
  clearDataBaseVersion = () => {
    let SearchCIA = {};
    SearchCompare.baseVersionId = '';
    SearchCIA.baseVersionName = '',
    SearchCIA.baseVersionId = '';
    SearchCIA.baseCL = '';
    SearchCIA.basePath = '';
    SearchCIA.baseServer = '';
    this.changeDataSearch(null, null, SearchCIA);
    this.setState({
      baseVersionInfo: {
        qbServer: '',
        path: '',
        cl: ''
      },
      baseVersionId: '',
    })
  };

  clearDataTargetVersion = () => {
    let SearchCIA = {};
    SearchCompare.targetVersionId = '';
    SearchCIA.targetVersionName = '';
    SearchCIA.targetVersionId = '';
    SearchCIA.targetCL = '';
    SearchCIA.targetPath = '';
    SearchCIA.targetServer = '';
    this.changeDataSearch(null, null, SearchCIA);
    this.setState({
      listTargetVersionCIA: [],
      targetVersionInfo: {
        qbServer: '',
        path: '',
        cl: '',
      }
    })
  };

  handleClickItemType = (item, idDropdown) => {
    //SearchCIA.type = item.value;
    this.changeDataSearch('type', item.value);
    this.setState({
      disableModel: false,
      disableModule: false,
      disableVersion: false,
      TypeCIATitle: item.title,
    });
  };

  handleClickModuleItem = (item) => {
    //SearchCIA.moduleName = item;
    this.changeDataSearch('moduleName', item);
    this.clearDataBaseVersion();
    this.clearDataTargetVersion();
  };

  pickBaseVersion = (item) => {
    let SearchCIA = {};
    SearchCompare.baseVersionId = item.id;
    SearchCIA.baseVersionId = item.id;
    SearchCIA.baseVersionName = item.version;
    SearchCIA.baseCL = item.cl;
    SearchCIA.basePath = item.path;
    SearchCIA.baseServer = item.qbServer;
    this.changeDataSearch(null, null, SearchCIA);
    this.setState({
      baseVersionInfo: item,
      baseVersionId: item.id,
    });
    this.clearDataTargetVersion();
  };

  pickTargetVersion = (item) => {
    let SearchCIA = {};
    SearchCompare.targetVersionId = item.id;
    SearchCIA.targetVersionId = item.id;
    SearchCIA.targetVersionName = item.version;
    SearchCIA.targetCL = item.cl;
    SearchCIA.targetPath = item.path;
    SearchCIA.targetServer = item.qbServer;
    this.changeDataSearch(null, null, SearchCIA);
    this.setState({
      targetVersionInfo: item
    })
  };

  getTypeByModel = () => {
    let data = {
      modelId: this.state.SearchCIA.appModelId,
    };
    this.props.showProgress();
    commonService.getTypeByModel(data, (res) => {
      this.props.hideProgress();
      let DropdownList = [];
      for (let i = 0; i < res.data.length; i++) {
        let DropdownItem = { title: res.data[i], value: res.data[i] };
        DropdownList.push(DropdownItem);
      }
      this.setState({
        listTypeCIA: DropdownList
      })
    }, (error) => {
      this.props.hideProgress();
    })
  };

  createNewCodeDiff = () => {
/*    SearchCIA.appModelId = SearchCIA.modelId;
    this.changeDataSearch('appModelId', this.state.SearchCIA.modelId);*/
    codeDiffService.createCodeDiff(this.state.SearchCIA, (res) => {
      this.getAllCodeDiff(SearchCompare);
    }, (error) => {
      this.props.hideProgress();
      this.props.showAlert(error.response.data.message);
    })
  }
  createCodeDiff = () => {
    this.setState({
      currentCodeDiffPage: 1
    });
    this.props.showProgress();

    codeDiffService.getAllCodeDiff(SearchCompare, (res) => {
      if (res.data.totalCount === 0) {
        this.createNewCodeDiff();
      } else {
        let check = false;
        for (let i = 0; i < res.data.totalCount; i++) {
          if (res.data.list[i].reportFile == null) {
            check = true;
            break;
          }
        }
        if (!check) {
          this.props.actionModal('Message', 'This build was created by another user. You want to rebuild?', true, () => {
            this.createNewCodeDiff();
          }, () => {
          });
        }else{
          this.props.showAlert('Another user is building this test binary. Please wait until the building process is completed then try again.');
        }
      }
      this.getAllCodeDiff(SearchCompare);
      this.props.hideProgress();
    }, (error) => {
      this.props.hideProgress();
      this.props.showAlert(error.response.data.message);
    })
  };

  handleChangeCodeDiffPage = (pageNumber) => {
    this.setState({
      currentCodeDiffPage: pageNumber
    });
    let data = {
      pageNum: null
    };
    data.pageNum = pageNumber - 1;
    this.getAllCodeDiff(data);
  };

  getAllCodeDiff = (data) => {
    clearTimeout(this.timeOut);
    this.props.showProgress();
    codeDiffService.getAllCodeDiff(data, (res) => {
      this.props.hideProgress();
      let page = 0;
      if (data != 'undefined' && data != null) {
        page = data.pageNum;
      }
      this.setState({
        codeDiffTable: { list: res.data.list, pageNum: page },
        totalCount: res.data.totalCount,
        TotalCodeDiffPage: Math.ceil(res.data.totalCount / 10) !== 0 ? Math.ceil(res.data.totalCount / 10) : 1
      });

      let checkLoad;
      for (let i = 0; i < res.data.list.length; i++) {
        checkLoad = false;
        if (res.data.list[i].reportFile == null || res.data.list[i].reportFile == 'undefined') {
          checkLoad = true;
          break;
        }
      }
      if (checkLoad) {
        this.timeOut = setTimeout(this.getAllCodeDiffRunning(), 4000);
      }
    }, () => {
      this.props.hideProgress();
    })
  };
  getAllCodeDiffRunning = (data) => {

    codeDiffService.getAllCodeDiff(SearchCompare, (res) => {
      let page = 0;
      if (data != 'undefined' && data != null) {
        page = data.pageNum;
      }
      this.setState({
        codeDiffTable: { list: res.data.list, pageNum: page },
        TotalCodeDiffPage: Math.ceil(res.data.totalCount / 10) !== 0 ? Math.ceil(res.data.totalCount / 10) : 1
      });

      let checkLoad;
      for (let i = 0; i < res.data.list.length; i++) {
        checkLoad = false;
        if (res.data.list[i].reportFile == null || res.data.list[i].reportFile == 'undefined') {
          checkLoad = true;
          break;
        }
      }
      if (checkLoad) {
        this.timeOut = setTimeout(this.getAllCodeDiffRunning, 4000);
      }
    }, () => {
    })
  };

  pickModel = (item) => {
    //SearchCIA.modelId = item.value;
    this.changeDataSearch('appModelId', item.value);
    SearchCompare.modelId = item.value;
    this.clearDataModule();
    this.clearDataBaseVersion();
    this.clearDataTargetVersion();
  };

  clearModuleList = () => {
    SearchCompare.modelId = '';
    //SearchCIA.modelId = '';
    this.changeDataSearch('appModelId', null);
    this.clearDataModule();
    this.clearDataBaseVersion();
    this.clearDataTargetVersion();
  };
  clearDataWithEmptyModule = () => {
    this.clearDataModule();
    this.clearDataBaseVersion();
    this.clearDataTargetVersion();
  };

  render() {
    return (
      <div>
        <ProgressModal />
        <Header />
        <div className="content">
          <div className="content-title">
            <div className="content-title-text cia-title">Code Diff</div>
            <div className="content-title-square"></div>
          </div>

          <div className="content-body">
            <div className="module-info module-info-codediff">
              <div className="module-info-title info-title-codediff "><span
                className="cia-title-small">Code Diff Result</span>
              </div>
              <div className="row module-info-codediff-title">
                <div className="col-lg-3 "><span className=" cia-label">Type</span>
                  <ComponentDropdown title={this.state.TypeCIATitle} iddropdown="cia-type"
                                     handleClickItemDropdown={this.handleClickItemType}
                                     className="" listSearchStatus={this.state.listTypeCIA} />
                </div>
                <div className="col-lg-3 "><span className=" cia-label">Model</span>
                  <div className="">
                    <PickModelListComponent
                      disabled={this.state.disableModel}
                      modelName={this.state.modelName}
                      clearModuleList={this.clearModuleList}
                      pickModel={this.pickModel} />
                  </div>
                </div>
                <div className="col-lg-3 "><span className=" cia-label">Module Name</span>
                  <div className="">
                    <PickModuleListComponent
                      disabled={this.state.disableModule}
                      pickModule={this.handleClickModuleItem}
                      moduleName={this.state.moduleName}
                      modelId={this.state.SearchCIA.appModelId}
                      type={this.state.SearchCIA.type} />
                  </div>
                </div>
              </div>
              <div className="row label-diffcode info-content-codediff">
                <div className=" col-lg-3 medium-codediff"><span className=""></span></div>
                <div className=" col-lg-3 medium-codediff"><span className="">Version</span></div>
                <div className=" col-lg-3 medium-codediff"><span>Server</span></div>
                <div className=" col-lg-3 medium-codediff"><span>Path</span></div>
                <div className=" col-lg-3 medium-codediff"><span>CL/Commit</span></div>
              </div>
              <div className="row module-info-content info-content-codediff medium-codediff">
                <div className="medium-codediff col-lg-3">
                  <span className="span-version">Base Code</span>
                </div>
                <div className="medium-codediff col-lg-3">
                  <PickVersionListComponent
                    disabled={this.state.disableVersion}
                    clearVersionData={this.clearDataBaseVersion}
                    pickVersion={this.pickBaseVersion}
                    moduleName={this.state.SearchCIA.moduleName}
                    versionName={this.state.baseVersionInfo.version}
                    modelId={this.state.SearchCIA.appModelId}
                  />
                </div>
                <div className="col-lg-3 medium-codediff">
                  <input disabled type="text" className="input-codediff cia-text"
                         value={this.state.baseVersionInfo.qbServer}></input>
                </div>
                <div className="col-lg-3 medium-codediff">
                  <input disabled type="text" className="input-codediff cia-text"
                         value={this.state.baseVersionInfo.path}></input>
                </div>
                <div className="col-lg-3 medium-codediff">
                  <input disabled type="text" className="input-codediff cia-text"
                         value={this.state.baseVersionInfo.cl}></input>
                </div>
              </div>

              <div className="row module-info-content info-content-codediff">
                <div className="medium-codediff col-lg-3">
                  <span className="span-version">Target Code</span>
                </div>
                <div className="medium-codediff col-lg-3">
                  <PickVersionListComponent
                    disabled={this.state.disableVersion}
                    clearVersionData={this.clearDataTargetVersion}
                    pickVersion={this.pickTargetVersion}
                    moduleName={this.state.SearchCIA.moduleName}
                    targetversion={this.state.baseVersionId}
                    modelId={this.state.SearchCIA.appModelId}
                  />
                </div>
                <div className="col-lg-3 medium-codediff">
                  <input disabled type="text" className="input-codediff cia-text"
                         value={this.state.targetVersionInfo.qbServer}></input>
                </div>
                <div className=" col-lg-3 medium-codediff">
                  <input disabled type="text" className="input-codediff cia-text"
                         value={this.state.targetVersionInfo.path}></input>
                </div>
                <div className=" col-lg-3 medium-codediff">
                  <input disabled type="text" className="input-codediff cia-text"
                         value={this.state.targetVersionInfo.cl}></input>
                </div>
              </div>
            </div>
          </div>

          <div className="border-compare border-check-build">
            <button disabled={this.state.SearchCIA.moduleName && this.state.SearchCIA.baseVersionId && this.state.SearchCIA.targetVersionId ? false : true}
                    className="btn-check-build btn btn-primary" onClick={this.createCodeDiff}> Compare</button>
          </div>
          <div className="border-latest-comparision border-latest-build"><span className="cia-title">Code Diff Result</span>
          </div>
          <div className="content-table table-codediff">
            <CodeDiffTable tableData={this.state.codeDiffTable} />
          </div>
          <div className="pagination-body">
            {this.state.codeDiffTable && this.state.codeDiffTable.list.length > 0 &&
            <ComponentPagination
              totalCount={this.state.totalCount}
              pageNum={this.state.codeDiffTable.pageNum}
              currentPage={this.state.currentCodeDiffPage}
              totalPages={this.state.TotalCodeDiffPage}
              onChange={this.handleChangeCodeDiffPage}
            />
            }
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  dataTransferCIA: state.application.share.dataTransferCIA
});


const mapDispatchToProps = dispatch => {
  return {
    actionModal: (title, message, isShow, successCallBack, failCallBack, disableSubmitBtn) => {
      dispatch(actionModal(title, message, isShow, successCallBack, failCallBack, disableSubmitBtn));
    },
    showAlert: (message, successCallBack) => {
      dispatch(showAlert(message, successCallBack));
    },
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    },
    removeDataTransfer: () => {
      dispatch(removeDataTransfer());
    }
  };
};


export default connect(mapStateToProps, mapDispatchToProps)(CodeDiff);