import React from 'react';
import {connect} from "react-redux";
import {push} from "redux-router";
import { Tabs, Tab } from 'react-bootstrap';
import axios from 'axios';
import {showProgress, hideProgress, actionModal, confirmModalCustom} from "../../../actions/share";
import {showAlert} from "../../../actions/share";
import Header from '../../components/share/header';
import '../../../../public/styles/pages/TCManagement.scss';
import {getTcSuitByModel} from '../../../service/commonService';
import * as TCManagementSerivice from '../../../service/TCManagementService';
import {DropdownButton, MenuItem} from 'react-bootstrap';
import ProgressModal from '../../components/progressModal/ProgressModal';
import PickModuleListComponent from '../../components/pickModelListComponent/pickModuleListComponent';
import PickModelListComponent from '../../components/pickModelListComponent/pickModelListComponent';
import DragAndDrop from '../../components/Dropzone/DragAndDrop';
import SettingDisplayingModal from '../../components/settingDisplayingModal/settingDisplayingModal';
import Checkbox from '../../components/settingDisplayingModal/Checkbox';
import AddNewTestSuits from './addNewTestSuits';
import EditTestCase from './editTestCase';
import ComponentPagination from '../../components/ComponentPagination';

import trashIcon from "../../../../public/images/icons/ic_delete1.png";
import gridViewIcon from "../../../../public/images/icons/tile-view.png";
import exportIcon from "../../../../public/images/icons/excel-icon.png";
import editIcon from "../../../../public/images/icons/edit-icon.png";
import settingIcon from "../../../../public/images/icons/ic_tool.png";
import addIcon from "../../../../public/images/icons/ic_add_hashtag.png";

let listSetting = [
    {id: 0, code: 'tcId', name: 'TC ID', value: true, default: true},
    {id: 1, code: 'smallCat', name: 'Small Category', value: false, default: false},
    {id: 2, code: 'preCond', name: 'Pre-condition', value: true, default: true},
    {id: 3, code: 'first', name: '1st Iteration', value: false, default: false},
    {id: 4, code: 'level', name: 'Level', value: false, default: false},
    {id: 5, code: 'detailsFunc', name: 'Detail Function', value: false, default: false},
    {id: 6, code: 'testProcedure', name: 'Test Procedure', value: false, default: false},
    {id: 7, code: 'second', name: '2nd Iteration', value: false, default: false},
    {id: 8, code: 'operator', name: 'Operator', value: false, default: false},
    {id: 9, code: 'testObjectives', name: 'Test Objectives', value: true, default: true},
    {id: 10, code: 'expectedResult', name: 'Expected Result', value: true, default: true},
    {id: 11, code: 'third', name: '3rd Iteration', value: false, default: false},
    {id: 12, code: 'plat', name: 'Platform/APK Version', value: true, default: true},
    {id: 13, code: 'inputSpec', name: 'Input Specification', value: false, default: false},
    {id: 14, code: 'remarks', name: 'Remarks', value: false, default: false},
    {id: 15, code: 'auto', name: 'Automation', value: false, default: false},
    {id: 16, code: 'midCat', name: 'Middle Category', value: false, default: false},
  ],
  listSettingFromServer = {},
  TCdataForUpload = {
    moduleName: '',
    TCSuitId: '',
    modelId: '',
    modelName: '',
    fileForUpload:'',
    pageNum: 0,
    viewtype: false,
  },
  canAddTestSuite = true,
  listTestCaseSelected = [],
  tcSelectedEdit = {},
  editTestSuitText: '';

class TCManagement extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      TCSuitText: 'Select TC Suite',
      TCSuitList: [],
      testCaseList: [],
      testSuiteList: [],
      totalSuiteCount: 0,
      totalSuitePage: 1,
      isShowSetting: false,
      isShowAddTestSuite: false,
      isShowEditTC: false,
      totalCount: 0,
      currentPage: 1,
      totalPage: 1,
      textContent: '',
      typePage: 'TC'
    }
  }

  componentWillMount() {
    listTestCaseSelected = [];
    TCManagementSerivice.getListSetting((res) => {
      listSettingFromServer = res.data;
      for (let i = 0; i < listSetting.length; i++) {
        listSetting[i].value = listSettingFromServer[listSetting[i].code];
      }
      this.forceUpdate();
    }, (error) => {
    });
  }

  handleSelectModule = (item) => {
    TCdataForUpload.moduleName = item;
    canAddTestSuite = true;
    this.clearTCSuit();
    this.getTcSuit();
  };
  getTcSuit = () => {
    let data = {
      moduleName: TCdataForUpload.moduleName,
      modelId: TCdataForUpload.modelId
    };
    getTcSuitByModel(data, (res) => {
      this.setState({ TCSuitList: res.data.list });
      if (res.data.list.length > 0 && data.modelId) {
        canAddTestSuite = false;
      }
    }, (error) => {
    });
  };
  clearDataWithEmptyModule = () => {
    TCdataForUpload.moduleName = null;
    this.clearTCSuit();
  };
  handleSelectType = (item) => () => {
    TCdataForUpload.TCSuitName = item.name;
    TCdataForUpload.TCSuitId = item.id;
    this.setState({ TCSuitText: item.name });
    this.getTestCaeByTCSuitId();
  };
  clearTCSuit = () => {
    this.setState({
      TCSuitText: 'Select TC Suite',
      TCSuitList: []
    })
  };
  uploadTestCasesAction = () => {
    if (!TCdataForUpload.moduleName || !TCdataForUpload.TCSuitName) {
      this.props.showAlert("Please select all fields Module Name, TC Suite!");
      return;
    }
    document.getElementById('uploadTestCaseFile').click();
  };
  getTestCaeByTCSuitId = () => {
    let data = {
      pageSize: 10,
      pageNum: TCdataForUpload.pageNum,
      testSuitId: TCdataForUpload.TCSuitId
    };
    TCManagementSerivice.getTestCaseByTCSuit(data, (res) => {
      this.setState({
        testCaseList: res.data.value.list,
        totalCount: res.data.value.totalCount,
        totalPage: Math.ceil(res.data.value.totalCount / 10) !== 0 ? Math.ceil(res.data.value.totalCount / 10) : 1
      })
    }, (error) => {
    });
  };
  handleSuccessCallBackForUploadFileTC = () => {
    let newData = {
      file : TCdataForUpload.fileForUpload,
      moduleName :TCdataForUpload.moduleName,
      testSuitId : TCdataForUpload.TCSuitId,
      acceptDelete: true
    };
    TCManagementSerivice.uploadTestCases(newData, (response) => {
      this.props.hideProgress();
      this.props.showAlert("Uploaded successfully");
      this.getTestCaeByTCSuitId();
    }, (error) => {
      this.props.hideProgress();
      this.props.showAlert(error.message);
      this.getTestCaeByTCSuitId();
    });
  };

  onDropFile = (e) => {
    e.preventDefault();
    var files;
    if (e.dataTransfer) {
      files = e.dataTransfer.files;
    } else if (e.target) {
      files = e.target.files;
    }
    if (files && files.length > 0) {
      let form = new FormData();
      form.append("file", files[0], files[0].name);
      let data = {};
      data.file = form;
      TCdataForUpload.fileForUpload = form;
      data.moduleName = TCdataForUpload.moduleName;
      data.testSuitId = TCdataForUpload.TCSuitId;
      data.acceptDelete = null;
      this.props.showProgress();
      TCManagementSerivice.uploadTestCases(data, (response) => {
        this.props.hideProgress();
        if(response.data.code === 400003) {
          this.props.actionModal('Some Test Case is being used',
            'There are some some test case being used in test log. Do you want to remove these?',true,this.handleSuccessCallBackForUploadFileTC)
        }
        else if(response.data.code === 400002)
          this.props.showAlert(response.data.message + "Please edit your file and upload again.");
        else {
          this.props.showAlert("Uploaded successfully");
          this.getTestCaeByTCSuitId();
        }
      }, (error) => {
        this.props.hideProgress();
        this.props.showAlert(error.message);
      });
    }
    document.getElementById('uploadTestCaseFile').value = null;
  };
  exportTestCases = () => {
    let data = {
      testSuitId: TCdataForUpload.TCSuitId
    };
    TCManagementSerivice.exportTestCasesList(data, (response) => {
      let file = new Blob([response.data], {type: response.headers['content-type']});
      if (window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(file);
      }
    }, (error) => {
      this.props.showAlert("Export fail");
    });
  };

  setNewListFromSetting = (newList)=> {
    listSetting = newList;
    for (let i = 0; i < newList.length; i++) {
      listSettingFromServer[newList[i].code] = newList[i].value;
    }
    TCManagementSerivice.updateListSetting(listSettingFromServer, (response) => {
      this.props.showAlert("Save your setting successfully");
    }, (error) => {
      this.props.showAlert("Save your setting fail");
    });
  };

  showSettingDisplay = (value) => () => {
    this.setState({
      isShowSetting: value
    })
  };

  pickModel = (item) => {
    TCdataForUpload.modelId = item.value;
    TCdataForUpload.modelName = item.title;
    canAddTestSuite = true;
    this.clearTCSuit();
    this.getTcSuit();
  };

  addNewTestSuite = (ok) => () => {
    if(ok)
      this.getTcSuit();
    if (canAddTestSuite){
      this.setState((prevState) => ({
        isShowAddTestSuite: !prevState.isShowAddTestSuite
      }));
    }
    else
      this.props.showAlert("Already have Test Suite, not need create Test Suite");
  };
  clearModuleList = () => {
    TCdataForUpload.modelId = '';
    TCdataForUpload.modelName = '';
    this.clearTCSuit();
  };
  handleChangePage = (pageNumber) => {
    TCdataForUpload.pageNum = pageNumber - 1;
    this.setState({
      currentPage: pageNumber
    });
    this.getTestCaeByTCSuitId();
  };
  editTC = (tc) => () => {
    tcSelectedEdit = tc;
    this.toggleEditPopUp();
  };
  toggleEditPopUp = () => {
    this.setState((prevState) => ({
      isShowEditTC: !prevState.isShowEditTC
    }));
  }
  selectTestCase = (tcId) => {
    if(!listTestCaseSelected.includes(tcId)){
      listTestCaseSelected.push(tcId)
    }
    else {
      listTestCaseSelected = listTestCaseSelected.filter(item => item !== tcId)
    }
  };
  confirmDelete = () => {
    TCManagementSerivice.deleteTestCase(listTestCaseSelected.toString(), true, (res)=>{
      this.props.showAlert("Delete successfully");
      listTestCaseSelected = [];
      this.getTestCaeByTCSuitId();
    },(error)=>{
    })
  };
  deleteTestCase = () => {
    if(listTestCaseSelected.length >0){
      this.props.showProgress();
      TCManagementSerivice.deleteTestCase(listTestCaseSelected.toString(), null, (res)=>{
        this.props.hideProgress();
        if(res.data.code === 400003) {
          this.props.actionModal('Some Test Case is being used',
            'There are some some test case being used in test log. Do you want to remove these?',true,this.confirmDelete)
        }
        else if(res.data.code === 400002)
          this.props.showAlert(res.data.message + "Please edit your file and upload again.");
        else {
          this.props.showAlert("Delete successfully");
          this.getTestCaeByTCSuitId();
        }
      },(error)=>{
        })
    }
  };
  onClickviewType = () => {
    this.setState(prevState =>({ viewtype : !prevState.viewtype}));
  };
  evetHover = (value) => e =>{
    this.setState({textContent: value});
  };
  handleClickTCTab = (index) => {
    if(index === 2) this.setState({ typePage: 'TS'});
    if(index === 1) this.setState({ typePage: 'TC'});
  };
  showResult = () => {
    let param = {
      modelId: TCdataForUpload.modelId,
      modelName: TCdataForUpload.modelName,
      moduleName: TCdataForUpload.moduleName,
      pageSize: 10,
      pageNum: TCdataForUpload.pageNum,
    };
    this.props.showProgress();
    TCManagementSerivice.getListTestSuite(param, (res) => {
      this.props.hideProgress();
      this.setState({
        testSuiteList: res.data.list,
        totalSuiteCount: res.data.totalCount,
        totalSuitePage: Math.ceil(res.data.totalCount / 10) !== 0 ? Math.ceil(res.data.totalCount / 10) : 1
      });
    }, (error) => {});
  };
  selectTestSuite = () => {
    //implement select test suite item
  };

  handleChangeEditText = (value) => {
    editTestSuitText = value;
  };
  editTS = (data) => {
    let content = <div className="edit-ts-modal">
      <div className="item-edit-ts">
        <div className="text-title-item">Module Name*</div>
        <div className="content-input">
          <PickModelListComponent modelInit={data.moduleName} disabled={true}/>
        </div>
      </div>
      <div className="item-edit-ts">
        <div className="text-title-item">Model Name</div>
        <div className="content-input">
          <PickModelListComponent modelInit={data.modelName} disabled={true}/>
        </div>
      </div>
      <div className="item-edit-ts">
        <div className="text-title-item">TC Suite*</div>
        <div className="content-input">
          <PickModelListComponent modelInit={data.name} customModelList={true} handleChangeText={this.handleChangeEditText}/>
        </div>
      </div>
    </div>;
    let param = {
      title: 'Edit TC Suit',
      message: content,
      isShow: true,
      submitText: 'Edit'
    };
    this.props.confirmModalCustom(param,()=> this.confirmEditTestSuite(data, editTestSuitText))
  };
  confirmEditTestSuite = (data, editTestSuitText) => {
    let param = {
      id: data.id,
      name: editTestSuitText
    };
    this.props.showProgress();
    TCManagementSerivice.updateTestSuite(param, (res) => {
      this.props.hideProgress();
      let testSuiteList = [...this.state.testSuiteList];
      for(let item of testSuiteList) {
        if(item.id === res.data.id) {
          item.name = res.data.name;
          break;
        }
      }
      this.setState({
        testSuiteList: testSuiteList,
      });
    }, (error) => {this.props.hideProgress();});
  };
  deleteTestSuite = (id) => {
    let param = {
      title: 'Delete TC Suit',
      message: 'This Test Suite will be removed from list. You want to delete this item?',
      isShow: true,
      submitText: 'Delete'
    };
    this.props.confirmModalCustom(param,()=> this.confirmDeleteTestSuite(id), () => {})
  };
  confirmDeleteTestSuite = () => {
    //implement delete test suite
  };
  render() {
    return (
      <div>
        <ProgressModal />
        <Header />
        <div className="content">
          <div className="upload-test-log-wrapper">
            <div className="content-title">
              <div className="content-title-text">TC Management</div>
              <div className="content-title-square"></div>
              <img src={settingIcon} alt="setting display" className="setting-icon"
                   onClick={this.showSettingDisplay(true)}/>
            </div>
            <Tabs defaultActiveKey={1} animation={false} id="tc-management-tabs" onSelect={this.handleClickTCTab}>
              <Tab eventKey={1} title="TC Management" />
              <Tab eventKey={2} title="TS Management" />
            </Tabs>
            <div className="upload-test-log-content">
              <div className="module-info">
                <div className="cia-title-small">Test Suite Info</div>
                <div className="upload-form row">
                  <div className="col-lg-4">
                    <span>Module Name</span>
                    <div className="content-input">
                      <PickModuleListComponent
                        clearDataWithEmptyModule={this.clearDataWithEmptyModule}
                        pickModule={this.handleSelectModule}
                        modelId='TCmanagement'
                        show = {true}
                        type=''/>
                    </div>
                  </div>

                  <div className="col-lg-4">
                    <span>Model Name</span>
                    <div className="content-input">
                      <PickModelListComponent
                        clearModuleList={this.clearModuleList}
                        pickModel={this.pickModel}
                        type= 'TCmanagement'/>
                    </div>
                  </div>

                  {this.state.typePage === 'TC' ?
                    <div className="col-lg-3">
                      <span className="">TC Suite</span>
                      <div className="content-input">
                        <DropdownButton title={this.state.TCSuitText} id="tcSuit">
                          {
                            this.state.TCSuitList.map((item, index) => {
                              return <MenuItem key={index} className="dropdown-item"
                                               onClick={this.handleSelectType(item)}>{item.name}</MenuItem>
                            })
                          }
                        </DropdownButton>
                      </div>
                    </div> : ''
                  }
                  <button className="btn btn-add-ts" onClick={this.addNewTestSuite()}>Add TS</button>
                </div>

              </div>
              <br/>
              <div hidden>
                <input type="file" id="uploadTestCaseFile" onChange={this.onDropFile}
                       accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"/>
              </div>
              {this.state.typePage === 'TC' ?
                <button className="btn btn-primary btn-upload" onClick={this.uploadTestCasesAction}>Upload</button> :
                <button className="btn btn-primary btn-upload" onClick={this.showResult}>Show result</button>
              }
              <br/>

              <div className="file-list display-table">
                <div className="cia-title">TC list</div>
                <hr />
                {this.state.typePage === 'TC' &&
                  <div className="tool-bar right">
                    <img className="right" alt="export" src={exportIcon} onClick={this.exportTestCases}/>
                    <img className="right" alt="view type" src={gridViewIcon} id="view-type"
                         data-toggle="tooltip" data-placement="top" title="View Type"
                         onClick={this.onClickviewType}/>
                    <img className="right" alt="trash" src={trashIcon} onClick={this.deleteTestCase}/>
                  </div>
                }
                <div className="border-table">
                  <table className="table table-striped table-tcmanagement">
                    <tbody>
                    {this.state.typePage === 'TC' ?
                      <tr>
                        <th className="td-no"><input type="checkbox" value="all"/></th>
                        <th className="td-no">No</th>
                        <th className="td-id">TC ID</th>
                        {listSetting[4].value && <th className="td-level">Level</th>}
                        {listSetting[8].value && <th className="td-operator">Operator</th>}
                        <th className="td-platform">Platform/APK Version</th>
                        {listSetting[16].value && <th className="td-cate">Middle Category</th>}
                        {listSetting[1].value && <th className="td-cate">Small Category</th>}
                        {listSetting[5].value && <th className="td-detail">Detail Function</th>}
                        <th className="td-test">Test Objective</th>
                        {listSetting[13].value && <th className="td-input">Input Specification</th>}
                        <th className="td-pre">Pre-condition</th>
                        {listSetting[6].value && <th className="td-test">Test Procedure</th>}
                        <th className="td-file">Expected Result</th>
                        {listSetting[14].value && <th className="td-remark">Remarks</th>}
                        {listSetting[3].value && <th className="td-iterator">1st Iterator</th>}
                        {listSetting[7].value && <th className="td-iterator">2nd Iterator</th>}
                        {listSetting[11].value && <th className="td-iterator">3rd Iterator</th>}
                        {listSetting[15].value && <th className="td-automation">Automation</th>}
                        <th className="td-update">Update Date</th>
                        <th className="td-creator">Creator</th>
                        <th className="td-edit">Modify</th>
                      </tr> :
                      <tr>
                        <th className="td-no"><input type="checkbox" value="all"/></th>
                        <th className="td-id">TS ID</th>
                        <th className="td-platform">Module Name</th>
                        <th className="td-update">Model Name</th>
                        <th className="td-creator">TC Suite</th>
                        <th className="td-edit">Action</th>
                      </tr>
                    }
                    {this.state.typePage === 'TC' ?
                      this.state.testCaseList.length > 0 && this.state.testCaseList.map((data, idx) => {
                        let dataForCheckBox = {
                          name: '',
                          default: false,
                          id: data.id,
                          value: false
                        };
                        return <tr key={idx} className={this.state.viewtype ? 'full-text' : 'short-text'}>
                          <td className="td-no"><Checkbox item={dataForCheckBox} handleCheckboxChange={this.selectTestCase}/></td>
                          <td className="td-no">{this.state.currentPage + idx}</td>
                          <td className="td-id">{data.tcId}</td>
                          {listSetting[4].value && <td className="td-level">{data.level}</td>}
                          {listSetting[8].value && <td className="td-operator">{data.operator}</td>}
                          <td className="td-platform">{data.platform}</td>
                          {listSetting[16].value && <td className="td-cate">{data.middleCategory}</td>}
                          {listSetting[1].value && <td className="td-cate">{data.smallCategory}</td>}
                          {listSetting[5].value && <td className="td-detail"><div className="data">
                              <span onMouseOver={this.evetHover(data.function)}
                              data-toggle="tooltip" data-placement="top" title={this.state.textContent}>
                              {data.function}</span></div></td>}
                          <td className="td-test"><div className="data">
                              <span onMouseOver={this.evetHover(data.objectives)}
                              data-toggle="tooltip" data-placement="top" title={this.state.textContent}>
                              {data.objectives}</span></div></td>
                          {listSetting[13].value && <td className="td-input">{data.specification}</td>}
                          <td className="td-pre"><div className="data">
                             <span onMouseOver={this.evetHover(data.preCondition)}
                              data-toggle="tooltip" data-placement="top" title={this.state.textContent}>
                              {data.preCondition}</span></div></td>
                          {listSetting[6].value && <td className="td-test"><div className="data">
                             <span onMouseOver={this.evetHover(data.proceduce)}
                              data-toggle="tooltip" data-placement="top" title={this.state.textContent}>
                             {data.proceduce}</span></div></td>}
                          <td className="td-file"><div className="data">
                             <span onMouseOver={this.evetHover(data.expectedResult)}
                              data-toggle="tooltip" data-placement="top" title={this.state.textContent}>
                             {data.expectedResult}</span></div></td>
                          {listSetting[14].value && <td className="td-remark"><div className="data">
                              <span onMouseOver={this.evetHover(data.remarks)}
                              data-toggle="tooltip" data-placement="top" title={this.state.textContent}>
                              {data.remarks}</span></div></td>}
                          {listSetting[3].value && <td className="td-iterator">1st Iterator</td>}
                          {listSetting[7].value && <td className="td-iterator">2nd Iterator</td>}
                          {listSetting[11].value && <td className="td-iterator">3rd Iterator</td>}
                          {listSetting[15].value && <td className="td-automation">Automation</td>}
                          <td className="td-date">{data.lastModifiedDate}</td>
                          <td className="td-date">{data.createdBy}</td>
                          <td className="td-edit">
                            <img className="" src={editIcon} alt="edit" onClick={this.editTC(data)}/>
                          </td>
                        </tr>;
                      }) :
                      this.state.testSuiteList.length > 0 && this.state.testSuiteList.map((data, index) => {
                        let dataForCheckBox = {
                          name: '',
                          default: false,
                          id: data.id,
                          value: false
                        };
                        return <tr key={index} className="short-text">
                          <td className="td-no"><Checkbox item={dataForCheckBox} handleCheckboxChange={this.selectTestSuite}/></td>
                          <td className="td-id">{data.id}</td>
                          <td className="td-platform">{data.moduleName}</td>
                          <td className="td-date">{data.modelName}</td>
                          <td className="td-date">{data.name}</td>
                          <td className="td-edit">
                            <img className="" src={editIcon} alt="edit" onClick={() => this.editTS(data)}/>
                            <img className="" src={trashIcon} alt="delete" onClick={() => this.deleteTestSuite(data.id)}/>
                          </td>
                        </tr>;
                      })
                    }
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          </div>
          <div className="pagination-body">
            {this.state.testCaseList && this.state.testCaseList.length > 0 &&
            <ComponentPagination
              totalCount={this.state.totalCount}
              pageNum={TCdataForUpload.pageNum}
              currentPage={this.state.currentPage}
              totalPages={this.state.totalPage}
              onChange={this.handleChangePage}
            />
            }
          </div>
        </div>
        {this.state.isShowSetting &&
        <SettingDisplayingModal listSetting={listSetting}
                                showSettingDisplay={this.showSettingDisplay}
                                setNewListFromSetting={this.setNewListFromSetting}/>}
        {this.state.isShowAddTestSuite &&
        <AddNewTestSuits moduleName={TCdataForUpload.moduleName}
                         modelName={TCdataForUpload.modelName}
                         hidePopUp={this.addNewTestSuite}
                         modelId={TCdataForUpload.modelId}/>}
        {this.state.isShowEditTC &&
        <EditTestCase testcase={tcSelectedEdit} reloadListTC={this.getTestCaeByTCSuitId} hidePopUp={this.toggleEditPopUp}/>}
      </div>
    )
  }
}
const mapStateToProps = (state) => ({
  listCategory: state.application.share.listCategory,
  setSearchText: state.application.share.functionSetSearchText,
  isShowProgress: state.application.share.progressModal.isShow
});


const mapDispatchToProps = dispatch => {
  return {
    actionModal: (title, message, isShow, successCallBack, failCallBack) => {
      dispatch(actionModal(title, message, isShow, successCallBack, failCallBack));
    },
    confirmModalCustom: (params, successCallBack, failCallBack) => {
      dispatch(confirmModalCustom(params, successCallBack, failCallBack));
    },
    redirectPage: url => {
      dispatch(push(url));
    },
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    },
    showAlert: (permissions) => {
      dispatch(showAlert(permissions));
    }
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(TCManagement);