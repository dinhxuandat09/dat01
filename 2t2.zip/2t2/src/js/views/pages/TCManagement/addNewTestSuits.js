import {Modal,Button} from 'react-bootstrap';
import  React from "react";
import {connect} from 'react-redux';
import '../../../../public/styles/commons/alertModal/AlertModal.scss';
import {addNewTestSuite} from '../../../service/TCManagementService';

let isDuplicate = false;
class AddNewTestSuits extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      TCSuiteName: '',
      warning: false
    };
  }
  componentWillMount() {
  }
  handleOnChange = (e) => {
    this.setState({
      TCSuiteName: e.target.value
    })
    if(!e.target.value && this.state.warning)
      this.setState({warning : false})
  }
  close = () => {
    this.props.hidePopUp()();
  };

  addNewTestSuite = () => {
    let data = {
      model_id: this.props.modelId,
      moduleName: this.props.moduleName,
      name: this.state.TCSuiteName
    };
    addNewTestSuite(data, (res)=>{
      this.props.hidePopUp(true)();
    }, (error)=>{
      this.setState({
        warning: true
      })
      console.log(error.message);
    })
  }

  confirm = (e) => {
    e.preventDefault();
    if(this.props.moduleName === '' || this.state.TCSuiteName==='')
      this.setState({
        warning: true
      })
    else{
      this.addNewTestSuite();
    }
  };

  render() {
    return (
      <div className="alert-popup-container">
        <Modal dialogClassName="alert-modal" show={true}>
          <Modal.Header>Add TC Suite</Modal.Header>
          <Modal.Body>
            <div className="test-suite-row">
              <span className="col-lg-3">Module Name *</span>
              <input className="col-lg-9 cia-text" type="text" value={this.props.moduleName} placeholder="Need select Module" disabled/>
              {(!this.props.moduleName && this.state.warning) && <span className="warning">This field is required</span>}
            </div>
            <div className="test-suite-row">
              <span className="col-lg-3">Model name</span>
              <input className="col-lg-9 cia-text" type="text" value={this.props.modelName} placeholder="Select model" disabled/>
            </div>
            <div className="test-suite-row">
              <span className="col-lg-3">TC Suite *</span>
              <input className="col-lg-9 cia-text" type="text" value={this.state.TCSuiteName} onChange={this.handleOnChange} placeholder="Enter name here"/>

            </div>
          </Modal.Body>
          <Modal.Footer>
            <button className="btn btn-default" onClick={this.close}>Cancel</button>
            <button className="btn btn-primary" onClick={this.confirm}>Add</button>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}

export default AddNewTestSuits;