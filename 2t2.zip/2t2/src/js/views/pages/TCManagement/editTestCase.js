import {Modal, Button} from 'react-bootstrap';
import  React from "react";
import {connect} from 'react-redux';
import '../../../../public/styles/commons/alertModal/AlertModal.scss';
import AutoCompleteText from '../../components/autoCompleteText/autoCompleteText';
import TextArea from '../../components/textArea/textArea';
import * as TCManagementSerivice from '../../../service/TCManagementService';

let tcUpdated = {},
  fieldHasAutoCompleteText = [
    {name: 'Level', code: 'level'},
    {name: 'Operator', code: 'operator'},
    {name: 'Platform/ APK Version', code: 'platform'},
    {name: 'Middle Category', code: 'middleCategory'},
    {name: 'Small Category', code: 'smallCategory'},
    {name: 'Details Function', code: 'function'},
  ],
  fieldVsLongText = [
    {name: 'Test Objectives', code:'objectives'},
    {name: 'Input Specification', code:'specification'},
    {name: 'Pre-condition', code:'preCondition'},
    {name: 'Test Procedure', code:'proceduce'},
    {name: 'Expected Result', code:'expectedResult'},
    {name: 'Remarks', code:'remarks'}];

class EditTestCase extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentWillMount() {
    tcUpdated = this.props.testcase;
    for (let i = 0; i < fieldHasAutoCompleteText.length; i++){
      fieldHasAutoCompleteText[i].value = tcUpdated[fieldHasAutoCompleteText[i].code]
    }
    for (let i = 0; i < fieldVsLongText.length; i++){
      fieldVsLongText[i].value = tcUpdated[fieldVsLongText[i].code]
    }
  }

  close = () => {
    this.props.hidePopUp();
  };
  setNewValueForTc = (field, newValue)=> {
    tcUpdated[field] = newValue;
  };


  confirm = (e) => {
    TCManagementSerivice.updateTestCase(tcUpdated, (res)=>{
      this.props.reloadListTC();
    },(eror)=>{})
    this.props.hidePopUp();
  };
  generateInputElement = () => {
    return (
      fieldHasAutoCompleteText.map((item, index)=> {
        return (
          <AutoCompleteText item={item} key={index} setNewValueForTc={this.setNewValueForTc} testCaseID={this.props.testcase.id}/>
        )
      }))
  };
  generateTextArea = () => {
    return (
      fieldVsLongText.map((item, index)=> {
        return (
          <TextArea key={index} item={item} setNewValueForTc={this.setNewValueForTc}/>
        )
      })
    )
  }


  render() {
    return (
      <div className="alert-popup-container">
        <Modal dialogClassName="alert-modal modal-edit-tc" show={true}>
          <Modal.Header>Edit test case: {this.props.testcase.tcId}</Modal.Header>
          <Modal.Body>
            {this.generateInputElement()}
            {this.generateTextArea()}
          </Modal.Body>
          <Modal.Footer>
            <button className="btn btn-default" onClick={this.close}>Cancel</button>
            <button className="btn btn-primary" onClick={this.confirm}>Save</button>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }
}

export default EditTestCase;