import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import css from '../../vendor/roboto/css/font.scss';

import { CollectionSidebar, AlertModal } from './views/components';
// Components
import ViewportLayer from '../common/ViewportLayer';

const appName = 'SETP';

const Application = ({ children, isFetching, upload }) => {
  return (
    <div>
      <ViewportLayer>
{/*        <CollectionSidebar appName={appName} />*/}
{/*        <ActionBarContainer />*/}
        <div className="app-content">
{/*          <AppBarContainer />*/}
          <div className="content-body">
            {children}
            <AlertModal/>
          </div>
        </div>
      </ViewportLayer>
    </div>
  );
};

Application.propTypes = {
  children: PropTypes.element
};

const mapStateToProps = (state) => ({
  upload: state.application.upload
});

export default connect(mapStateToProps)(Application);