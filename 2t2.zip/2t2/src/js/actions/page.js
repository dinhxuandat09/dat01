import {SET_APP_BAR} from '../utils/constants/actiontypes';

function setAppBar(result) {
  return {
    type: SET_APP_BAR,
    result: result
  }
}

export function getContentAppBar(param = {}) {
  return (dispatch) => {
    const result = {
      contentAppBarRight: param.contentRight,
      contentAppBarLeft: param.contentLeft,
    };
    dispatch(setAppBar(result));
  }
}

