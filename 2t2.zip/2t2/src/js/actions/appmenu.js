import { TOGGLE_APP_MENU } from '../utils/constants/actiontypes';

export const toggleAppMenu = () => ({
  type: TOGGLE_APP_MENU,
});
