import * as CookieService from './cookieService';
import * as TokenService from './tokenService';
import * as UtilService from './utilService';
import { isUndefinedOrNull, isFunction } from 'lodash';
import * as constants from './Constants';
import * as storage from '../persistence/storage';

var loginSessionIdKey = 'a928d0e2d54eb6c73604a13fbbba59d2';

export function isSessionExpires() {
  return isUndefinedOrNull(CookieService.get(loginSessionIdKey));
}

export function setLoginSession() {
  CookieService.setWithExpires(loginSessionIdKey, UtilService.generateGUID(), constants.DEFAULT_LOGIN_SESSION_EXPIRES);
  addSessionCheckInterval();
}

export function renewLoginSession() {
  CookieService.touch(loginSessionIdKey);
}

export function removeLoginUser() {
}

export function isLoggedIn() {
  if(window.navigator.msSaveOrOpenBlob && EpAdmC.GetSecureBox()){
    return true;
  } else {
    return false;
  }
}

export function requestLogin(data) {
  //TODO:
}

export function requestLogOut(callback) {
  sessionTimeout();
  if (isFunction(callback)) {
    callback();
  }
}

export function sessionTimeout() {
  sessionTimeoutWithoutStateChange();
  if (isFunction(constants.SESSION_TIMEOUT_CALLBACK)) {
    constants.SESSION_TIMEOUT_CALLBACK();
  }
}

export function sessionTimeoutWithoutStateChange() {
  removeLoginUser();
  TokenService.expireApiToken();
  CookieService.removeAll();
}