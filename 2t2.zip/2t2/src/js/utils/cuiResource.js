import {isFunction, isObject, extend} from 'lodash';
import axios from 'axios';
import {renewLoginSession} from './securityService';
import {LOGOUT_URL} from './Constants';
import * as CookieService from './cookieService';
import {store} from '../Root';
import {showAlert, hideProgress} from '../actions/share'
import {push} from "redux-router";

export function makeHttpPromise(requestConfig) {
  var config = requestConfig || {};
  config.method = config.method || 'GET';
  config.url = config.url || '';
  if (config.header) {
    config.header = config.header.extend(config.header, requestConfig.header);
  }
  return config;
}

export function makeRequest(config, successCallback, failCallback) {
  renewLoginSession();
  let crowdTokenKey;
  if(window.navigator.msSaveOrOpenBlob){
    crowdTokenKey = CookieService.get('key_portal');
  } else {
    crowdTokenKey = 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImF1dGgiOiJST0xFX0FETUlOLFJPTEVfVVNFUiIsImV4cCI6MTUxODc1MTYxN30.PpJfGGw_wBgcevgy2xB_wLn1U0oO4-d__6D0fWewKUHJ0U5yZtfWBT9tkJcJ-osu5369-cKwkkeZ-LktMwvuig'
  }

  if (crowdTokenKey) {
    if (config.headers) {
      config.headers.Authorization = 'Bearer ' + crowdTokenKey;
    } else {
      config.headers = {Authorization: 'Bearer ' + crowdTokenKey};
    }
  }
  var result = {
    $promise: makeHttpPromise(config)
  };
  return axios(result.$promise).then(function (response) {
    if (isFunction(successCallback)) {
      successCallback(response);
    }
  }).catch(function (error) {
/*    if (error.response && error.response.status) {
      if (error.response.status === 401) {
        if (config.url.indexOf("authenticate") < 0) {
          renewToken();
        }
      }
    }
    if (error.response && error.response.data && error.response.data.message) {
      if (error.response.data.message === "invalid tool id") {
        store.dispatch(push('/PageNotFound'));
      }
    }*/
    if (isFunction(failCallback)) {
      failCallback(error);
    }
  });
}

function renewToken() {
  let config = {
    url: '/api/renew',
    params: {
      username: CookieService.get('userID')
    }
  };
  makeGetRequest(config, (res) => {
    document.cookie = "crowd.token_key_portal=" + res.data.message + ";path=/";
    document.cookie = "crowd.token_key=" + res.data.message + ";path=/";
    store.dispatch(hideProgress());
    location.reload();
  }, () => {
    store.dispatch(hideProgress());
    document.cookie = 'crowd.token_key' + '=; Max-Age=0';
    document.cookie = 'crowd.token_key_portal' + '=; Max-Age=0';
    document.cookie = 'userID' + '=; Max-Age=0';
    document.cookie = 'permissions' + '=; Max-Age=0';
    store.dispatch(push('/login'));
  })
}

export function makeGetRequest(requestConfig, successCallback, failCallback) {
  var config = extend({method: 'GET'}, requestConfig);
  return makeRequest(config, successCallback, failCallback);
}

export function makePostRequest(requestConfig, successCallback, failCallback) {
  var config = extend({method: 'POST'}, requestConfig);
  return makeRequest(config, successCallback, failCallback);
}

export function makePutRequest(requestConfig, successCallback, failCallback) {
  var config = extend({method: 'PUT'}, requestConfig);
  return makeRequest(config, successCallback, failCallback);
}

export function makeDeleteRequest(requestConfig, successCallback, failCallback) {
  var config = extend({method: 'DELETE'}, requestConfig);
  return makeRequest(config, successCallback, failCallback);
}

export function makePatchRequest(requestConfig, successCallback, failCallback) {
  var config = extend({method: 'PATCH'}, requestConfig);
  return makeRequest(config, successCallback, failCallback);
}
