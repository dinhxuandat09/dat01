import * as constants from './Constants'
import * as CookieService from './cookieService'

export function expireApiToken() {
  CookieService.remove(constants.KEYS.apiToken);
  CookieService.removeWithOption(constants.KEYS.ssoToken, { domain: '.samsung.com', path: '/' });
  CookieService.removeWithOption(constants.KEYS.ssoTokenOpt, { domain: '.samsung.com', path: '/' });
}

