import { copy, extend, each, isUndefined } from 'lodash';
import * as constants from './Constants'
import cookie from 'react-cookie'

var cookieOption = constants.COOKIE_OPTION;
var defaultExpires = constants.COOKIE_DEFAULT_EXPIRES;

var expiresCache = {};

export function get(key) {
  return cookie.load(key);
}

export function set(key, value) {
  cookie.save(key, value, copy(cookieOption));
}

export function setWithOption(key, value, option) {
  cookie.save(key, value, copy(option));
}

export function setWithExpires(key, value, expires) {
  cookie.save(key, value, extend(copy(cookieOption), { maxAge: expires }));
  expiresCache[key] = expires;
}

export function remove(key) {
  cookie.remove(key, copy(cookieOption));
  delete expiresCache[key];
}

export function removeWithOption(key, option) {
  cookie.remove(key, copy(option));
  delete expiresCache[key];
}

export function removeAll() {
  var cookies = document.cookie.split(';');
  each(cookies, function (value) {
    if (value !== '') {
      remove(value.split('=')[0]);
    }
  });
}

export function touch(key) {
  var value = get(key);
  if (isUndefined(value)) {
    return false;
  }
  setWithExpires(key, value, expiresCache[key] || defaultExpires);
  return true;
}
