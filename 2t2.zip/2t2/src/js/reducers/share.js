import * as Constants from "../utils/constants/Constants";
import createReducer from '../utils/create-reducer';

const dataTransferCIA = {
  moduleName: '',
  model: {
    title: '',
    value: '',
  },
  type: {
    title: '',
    value: '',
  },
  baseVersion: {
    cl: '',
    codeType: 'Java',
    id: '',
    path: '',
    qbServer: '',
    version: '',
    qbId: ''
  },
  targetVersion: {
    cl: '',
    codeType: 'Java',
    id: '',
    path: '',
    qbServer: '',
    version: '',
    qbId: ''
  },
};

const initialState = {
  alertPopup: {
    isShow: false,
    message: '',
    type: 'warning',
    successFnc: () => {}
  },
  confirmModal: {
    title: '',
    isShow: false,
    message: '',
    disableSubmitBtn: false,
    confirmCallBack: false,
    submitText: 'OK',
    successCallBack: () => {},
    failCallBack: () => {}
  },
  progressModal: {
    isShow: false
  },
  listCategory: [],
  loadToolFunc: () => {},
  functionReloadComment: () => {},
  functionReloadToolDetail: () => {},
  functionSetSearchText:() => {},
  getDiffUpload: () => {},
  reloadToolList: () => {},
  reloadAvatar: () => {},
  startSquare: () => {},
  dataTransferCIA: dataTransferCIA

};

const share = {
  [Constants.HIDE_ALERT]: (state, action) => ({ ...state, alertPopup: {...state.alertPopup, isShow: false}}),
  [Constants.SHOW_ALERT]: (state, action) => ({ ...state, alertPopup: {...state.alertPopup, isShow: true, message: action.message, successFnc: action.successCallBack}}),
  [Constants.HIDE_MODAL]: (state, action) => ({ ...state, confirmModal: {...state.confirmModal, isShow: false}}),
  [Constants.ACTION_MODAL]: (state, action) => ({
    ...state, confirmModal: {...state.confirmModal, isShow: true, successCallBack: action.successCallBack, failCallBack: action.failCallBack,
    title:action.title, message: action.message, disableSubmitBtn: action.disableSubmitBtn}
  }),
  [Constants.CONFIRM_MODAL_CUSTOM]: (state, action) => ({
    ...state, confirmModal: {...state.confirmModal, isShow: true, successCallBack: action.successCallBack, failCallBack: action.failCallBack,
      title:action.title, message: action.message, disableSubmitBtn: action.disableSubmitBtn, submitText: action.submitText}
  }),
  [Constants.CHECK_DISABLE_ACTION_MODAL]: (state, action) => ({
    ...state, confirmModal: {...state.confirmModal, disableSubmitBtn: action.disableSubmitBtn}
  }),
  [Constants.GET_DIFF_UPLOAD]: (state, action) => ({ ...state, getDiffUpload: action.functionGetDiffUpload}),
  [Constants.SHOW_PROGRESS]: (state, action) => ({ ...state, progressModal: {...state.progressModal, isShow: true}}),
  [Constants.HIDE_PROGRESS]: (state, action) => ({ ...state, progressModal: {...state.progressModal, isShow: false}}),
  [Constants.ADD_RELOAD_AVATAR]: (state, action) => ({ ...state, reloadAvatar: action.reloadAvatar}),
  [Constants.SET_LIST_CATEGORY]: (state, action) => ({ ...state, listCategory: action.listCategory}),
  [Constants.ADD_FUNC_RELOAD_TOOL_LIST]: (state, action) => ({ ...state, reloadToolList: action.reloadToolList}),
  [Constants.SET_LOAD_TOOL_FUNC]: (state, action) => ({ ...state, loadToolFunc: action.loadToolFunc}),
  [Constants.ADD_FUNCTION_RELOAD]: (state, action) => ({ ...state, functionReloadComment: action.functionReloadComment}),
  [Constants.ADD_FUNCTION_REQUEST_RELOAD]: (state, action) => ({ ...state, functionReloadRequestComment: action.functionReloadRequestComment}),
  [Constants.ADD_FUNCTION_RELOAD_TOOL_DETAIL]: (state, action) => ({ ...state, functionReloadToolDetail: action.functionReloadToolDetail}),
  [Constants.ADD_FUNCTION_SET_SEARCH_TEXT]: (state, action) => ({ ...state, functionSetSearchText: action.functionSetSearchText}),
  [Constants.RELOAD_TOOL_LIST]: (state, action) => {
    state.loadToolFunc();
  },
  [Constants.CONFIRM_CALL_BACK]: (state, action) => ({ ...state, confirmModal:{ ...state.confirmModal ,confirmCallBack: action.confirmCallBack}}),
  [Constants.START_SQUARE]: (state, action) => ({ ...state, startSquare: action.functionStartSquare}),


  // remove transfer data
  [Constants.REMOVE_DATA]: (state, action) => ({ ...state, dataTransferCIA: dataTransferCIA}),
  // change transfer Data
  [Constants.CHANGE_DATA]: (state, action) => ({ ...state, dataTransferCIA: action.dataTransferCIA}),
};

export default createReducer(initialState, share);