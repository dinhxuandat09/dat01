import { combineReducers } from 'redux';

import appmenu from './appmenu';
import sidebar from './sidebar';
import dialog from './dialog';
import system from './application';
import share from './share';

export default combineReducers({
  system,
  appmenu,
  sidebar,
  dialog,
  share
});
