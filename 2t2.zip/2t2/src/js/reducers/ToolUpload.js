import { LOGGED_IN, LOG_OUT, LOCALE_SWITCHED, SHOW_ERROR, HIDE_ERROR } from '../utils/Constants';
import createReducer from '../utils/create-reducer';


const initialState = {
  data:[]
};

const actionHandlers = {
  [LOGGED_IN]: (_, action) => action.payload
};

export default createReducer(initialState, actionHandlers);
