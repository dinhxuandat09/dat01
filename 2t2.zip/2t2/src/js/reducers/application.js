import { LOGGED_IN, LOG_OUT, LOCALE_SWITCHED, SHOW_ERROR, HIDE_ERROR, SET_ROLE } from '../utils/Constants';
import createReducer from '../utils/create-reducer';


const initialState = {
  token: null,
  locale: 'en',
  user: {
    // TODO: have a checkbox to update the state
    // e.g.: on the login page and/or menu
    // permissions: ['manage_account']
    permissions: []
  },
  error: null,
  upload: null
};

const actionHandlers = {
  [LOGGED_IN]: (_, action) => action.payload,
  [LOG_OUT]: () => ({ token: null }),
  [LOCALE_SWITCHED]: (_, action) => ({ locale: action.payload }),

  // TODO: this handle only API error responses.
  // We should also handle all other kind of application errors,
  // report them and show some kind of helpful message to the user.
  [SHOW_ERROR]: (state, action) => {
    const { payload, source } = action
    return Object.assign({}, state, {
      // TODO: ideally we want to map API error response codes
      // with some user-friendly messages.
      error: {
        source,
        message: payload.message,
        statusCode: payload.statusCode || payload.code,
        body: payload.body || (payload instanceof Error ?
          (payload.toString() + '\n' + payload.stack) : payload)
      }
    })
  },
  [HIDE_ERROR]: state => ({ ...state, ...{ error: null } }),
  [SET_ROLE]: (state, action) => ({ ...state, user: {...state.user, permissions: action.user.permissions}})
}

export default createReducer(initialState, actionHandlers);
