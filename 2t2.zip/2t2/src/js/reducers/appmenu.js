import { TOGGLE_APP_MENU } from '../utils/constants/actiontypes';
import createReducer from '../utils/create-reducer';

const initialState = {
  isOpen: false,
};

const appmenuHandler = {
  [TOGGLE_APP_MENU]: (state, action) => ({ ...state, isOpen: !state.isOpen })
}

export default createReducer(initialState, appmenuHandler);
