import { CHANGE_COLLECTION, TOGGLE_COLLECTION } from '../utils/constants/actiontypes';
import createReducer from '../utils/create-reducer';

const initialState = {
  selectedItem: 'All',
  isOpen: false,
};

const sidebarHandler = {
  [CHANGE_COLLECTION]: (state, action) => ({ ...state, selectedItem: action.payload }),
  [TOGGLE_COLLECTION]: (state, action) => ({...state, isOpen : !state.isOpen })
}

export default createReducer(initialState, sidebarHandler);
