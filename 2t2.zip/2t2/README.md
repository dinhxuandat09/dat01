# Webportal Drive

> ${DESCRIPTION}

## Install

##to install all node modules
```bash
npm Install
```
## to node environment type
```bash
## set NODE_ENV=development
```
ignore ssl yarn
```bash
yarn config set "strict-ssl" false -g
```

to start the project
```bash
yarn start
```

## Port
8080

## License