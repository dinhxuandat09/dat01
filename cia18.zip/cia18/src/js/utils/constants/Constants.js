export const LOGGED_IN = 'LOGGED_IN';
export const LOG_OUT = 'LOG_OUT';
export const HIDE_ALERT = 'HIDE_ALERT';
export const SHOW_ALERT = 'SHOW_ALERT';
export const SHOW_MODAL = 'SHOW_MODAL';
export const HIDE_MODAL = 'HIDE_MODAL';
export const GET_DIFF_UPLOAD = 'GET_DIFF_UPLOAD';
export const ADD_FUNC_RELOAD_TOOL_LIST = 'ADD_FUNC_RELOAD_TOOL_LIST';
export const ADD_RELOAD_AVATAR = 'ADD_RELOAD_AVATAR';
export const ACTION_MODAL = 'ACTION_MODAL';
export const CHECK_DISABLE_ACTION_MODAL = 'CHECK_DISABLE_ACTION_MODAL';
export const CONFIRM_CALL_BACK = 'CONFIRM_CALL_BACK';
export const HIDE_PROGRESS = 'HIDE_PROGRESS';
export const SHOW_PROGRESS = 'SHOW_PROGRESS';
export const LOCALE_SWITCHED = 'LOCALE_SWITCHED';
export const SHOW_ERROR = 'SHOW_ERROR';
export const HIDE_ERROR = 'HIDE_ERROR';
export const ADD_FUNCTION_RELOAD = 'ADD_FUNCTION_RELOAD';
export const ADD_FUNCTION_REQUEST_RELOAD = 'ADD_FUNCTION_REQUEST_RELOAD';
export const ADD_FUNCTION_RELOAD_TOOL_DETAIL = 'ADD_FUNCTION_RELOAD_TOOL_DETAIL';
export const ADD_FUNCTION_SET_SEARCH_TEXT = 'ADD_FUNCTION_SET_SEARCH_TEXT';
export const SET_LIST_CATEGORY = 'SET_LIST_CATEGORY';

export const SET_LOAD_TOOL_FUNC = 'SET_LOAD_TOOL_FUNC';
export const RELOAD_TOOL_LIST = 'RELOAD_TOOL_LIST';

export const ERROR = 'ERROR';
export const SET_VIEW_MODE = "SET_VIEW_MODE";
export const START_SQUARE = "START_SQUARE";


export const COOKIE_OPTION = {
  path: '/'
};
export const VIEW_MODE = {
  'TILE_VIEW': 'TILE_VIEW',
  'LIST_VIEW': 'LIST_VIEW'
};
export const COOKIE_DEFAULT_EXPIRES = parseInt(1800);
export const DEFAULT_LOGIN_SESSION_EXPIRES = parseInt(1800);

var buildTargetRole = 'portal';
export const BUILD_TARGET_ROLE = buildTargetRole;
export const KEYS = {
  apiToken: 's1',
  uidToken: 'uid',
  ssoToken: 'iPlanetDirectoryPro',
  ssoTokenOpt: 'iPlanetDirectoryProOptVal',
};

export const REMOVE_DATA = "REMOVE_DATA";
export const CHANGE_DATA = "CHANGE_DATA";
// Action types naming
