import * as Constants from "../utils/constants/Constants";
import * as constants from "../utils/Constants";
export function hideAlert() {
  return {
    type: Constants.HIDE_ALERT
  }
}
export function showAlert(message, successCallBack) {
  return {
    type: Constants.SHOW_ALERT,
    message: message,
    successCallBack: successCallBack
  }
}

export function hideProgress() {
  return {
    type: Constants.HIDE_PROGRESS
  }
}

export function showProgress() {
  return {
    type: Constants.SHOW_PROGRESS
  }
}

export function closeModal() {
  return {
    type: Constants.HIDE_MODAL
  }
}
export function openModal(message, successCallBack) {
  return {
    type: Constants.SHOW_MODAL,
    message: message,
    successCallBack: successCallBack
  }
}

export function actionModal(title ,message, isShow, successCallBack, failCallBack, disableSubmitBtn) {
  return {
    type: Constants.ACTION_MODAL,
    title: title,
    message: message,
    isShow: isShow,
    successCallBack: successCallBack,
    failCallBack: failCallBack,
    disableSubmitBtn: disableSubmitBtn
  }
}

export function checkdisableActionModal(disableSubmitBtn) {
  return {
    type: Constants.CHECK_DISABLE_ACTION_MODAL,
    disableSubmitBtn: disableSubmitBtn
  }
}

export function confirmCallBack(confirmCallBack) {
  return {
    type: Constants.CONFIRM_CALL_BACK,
    confirmCallBack: confirmCallBack
  }
}

export function setListCategory(listCategory = []) {
  return {
    type: Constants.SET_LIST_CATEGORY,
    listCategory: listCategory
  }
}

export function loadToolFunc(loadToolFunc) {
  return {
    type: Constants.SET_LOAD_TOOL_FUNC,
    loadToolFunc: loadToolFunc
  }
}

export function reloadToolList() {
  return {
    type: Constants.RELOAD_TOOL_LIST,
  }
}

export function addFunctionReloadComment(func) {
  return {
    type: Constants.ADD_FUNCTION_RELOAD,
    functionReloadComment: func
  }
}

export function addFunctionReloadRequestComment(func) {
  return {
    type: Constants.ADD_FUNCTION_REQUEST_RELOAD,
    functionReloadRequestComment: func
  }
}

export function addFunctionReloadToolDetail(func) {
  return {
    type: Constants.ADD_FUNCTION_RELOAD_TOOL_DETAIL,
    functionReloadToolDetail: func
  }
}

export function addFunctionSetSearchText(func) {
  return {
    type: Constants.ADD_FUNCTION_SET_SEARCH_TEXT,
    functionSetSearchText: func
  }
}

export function setRole(permissions) {
  return {
    type: constants.SET_ROLE,
    user: {
      permissions: permissions
    }
  }
}

export function reloadAvatar(func) {
  return {
    type: Constants.ADD_RELOAD_AVATAR,
    reloadAvatar: func
  }
}

export function reloadToolPage(func) {
  return {
    type: Constants.ADD_FUNC_RELOAD_TOOL_LIST,
    reloadToolList: func
  }
}

export function getDiffUpload(func) {
  return {
    type: Constants.GET_DIFF_UPLOAD,
    functionGetDiffUpload: func
  }
}

function functionStartSquare(ids) {
  let chat_objects = 'mysingleim://';
  let chat_array = "";
  if (ids instanceof  Array) {
    for (let i = 0; i < ids.length; i ++) {
      chat_array = chat_array + ids[i] + ';';
    }
    chat_objects = chat_objects + chat_array;
  } else {
    chat_objects = chat_objects + ids;
  }
  let url = chat_objects;
  $('<iframe>').hide().attr('src',url).appendTo(document.body);
}

export function startSquare(ids) {
  return {
    type: Constants.START_SQUARE,
    functionStartSquare: functionStartSquare(ids)
  };
}

export function removeDataTransfer() {
  return {
    type: Constants.REMOVE_DATA,
  }
}

export function changeDataTransfer(data) {
  return {
    type: Constants.CHANGE_DATA,
    dataTransferCIA: data
  }
}