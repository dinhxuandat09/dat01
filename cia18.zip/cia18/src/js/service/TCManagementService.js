import { isUndefinedOrNull, isFunction } from 'lodash';
import {makeGetRequest, makePostRequest} from '../utils/cuiResource';


export function getTestCaseByTCSuit(data, successCallBack, failCallBack) {
  let config = {
    url: 'api/test-cases/getAll',
    params: {
      testSuitId:'',
      sortBy: null,
      orderBy: 'descending',
      pageNum: 0,
      pageSize: 8
    }
  };
  config.params = Object.assign({}, config.params, data);
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}

export function uploadTestCases (data, successCallback, failCallback) {
  let config = {
    url: '/api/test-cases/upFile',
    params: {
      moduleName: data.moduleName,
      testSuit: data.testSuit
    },
    data: data.file
  };
  makePostRequest(config, (response) => {
    successCallback(response);
  }, (error) => {
    failCallback(error);
  });
}

export function exportTestCasesList(data, successCallBack, failCallBack) {
  let config = {
    url: 'api/test-cases/export',
    params: {
      testSuitId:data.testSuitId
    },
    headers: {'Content-Type': "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"},
    responseType: "arraybuffer"
  };
  makeGetRequest(config, (response) => {
    successCallBack(response);
  }, (error) => {
    failCallBack(error);
  })
}