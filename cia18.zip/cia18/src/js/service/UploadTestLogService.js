import { isUndefinedOrNull, isFunction } from 'lodash';
import { makeGetRequest, makePutRequest, makePostRequest, makeDeleteRequest } from '../utils/cuiResource';

export function getUploadTestLog(data, successCallback, failCallback) {
  let config = {
    url: '/api/test-cases/search',
    params: {
      modelId: null,
      moduleId: null,
      versionId: null,
      modelName: null,
      moduleName: null,
      versionName: null,
      testSuitName: null,
      testSuitId: null,
      pageNum: null,
      pageSize: null,
      sortBy: null,
      sortOrder: 'ascending'
    }
  };
  config.params = Object.assign({}, config.params, data);
  makeGetRequest(config, (response) => {
    successCallback(response);
  }, (error) => {
    failCallback(error);
  })
}

export function uploadMultiTestLogs (data, successCallback, failCallback) {
  let config = {
    url: '/api/files/multitestlogs',
    params: {
      model: data.modelId,
      moduleName: data.moduleName,
      version: data.versionId,
      testsuit: data.testSuitId
    },
    data: data.file
  };
  makePostRequest(config, (response) => {
    successCallback(response);
  }, (error) => {
    failCallback(error);
  });
} 

export function uploadTestLog (data, successCallback, failCallback) {
  let config = {
    url: '/api/files/testlog',
    params: {
      model: data.modelId,
      moduleName: data.moduleName,
      version: data.versionId,
      testsuit: data.testSuitId
    },
    data: data.file
  };
  makePostRequest(config, (response) => {
    successCallback(response);
  }, (error) => {
    failCallback(error);
  });
}

export function deleteLog (id, successCallback, failCallback) {
  let config = {
    url: '/api/file-logs/' + id
  };
  makeDeleteRequest(config, (response) => {
    successCallback(response);
  }, (error) => {
    failCallback(error);
  });
}