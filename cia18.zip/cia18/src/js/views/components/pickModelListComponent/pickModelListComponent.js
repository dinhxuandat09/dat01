import React from 'react';
import {connect} from "react-redux";
import '../../../../public/styles/pages/CIATable.scss';
import '../../../../public/styles/pages/PickModelListComponent.scss';
import * as commonService from '../../../service/commonService';
import UltimatePagination from "react-ultimate-pagination-bootstrap-4";
import {showProgress, hideProgress} from '../../../actions/share';
import Ic_Close from '../../../../public/images/icons/ic_close_black.png'
import {setTimeout, clearTimeout} from 'timers';

let CIAModelData = {
  pageSize: 8
};

class PickModelListComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      listModel: [],
      currentPage: 1,
      TotalPage: 1,
      searchText: '',
      showModelList: false,
    };
    if (this.props.modelInit) {
      this.state = {
        ...this.state,
        searchText: this.props.modelInit,
      }
    }
  }

  componentWillMount() {
    CIAModelData.modelName = null;
    CIAModelData.pageNum = 0;
    this.getListModel(CIAModelData);
    if(this.props.modelName){
      this.setState({
        searchText: this.props.modelName
      })
    }
  };

  getListModel = (data) => {
    commonService.getModel(data, (res) => {
      this.setState({
        listModel: res.data.value.list,
        TotalPage: Math.ceil(res.data.value.totalCount / 8) !== 0 ? Math.ceil(res.data.value.totalCount / 8) : 1
      });
    }, (error) => {
    });
  };

  handlePickModel = (item) => e => {
    this.setState({
      searchText: item.title,
      showModelList: false
    });
    this.props.pickModel(item);
    CIAModelData.modelName = item.title;
    this.handleSearchModel(CIAModelData);
  };

  handleChangePage = (page) => {
    this.setState({
      currentPage: page
    });
    CIAModelData.pageNum = page - 1;
    this.getListModel(CIAModelData);
  };
  clearTimerModel = () => {
    clearTimeout(this.timerHandleSearch);
    this.timerHandleSearch = null;
  }
  handleChangeSearchText = () => e => {
    this.setState({
      searchText: e.target.value,
    });
    CIAModelData.modelName = e.target.value;
    this.clearTimerModel();
    this.timerHandleSearch = setTimeout(this.handleSearchModel, 250);
    if (!e.target.value) {
      this.props.clearModuleList();
    }
  };

  handleSearchModel = () => {
    CIAModelData.pageNum = 0;
    this.setState({
      currentPage: 1
    });
    this.getListModel(CIAModelData);
  };

  openModalModelList = () => {
    this.setState({
      showModelList: true
    });
    this.ClosePopUpClickOutSize();
  };

  ClosePopUpClickOutSize = () => {
    $(document).on('click touch', (e) => {
      if (!$(e.target).parents().addBack().is('.model-list-container')) {
        if (e.target.id != "input-component-model" && e.target.className !== 'page-link' && this.state.showModelList)
          this.setState({ showModelList: false });
      }
    });
  };

  render() {
    return (
      <div>
        <input type="text" className="cia-text" id="input-component-model"
               onClick={this.openModalModelList}
               value={this.state.searchText} onChange={this.handleChangeSearchText()}
               placeholder="Enter Model"
        />
        {this.state.showModelList &&
          <div className={`model-list-container popup-model ${!this.state.listModel || this.state.listModel.length == 0 ? "show-warning" : ""}`}>
            <div className="model-list-body-container">
              {this.state.listModel && this.state.listModel.length > 0 &&
                <div className="table-wrapper">
                  <table className="table table-striped">
                    <tbody>
                      <tr className="table-header">
                        <th className="text-center">Model ID</th>
                        <th className="text-center">Model Name</th>
                      </tr>
                      {this.state.listModel.map((item, idx) => {
                        return <tr key={idx} onClick={this.handlePickModel(item)}>
                          <td className="padding-15">{item.value}</td>
                          <td className="padding-15">{item.title}</td>
                        </tr>;
                      })}
                    </tbody>
                  </table>
                  <UltimatePagination
                    currentPage={this.state.currentPage}
                    totalPages={this.state.TotalPage}
                    onChange={this.handleChangePage}
                  />
                </div>
              }
              {!this.state.listModel || this.state.listModel.length == 0 &&
                <div className="empty-data"><span className="text-center">Data do not exist ! Please input again</span></div>}
            </div>
          </div>
        }
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return {
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    }
  };
};

export default connect(null, mapDispatchToProps)(PickModelListComponent);