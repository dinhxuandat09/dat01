import React, { Component, PropTypes } from 'react';

class Checkbox extends Component {
  state = {
    isChecked: this.props.item.value,
  }

  toggleCheckboxChange = () => {
    const { handleCheckboxChange, item } = this.props;

    this.setState(({ isChecked }) => (
    {
      isChecked: !isChecked,
    }
    ));

    handleCheckboxChange(item.id);
  }

  render() {
    const { item } = this.props;
    const { isChecked } = this.state;

    return (
      <div className="item-checkbox">
          <input
            type="checkbox"
            value={item.name}
            checked={isChecked}
            disabled={item.default}
            onChange={this.toggleCheckboxChange}
          />

          <span>{item.name}</span>
      </div>
    );
  }
}

Checkbox.propTypes = {
  item: PropTypes.object.isRequired,
  handleCheckboxChange: PropTypes.func.isRequired,
};

export default Checkbox;
