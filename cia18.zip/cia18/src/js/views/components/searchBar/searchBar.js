import React from 'react'
import '../../../../public/styles/commons/searchBar/searchBar.scss';
import { makeGetRequest, makePostRequest } from '../../../utils/cuiResource';
import { showProgress, hideProgress, addFunctionSetSearchText } from "../../../actions/share";
import ProgressModal from '../progressModal/ProgressModal';
import { connect } from "react-redux";
import { push } from 'redux-router';
import image_search from "../../../../public/images/icons/ic_search.png";
import btnDownload from "../../../../public/images/icons/btnDownload.png";
import { fail } from 'assert';

class SearchBar extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      inputText: '',
      path: ["/Home", "/BuildTestBinary", "/UploadTestLog", "/CodeDiff", "/CIAReport", "/TCManagement", "/Community"],
      showbtnRemove: false,
    }
  }
 
  onChange = (e) => {
    this.setState({
      inputText: e.target.value,
      showbtnRemove : true
    });
    if(e.target.value == '')
     this.setState({showbtnRemove : false});
  };
  componentDidMount() {
    this.state.path.map((item, indx) => {
      this.props.router.location.pathname === item ? document.getElementById(item).classList.add("change-page") : document.getElementById(item).classList.remove("change-page");
    });
  };
  handleSearch = (e) => {
    this.props.redirectPage('/Search/' + this.state.inputText);
  }

  handleEnterSearch = (e) => {
    const key = e.which || e.keyCode;
    const ENTER = 13;
    if(key === ENTER)
      this.handleSearch();
  };

  handleDownload = () =>{
    window.open('http://mosaic.sec.samsung.net/kms/comty.do?comtyId=2093984&menuId=2352351&postId=2352370&page=view&type=LIST&access=ADDRESS', '_blank')
  };

  render() {
    return (
      <div className="search-bar">
        <ProgressModal />
        <input className="form-control search-input" placeholder="Search here"
          value={this.state.value}
          onKeyDown={this.handleEnterSearch}
          onChange={this.onChange}/>
        {this.state.showbtnRemove && <button className="remove-text-input" type="text">X</button>}
        <button type="button" className="btn btn-default search-btn" onClick={this.handleSearch}>
          <img src={image_search} width={32} height={32} ></img>
        </button>
        <button type="button" className="btn btn-default search-btn" onClick={this.handleDownload}>
          <img src={btnDownload} width={32} height={32} ></img>
        </button>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  router: state.router,
});

const mapDispatchToProps = dispatch => {
  return {
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    },
    redirectPage: url => {
      dispatch(push(url));
    },
    addFunctionSetSearchText: (func) => {
      dispatch(addFunctionSetSearchText(func))
    }
  };
};


export default connect(mapStateToProps, mapDispatchToProps)(SearchBar);