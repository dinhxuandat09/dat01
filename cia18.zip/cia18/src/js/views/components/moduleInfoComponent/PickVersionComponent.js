import React from 'react';
import { connect } from "react-redux";
import { push } from "redux-router";
import '../../../../public/styles/pages/CIATable.scss';
import '../../../../public/styles/pages/PickModelListComponent.scss';
import * as commonService from '../../../service/commonService';
import { Modal, Button } from 'react-bootstrap';
import UltimatePagination from "react-ultimate-pagination-bootstrap-4";
import { showProgress, hideProgress } from '../../../actions/share';
import Ic_Close from '../../../../public/images/icons/ic_close_black.png'
import Ic_Running from '../../../../public/images/ic_loading.gif';

let CIAVersionData = {
  pageSize: 8
};

class PickVersionListComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      listVersionBinary: [],
      currentPage: 1,
      TotalPage: 1,
      searchText: props.versionInit,
      showVersionList: false,
      textid: ''
    }
  }

  componentWillMount() {
    CIAVersionData.modelName = null;
    CIAVersionData.pageNum = 0;
    if (this.props.targetversion != null) {
      this.setState({ textid: 'input-component-targetversion' });
    } else {
      this.setState({ textid: 'input-component-baseversion' });
    }
    if(this.props.versionName){
      CIAVersionData.modelName = this.props.versionName;
      this.setState({
        searchText: this.props.versionName
      });
      this.getVersionByModule(CIAVersionData);
    }
  };


  getVersionByModule = (data) => {
    commonService.getVersionByModule(data, (res) => {
      this.setState({
        listVersionBinary: res.data.value.list,
        TotalPage: Math.ceil(res.data.value.totalCount / 8) !== 0 ? Math.ceil(res.data.value.totalCount / 8) : 1
      });
    }, (error) => {
    })
  };

  componentWillReceiveProps(nextProps) {
    if (nextProps.moduleName !== this.props.moduleName && nextProps.moduleName) {
      CIAVersionData.moduleName = nextProps.moduleName;
      this.getVersionByModule(CIAVersionData);
      this.setState({
        searchText: '',
        isShowSuggest: false,
      })
    } else {
      if (nextProps.targetversion !== this.props.targetversion && nextProps.targetversion) {
        this.setState({
          listVersionBinary: [],
          searchText: ''
        });
        CIAVersionData.versionId = nextProps.targetversion;
        this.getVersionByModule(CIAVersionData);
      }
    }
    if (!nextProps.moduleName) {
      this.setState({
        searchText: '',
        isShowSuggest: false,
        listVersionBinary: []
      })
    }
  }
  handlePickVersion = (item) => e => {
    this.setState({
      searchText: item.version,
      showVersionList: false
    });
    this.props.pickVersion(item)
  };

  handleChangePage = (page) => {
    this.setState({
      currentPage: page
    });
    CIAVersionData.pageNum = page - 1;
    this.getVersionByModule(CIAVersionData);
  };

  handleChangeSearchText = () => e => {
    if (!e.target.value) {
      this.props.clearVersionData();
    }
    this.setState({
      searchText: e.target.value
    });
    CIAVersionData.versionName = e.target.value;
    CIAVersionData.pageNum = 0;
    this.handleSearchVersion();
  };

  handleSearchVersion = () => {
    CIAVersionData.pageNum = 0;
    this.setState({
      currentPage: 1
    });
    this.getVersionByModule(CIAVersionData);
  };

  openModalList = () => {
    this.setState({
      showVersionList: true
    });
    this.ClosePopUpClickOutSize();
    this.handleChangeSearchText();
  };

  ClosePopUpClickOutSize = () => {
    $(document).on('click touch', (event) => {
      if (!$(event.target).parents().addBack().is('.model-list-container')) {
        if (event.target.id != this.state.textid && this.state.showVersionList)
            this.setState({ showVersionList: false });
      }
    });
  };

  close = () => {
    this.setState({
      showVersionList: false
    })
  };

  render() {
    return (
      <div>
        <input type="text" className="cia-text" id={this.state.textid}
          onClick={this.openModalList}
          value={this.state.searchText} onChange={this.handleChangeSearchText()}
          onPaste={this.handleChangeSearchText()}
          placeholder={this.props.placeholder || "Enter Version"}
        />
        {this.state.showVersionList &&
          <div className="model-list-container popup-version" onClick={(e) => e.stopPropagation()}>
            <div className="model-list-body-container">
              {this.state.listVersionBinary && this.state.listVersionBinary.length > 0 &&
                <div className="table-wrapper">
                  <table className="table table-striped">
                    <tbody>
                      <tr className="table-header">
                        <th className="text-center">Version</th>
                      </tr>
                      {this.state.listVersionBinary.map((item, idx) => {
                        return <tr key={idx} onClick={this.handlePickVersion(item)}>
                          <td className="padding-15">{item.version}</td>
                        </tr>;
                      })}
                    </tbody>
                  </table>
                  <UltimatePagination
                    currentPage={this.state.currentPage}
                    totalPages={this.state.TotalPage}
                    onChange={this.handleChangePage}
                  />
                </div>
              }
              {!this.state.listVersionBinary || this.state.listVersionBinary.length == 0 &&
                <div>
                  {this.props.targetversion == undefined &&
                    <div className="empty-data"><span className="text-center">Data Do Not Exist !. Please Input Again</span></div>}
                  {this.props.targetversion != undefined && <div>
                    {this.props.targetversion == '' && <div className="empty-data"><span className="text-center">Data Do Not Exist !. Please Input Again</span></div>}
                    {this.props.targetversion != '' && <div className="data-loading"> <img src={Ic_Running} alt="Data Loading" className="running-img" />
                      <span className="text-center">Data Loading</span>
                    </div>}
                  </div>
                  }

                </div>
              }
            </div>
          </div>

        }
      </div>
    );
  }
}
const mapDispatchToProps = dispatch => {
  return {
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    }
  };
};

export default connect(null, mapDispatchToProps)(PickVersionListComponent);