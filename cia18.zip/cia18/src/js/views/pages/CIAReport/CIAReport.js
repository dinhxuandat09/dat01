import React from 'react';
import Header from '../../components/share/header';
import '../../../../public/styles/pages/CIAReport.scss';
import {Tabs, Tab} from 'react-bootstrap';
import * as commonService from '../../../service/commonService';
import * as CIAService from '../../../service/CIAReport/CIAReport';
import ComponentDropdown from '../../components/ComponentDropdown';
import ConfirmModal from '../../components/confirmModal/confirmModal';
import CIAReportMethodTable from './CIAReportMethodTable';
import CIAReportTCTable from './CIAReportTCTable';
import PickModelListComponent from '../../components/pickModelListComponent/pickModelListComponent';
import PickModuleListComponent from '../../components/pickModelListComponent/pickModuleListComponent';
import UltimatePagination from "react-ultimate-pagination-bootstrap-4";
import ExportAll from '../../../../public/images/icons/ic_excel-all.png';
import {actionModal, removeDataTransfer, changeDataTransfer} from "../../../actions/share";
import {connect} from "react-redux";
import {showProgress, hideProgress} from '../../../actions/share';
import {push} from "redux-router";
import ComponentPagination from '../../components/ComponentPagination';
import PickVersionListComponent from '../../components/moduleInfoComponent/PickVersionComponent';

let SearchCIAReport = {};
let CIAReportMethodData = {};
let CIAReportTCData = {};
let reportId = null;
let transferData = {};

class CIAReport extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      TypeCIAReportTitle: 'Enter Type',
      listTypeCIAReport: [],
      targetVersionCIAReportTitle: 'Enter Version',
      listTargetVersionCIAReport: [],
      MethodReport: {
        list: [],
        pageNum: ''
      },
      TCReport: {
        list: [],
        pageNum: '',
      },
      TotalMethodPage: 1,
      currentMethodPage: 1,
      totalMethodItem: 1,
      TotalTCPage: 1,
      currentTCPage: 1,
      totalTCItem: 1,
      tcTabIndex: 1,
      isShowDetailSearchResult: false,
      modelCIAReportTitle: "",
      moduleCIAReportTitle: "",
      baseVersionId: '',
      remote: "disabled"
    };
    if (this.props.location.search) {
      const searchParam = this.props.location.search.split("?");
      const listModuleInfo = searchParam[1].split(",")
      this.state = {
        ...this.state,
        modelCIAReportTitle: listModuleInfo[0],
        TypeCIAReportTitle: listModuleInfo[1],
        moduleCIAReportTitle: listModuleInfo[2],
        baseVersionId: listModuleInfo[3],
        targetVersionCIAReportTitle: listModuleInfo[4],
        isShowDetailSearchResult: true
      };
      reportId = listModuleInfo[5]
    }
  }

  componentWillMount() {
    SearchCIAReport.moduleName =  '';
  };

  componentDidMount() {
    this.onClickTab();
    document.getElementById("cia-report-tc-tabs-tab-1")
      .setAttribute("style", "border-top: 1px solid #3899ec;border-right: 1px solid #3899ec;border-left: 1px solid #3899ec; opacity: 1");
    this.handleClickMethodTab(1);
  };

  clearDataType = () => {
    transferData.type = '';
    this.setState({
      TypeCIAReportTitle: 'Enter Type',
      listTypeCIAReport: [],
    })
  };

  clearDataModule = () => {
    transferData.moduleName = '';
    SearchCIAReport.moduleName = null;
  };

  clearDataTargetVersion = () => {
    this.setState({
      listTargetVersionCIAReport: [],
    });
    transferData.targetVersion = ''
  };

  pickModel = (item) => {
    SearchCIAReport.modelId = item.value;
    transferData.model = item;
    this.clearDataModule();
    this.clearDataType();
    this.clearDataTargetVersion();
    this.getTypeByModel();
  };

  handleClickItemType = (item, idDropdown) => {
    this.clearDataModule();
    this.clearDataTargetVersion();
    this.setState({
      TypeCIAReportTitle: item.title,
    });
    SearchCIAReport.type = item.value;
    transferData.type = item;
  };

  handleClickModuleItem = (item) => {
    this.clearDataTargetVersion();
    SearchCIAReport.moduleName = item;
    transferData.moduleName = item;
  };

  pickBaseVersion = (item) => {
    SearchCIAReport.baseVersionId = item.id;
    transferData.baseVersion = item;
    this.setState({baseVersionId: item.id});
  };

  pickTargetVersion = (item) => {
    transferData.targetVersion = item;
    SearchCIAReport.targetVersionId = item.id;
  };

  getTypeByModel = () => {
    let Data = {
      modelId: SearchCIAReport.modelId,
    };
    this.props.showProgress();
    commonService.getTypeByModel(Data, (res) => {
      this.props.hideProgress();
      let DropdownList = [];
      for (let i = 0; i < res.data.length; i++) {
        let DropdownItem = {title: res.data[i], value: res.data[i]};
        DropdownList.push(DropdownItem);
      }
      this.setState({
        listTypeCIAReport: DropdownList
      })
    }, (error) => {
      this.props.hideProgress();
    })
  };

  getTargetVersion = (listBaseVersion) => {
    let versionList = [];
    for (let i = 0; i < listBaseVersion.length; i++) {
      if (listBaseVersion[i].id !== SearchCIAReport.baseVersionId) {
        versionList.push(listBaseVersion[i]);
      }
    }
    this.setState({
      listTargetVersionCIAReport: versionList
    })
  };
  clearStyleTab = () => {
    document.getElementById("cia-report-tc-tabs-tab-1").setAttribute("style", "border:none");
    document.getElementById("cia-report-tc-tabs-tab-2").setAttribute("style", "border:none");
    document.getElementById("cia-report-tc-tabs-tab-3").setAttribute("style", "border:none");
  };

  clearStyleMethodTab = () => {
    for (let i = 1; i <= 5; i++) {
      document.getElementById("cia-report-method-tabs-tab-" + i).setAttribute("style", "border: none");
    }
  };

  showReport = () => {
    this.props.showProgress();
    if (this.state.isShowDetailSearchResult) {
      this.handleClickTCTab(1);
      this.clearStyleTab();
      document.getElementById("cia-report-tc-tabs-tab-1").setAttribute("style", "border: 1px solid #3899ec; border-bottom: none");
      this.setState({isShowDetailSearchResult: false})
    } else {
      this.getIdReport();
    }
  };

  getIdReport = (acceptGet) => {
    if(acceptGet){
      SearchCIAReport.acceptGet = acceptGet;
    } else {
      SearchCIAReport.acceptGet = null;
    }
    CIAService.getCIAReport(SearchCIAReport, (res) => {
      this.props.hideProgress();
      reportId = res.data;
      this.handleClickTCTab(1);
      this.clearStyleTab();
      document.getElementById("cia-report-tc-tabs-tab-1").setAttribute("style", "border: 1px solid #3899ec; border-bottom: none");
      this.setState({remote: ''});
    }, (error) => {
      this.props.hideProgress();
      this.props.actionModal('Message', error.response.data.message, true, () => {
        if (error.response.data.description === '400003' || error.response.data.description === '400009') {
          this.props.changeDataTransfer(transferData);
          this.props.redirectPage('/UploadTestLog');
        }
        if (error.response.data.description === '400004' || error.response.data.description === '400007') {
          this.props.changeDataTransfer(transferData);
          this.props.redirectPage('/CodeDiff');
        }
        if (error.response.data.description === '400005' || error.response.data.description === '400008' || error.response.data.description === '400010'
          || error.response.data.description === '400012') {
          this.createReport();
        }
      }, () => {
        if(error.response.data.description === '400008'|| error.response.data.description === '400010'){
          this.getIdReport(true);
        }
      });
      this.setState({remote: "disabled"});
    });
  };

  createReport = () => {
    CIAService.createCIAReport(SearchCIAReport, (res) => {
      this.getIdReport();
    }, (error) => {
    })
  };

  getMethodReport = (data) => {
    this.props.showProgress();
    CIAService.getMethodReport(data, (res) => {
      this.props.hideProgress();
      this.setState({
        totalMethodItem: res.data.value.totalCount,
        MethodReport: {list: res.data.value.list, pageNum: data.pageNum},
        TotalMethodPage: Math.ceil(res.data.value.totalCount / 10) !== 0 ? Math.ceil(res.data.value.totalCount / 10) : 1
      });
    }, () => {
      this.props.hideProgress();
    })
  };

  getTCReport = (data) => {
    this.props.showProgress();
    CIAService.getTCReport(data, (res) => {
      this.props.hideProgress();
      this.setState({
        totalTCItem: res.data.value.totalCount,
        TCReport: {list: res.data.value.list, pageNum: data.pageNum},
        TotalTCPage: Math.ceil(res.data.value.totalCount / 10) !== 0 ? Math.ceil(res.data.value.totalCount / 10) : 1
      })
    }, () => {
      this.props.hideProgress();
    })
  };

  handleClickMethodTab = (index) => {
    if (reportId) {
      CIAReportMethodData.reportId = reportId;
      CIAReportMethodData.pageNum = 0;
      if (index === 1) {
        CIAReportMethodData.type = 'New'
      }
      if (index === 2) {
        CIAReportMethodData.type = 'Effected'
      }
      if (index === 3) {
        CIAReportMethodData.type = 'Not Effected'
      }
      if (index === 4) {
        CIAReportMethodData.type = 'Remove'
      }
      if (index === 5) {
        CIAReportMethodData.type = 'unchanged'
      }
      this.setState({
        currentMethodPage: 1
      });
      this.getMethodReport(CIAReportMethodData)
    }
    if (index === 1) {
      this.clearStyleMethodTab();
      document.getElementById("cia-report-method-tabs-tab-1").setAttribute("style", "border: 1px solid #3899ec; border-bottom: none; opacity: 1; background-color: white");
      document.getElementById("cia-report-method-tabs").classList.remove('nav-tabs-green');
      document.getElementById("cia-report-method-tabs").classList.remove('nav-tabs-orange');
      document.getElementById("cia-report-method-tabs").classList.add('nav-tabs-blue');
    }
    if (index === 2 || index === 3 || index === 4) {
      this.clearStyleMethodTab();
      document.getElementById("cia-report-method-tabs-tab-2").setAttribute("style", "border: none; opacity: 1; background-color: transparent");
      document.getElementById("cia-report-method-tabs-tab-3").setAttribute("style", "border: none; opacity: 1; background-color: transparent");
      document.getElementById("cia-report-method-tabs-tab-4").setAttribute("style", "border: none; opacity: 1; background-color: transparent");
      document.getElementById("cia-report-method-tabs-tab-" + index).setAttribute("style", "border: 1px solid #e45000; border-bottom: none; opacity: 1; background-color: white");
      document.getElementById("cia-report-method-tabs").classList.remove('nav-tabs-blue');
      document.getElementById("cia-report-method-tabs").classList.remove('nav-tabs-green');
      document.getElementById("cia-report-method-tabs").classList.add('nav-tabs-orange');
    }
    if (index === 5) {
      this.clearStyleMethodTab();
      document.getElementById("cia-report-method-tabs-tab-5").setAttribute("style", "border: 1px solid #267d03; border-bottom: none; opacity: 1; background-color: white");
      document.getElementById("cia-report-method-tabs").classList.remove('nav-tabs-blue');
      document.getElementById("cia-report-method-tabs").classList.remove('nav-tabs-orange');
      document.getElementById("cia-report-method-tabs").classList.add('nav-tabs-green');
    }
  };

  handleClickTCTab = (index) => {
    if (reportId) {
      CIAReportTCData.reportId = reportId;
      CIAReportTCData.pageNum = 0;
      if (index === 1) {
        CIAReportTCData.typeTc = null
      }
      if (index === 2) {
        CIAReportTCData.typeTc = 'Effected'
      }
      if (index === 3) {
        CIAReportTCData.typeTc = 'Not Effected'
      }
      this.setState({
        currentTCPage: 1
      });
      this.getTCReport(CIAReportTCData)
    }
    this.handleClickMethodTab(index === 3 ? 5 : index);
    this.setState({
      tcTabIndex: index
    });
  };

  handleChangeMethodPage = (pageNumber) => {
    this.setState({
      currentMethodPage: pageNumber
    });
    CIAReportMethodData.pageNum = pageNumber - 1;
    this.getMethodReport(CIAReportMethodData);
  };

  handleChangeTCPage = (pageNumber) => {
    this.setState({
      currentTCPage: pageNumber
    });
    CIAReportTCData.pageNum = pageNumber - 1;
    this.getTCReport(CIAReportTCData);
  };

  onClickTab = () => {
    document.getElementById("cia-report-tc-tabs-tab-1").addEventListener("click", () => {
      this.clearStyleTab();
      document.getElementById("cia-report-tc-tabs-tab-1").setAttribute("style", "border: 1px solid #3899ec; border-bottom: none;  opacity: 1");
      document.getElementById("cia-report-tc-tabs").classList.remove('nav-tabs-green');
      document.getElementById("cia-report-tc-tabs").classList.remove('nav-tabs-orange');
      document.getElementById("cia-report-tc-tabs").classList.add('nav-tabs-blue');
    });
    document.getElementById("cia-report-tc-tabs-tab-2").addEventListener("click", () => {
      this.clearStyleTab();
      document.getElementById("cia-report-tc-tabs-tab-2").setAttribute("style", "border: 1px solid #e45000; border-bottom: none; opacity: 1");
      document.getElementById("cia-report-tc-tabs").classList.remove('nav-tabs-blue');
      document.getElementById("cia-report-tc-tabs").classList.remove('nav-tabs-green');
      document.getElementById("cia-report-tc-tabs").classList.add('nav-tabs-orange');
    });
    document.getElementById("cia-report-tc-tabs-tab-3").addEventListener("click", () => {
      this.clearStyleTab();
      document.getElementById("cia-report-tc-tabs-tab-3").setAttribute("style", "border: 1px solid #267d03; border-bottom: none; opacity: 1");
      document.getElementById("cia-report-tc-tabs").classList.remove('nav-tabs-blue');
      document.getElementById("cia-report-tc-tabs").classList.remove('nav-tabs-orange');
      document.getElementById("cia-report-tc-tabs").classList.add('nav-tabs-green');
    });
  };
  clearModuleList = () => {
    SearchCIAReport.modelId = '';
    transferData.model = '';
    this.clearDataModule();
    this.clearDataType();
    this.clearDataTargetVersion();
  };
  clearDataWithEmptyModule = () => {
    this.clearDataModule();
    SearchCIAReport.baseVersionId = '';
    transferData.baseVersion = '';
    this.setState({baseVersionId: ''});
    this.forceUpdate();
  }

  handleDownloadExportFile = () => {
    if (reportId) {
      CIAService.exportReport(reportId, (response) => {
        let file = new Blob([response.data], {type: response.headers['content-type']});
        if (window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(file);
        }
      }, () => {
      })
    }
  };

  render() {
    return (
      <div className="cia-report-detail-wrapper">
        <Header/>
        <ConfirmModal/>
        <div className="content-title">
          <div className="content-title-text cia-title">CIA Report</div>
          <div className="content-title-square"></div>
        </div>
        <div className="cia-report-search-component">
          <div className="cia-title-small">Module info</div>
          <div className="cia-search-wrapper row">
            <div className=" medium col-lg-2">
              <span className="cia-label">Model</span>
              <div className=''>
                <PickModelListComponent
                  clearModuleList={this.clearModuleList}
                  pickModel={this.pickModel}
                  modelInit={this.state.modelCIAReportTitle}/>
              </div>
            </div>
            <div className=" small col-lg-2">
              <span className="cia-label  padding-0">Type</span>
              <ComponentDropdown title={this.state.TypeCIAReportTitle}
                                 iddropdown="cia-type" className=""
                                 listSearchStatus={this.state.listTypeCIAReport}
                                 handleClickItemDropdown={this.handleClickItemType}
              />
            </div>
            <div className="medium col-lg-3 module-info-component-wrapper">
              <span className=" cia-label">Module Name</span>
              <div className="">
                <PickModuleListComponent
                  clearDataWithEmptyModule={this.clearDataWithEmptyModule}
                  pickModule={this.handleClickModuleItem}
                  modelId={SearchCIAReport.modelId}
                  type={SearchCIAReport.type}
                  moduleInit={this.state.moduleCIAReportTitle}/>
              </div>
            </div>
            <div className="medium col-lg-2">
              <span className="cia-label">Base Version</span>
              <PickVersionListComponent
                pickVersion={this.pickBaseVersion}
                moduleName={SearchCIAReport.moduleName}
                versionInit={this.state.baseVersionId}
              />
            </div>
                
            <div className="medium col-lg-2">
              <span className="cia-label">Target Version</span>
              <PickVersionListComponent
                pickVersion={this.pickTargetVersion}
                moduleName={SearchCIAReport.moduleName}
                targetversion={this.state.baseVersionId}
                versionInit={this.state.targetVersionCIAReportTitle}
              />
            </div>

          </div>
        </div>
        <button className="btn btn-primary btn-show-report" onClick={this.showReport}>Create & Show report</button>
        <div className="cia-report-search-component">
          <div className="cia-title">Report</div>
          <Tabs defaultActiveKey={1} className="cia-tabs" animation={false} id="cia-report-tc-tabs"
                onSelect={this.handleClickTCTab}>
            <Tab eventKey={1} title="All TC" tabClassName="cia-report-tc-1"/>
            <Tab eventKey={2} title="Affected TC" tabClassName="cia-report-tc-2"/>
            <Tab eventKey={3} title="Not affected TC" tabClassName="cia-report-tc-3"/>
            <div className="cia-report-table-container">
              <CIAReportTCTable tableData={this.state.TCReport}/>
            </div>
            <div className="pagination-body">
              {this.state.TCReport && this.state.TCReport.list.length > 0 &&
              <ComponentPagination
                totalCount={this.state.totalTCItem}
                pageNum={this.state.TCReport.pageNum}
                currentPage={this.state.currentTCPage}
                totalPages={this.state.TotalTCPage}
                onChange={this.handleChangeTCPage}
              />
              }
            </div>
          </Tabs>
          <div className={`export-all-button ${this.state.remote}`} onClick={this.handleDownloadExportFile}>
            <img src={ExportAll} alt="Excell all"/> Export All
          </div>
          <Tabs defaultActiveKey={1} className="cia-tabs method" animation={false} id="cia-report-method-tabs"
                onSelect={this.handleClickMethodTab}>
            <Tab eventKey={1} title="New Method" className="cia-report-method-tabs-1"
                 disabled={this.state.tcTabIndex === 2 || this.state.tcTabIndex === 3}/>
            <Tab eventKey={2} title="Modefied Method (Covered TC)"
                 disabled={this.state.tcTabIndex === 3 || this.state.tcTabIndex === 1}/>
            <Tab eventKey={3} title="Modefied Method (Uncovered TC)"
                 disabled={this.state.tcTabIndex === 3 || this.state.tcTabIndex === 1}/>
            <Tab eventKey={4} title="Remove Method"
                 disabled={this.state.tcTabIndex === 3 || this.state.tcTabIndex === 1}/>
            <Tab eventKey={5} title="Unchanged Method"
                 disabled={this.state.tcTabIndex === 2 || this.state.tcTabIndex === 1}/>
            <CIAReportMethodTable tableData={this.state.MethodReport}/>
            <div className="pagination-body">
              {this.state.MethodReport && this.state.MethodReport.list.length > 0 &&
              <ComponentPagination
                totalCount={this.state.totalMethodItem}
                pageNum={this.state.MethodReport.pageNum}
                currentPage={this.state.currentMethodPage}
                totalPages={this.state.TotalMethodPage}
                onChange={this.handleChangeMethodPage}
              />
              }
            </div>
          </Tabs>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return {
    actionModal: (title, message, isShow, successCallBack, failCallBack, disableSubmitBtn) => {
      dispatch(actionModal(title, message, isShow, successCallBack, failCallBack, disableSubmitBtn));
    },
    redirectPage: url => {
      dispatch(push(url));
    },
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    },
    removeDataTransfer: () => {
      dispatch(removeDataTransfer());
    },
    changeDataTransfer: (data) => {
      dispatch(changeDataTransfer(data));
    },
  };
};

export default connect(null, mapDispatchToProps)(CIAReport);