import React from 'react';
import { connect } from "react-redux";
import { push } from "redux-router";
import '../../../../public/styles/commons/share/body.scss';
import '../../../../public/styles/pages/BuildTestBinary.scss';
import Header from '../../components/share/header';
import { loadToolFunc, reloadToolPage } from "../../../actions/share";
import { showProgress, hideProgress, actionModal, showAlert } from "../../../actions/share";
import ProgressModal from '../../components/progressModal/ProgressModal';
import { select } from 'react-cookie';
import ComponentDropdown from '../../components/ComponentDropdown';
import * as commonService from '../../../service/commonService';
import BinaryTable from './BinaryTable';
import * as BinaryService from '../../../service/BuilTestBinary/BuilTestBinary';
import UltimatePagination from "react-ultimate-pagination-bootstrap-4";
import PickModelListComponent from '../../components/pickModelListComponent/pickModelListComponent';
import PickModuleListComponent from '../../components/pickModelListComponent/pickModuleListComponent';
import PickVersionListComponent from '../../components/moduleInfoComponent/PickVersionComponent';
import ComponentPagination from '../../components/ComponentPagination';
let searchBinary = {};
let pageShow = {};
let checkQuickBuildData = {};
let isPolling = false;
class BuildTestBinary extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dropdownIsOpen: false,
      typeBinaryTitle: 'Search Type',
      listTypeBinary: [],
      disabled: true,
      versionSelected: {
        cl: '',
        codeType: 'Java',
        id: '',
        path: '',
        qbServer: '',
        version: '',
        qbId: ''
      },
      severBinaryTitle: '1717',
      listBuildLog: {
        list: [],
        pageNum: '',

      },
      TotalTCPage: 1,
      currentTCPage: 1,
      totalCount: 0
    };
  }

  componentWillMount() {
    this.props.showProgress();
    pageShow = {};
    searchBinary = {};
    checkQuickBuildData = {};
    isPolling = false;
    this.props.hideProgress();
  };

  componentWillUnmount() {
    clearTimeout(this.setTimeOut);
  };

  getTypeByModel = () => {
    let data = {
      modelId: searchBinary.modelId,
    };
    // this.props.showProgress();
    commonService.getTypeByModel(data, (res) => {
      this.props.hideProgress();
      let dropdownList = [];
      for (let i = 0; i < res.data.length; i++) {
        let item = { title: res.data[i], value: res.data[i] };
        dropdownList.push(item);
      }
      this.setState({
        listTypeBinary: dropdownList
      })
    }, (error) => {
      //this.props.hideProgress();
    })
  };

  handleClickItemDropdown = (item, idDropdown) => {
    if (idDropdown === 'cia-type') {
      this.setState({
        typeBinaryTitle: item.title,
      });
      searchBinary.type = item.value;
    }
  };

  getAllCheckBuildBinary = (data) => {
    this.props.showProgress();
    BinaryService.getAllCheckBuilFromBinary(data, (res) => {
      if (res.data.value.totalCount) {
        this.setState({
          listBuildLog: { list: res.data.value.list, pageNum: 0 },
          totalCount: res.data.value.totalCount,
          TotalTCPage: Math.ceil(res.data.value.totalCount / 10) !== 0 ? Math.ceil(res.data.value.totalCount / 10) : 1
        });
        if (data.versionId) {
          let checkBuilding = false;
          for (let i = 0; i < res.data.value.list.length; i++) {
            if (res.data.value.list[i].status === 'RUNNING' || res.data.value.list[i].status === 'New') {
              checkBuilding = true;
              break;
            }
          }
          if (checkBuilding) {
            this.props.showAlert('Another user is building this test binary. Please wait until the building process is completed then try again.');
            if (!isPolling) {
              this.pollingBuildTestBinary();
            }
          } else {
            this.props.actionModal('Message', 'This build was created by another user. You want to rebuild?', true, () => {
              this.buildTestBinary(data);
            }, () => {
            });
          }
        }
      } else {
        this.buildTestBinary(data);
      }
      this.props.hideProgress();
    }, (error) => {
      this.props.hideProgress();
    })
  };

  pollingBuildTestBinary = () => {
    BinaryService.getAllCheckBuilFromBinary(pageShow, (res) => {
      this.setState({
        listBuildLog: { list: res.data.value.list, pageNum: pageShow.pageNum },
        totalCount: res.data.value.totalCount,
        TotalTCPage: Math.ceil(res.data.value.totalCount / 10) !== 0 ? Math.ceil(res.data.value.totalCount / 10) : 1
      });
      let checkBuilding = false;
      for (let i = 0; i < res.data.value.list.length; i++) {
        if (res.data.value.list[i].status === 'RUNNING' || res.data.value.list[i].status === 'New') {
          checkBuilding = true;
          break;
        }
      }
      if (checkBuilding) {
        isPolling = true;
        this.setTimeOut = setTimeout(this.pollingBuildTestBinary, 5000);
      } else {
        isPolling = false;
      }
    }, () => {
    });
  };

  buildTestBinary = (data) => {
    BinaryService.builFromBinary(data, (res) => {
      if (!isPolling) {
        this.pollingBuildTestBinary();
      }
    }, (res) => {
    })
  };
  checkQuickBuild = (data, pageShow) => {
    BinaryService.checkQuickBuild(data, (res) => {
      if (res.data != '') {
        this.onloadTable();
        this.getAllCheckBuildBinary(pageShow);
      } else {
        this.props.showAlert("Configuration quickbuild unavaliable");
      }
    }, (res) => { })
  };

  onloadTable = () => {
    pageShow.modelId = searchBinary.modelId;
    pageShow.moduleName = searchBinary.moduleName;
    pageShow.versionId = searchBinary.versionId;
    pageShow.pageNum = 0;
  }
  onClickCheckBuild = () => {
    checkQuickBuildData.modelId = searchBinary.modelId;
    checkQuickBuildData.moduleName = searchBinary.moduleName;
    checkQuickBuildData.versionId = searchBinary.versionId;
    checkQuickBuildData.pageNum = 0;
    pageShow.pageNum = 0;
    let convertedPath = '';
    if(/^-{0,1}\d+$/.test(this.state.versionSelected.cl)){
      convertedPath = "/root" + this.state.versionSelected.path.substr(1);
    } else {
      var arr = this.state.versionSelected.path.split('/');
      arr.pop();
      convertedPath = "root/PACKAGE 2.0/" + arr[1] + '.git/PBS';
    }
    this.checkQuickBuild(convertedPath, checkQuickBuildData);
  };

  handleChangeTCPage = (pageNumber) => {
    this.setState({
      currentTCPage: pageNumber
    });
    pageShow.pageNum = pageNumber - 1;
    if (pageNumber === 1) {
      isPolling = false;
    }
    this.pollingBuildTestBinary(pageShow);
  };


  clearType = () => {
    this.setState({
      typeBinaryTitle: 'Search type',
      listTypeBinary: [],
    });
    searchBinary.type = null;
  };

  clearModuleName = () => {
    searchBinary.moduleName = null;
  };

  clearAllLabel = () => {
    searchBinary.versionId = '';
    this.setState({
      severBinaryTitle: '',
      versionSelected: {
        cl: '',
        codeType: 'Java',
        id: '',
        path: '',
        qbServer: '',
        version: '',
        qbId: ''
      },
    })
    this.setState({ disabled: true });
  };

  pickModel = (item) => {
    searchBinary.modelId = item.value;
    this.clearType();
    this.clearModuleName();
    this.clearAllLabel();
    this.getTypeByModel();
  };

  onHandleClick = (item) => {
    searchBinary.moduleName = item;
    this.clearAllLabel();
  };

  pickVersion = (item) => {
    searchBinary.versionId = item.id;
    this.setState({ disabled: false });
    this.setState({
      versionSelected: item
    })
  };
  clearModuleList = () => {
    searchBinary.modelId = '';
    this.clearModuleName();
    this.clearType();
    this.clearAllLabel();
  };

  clearDataWithEmptyModule = () => {
    this.clearModuleName();
    this.clearAllLabel();
  };

  render() {
    return (
      <div>
        <ProgressModal />
        <Header />
        <div className="content">
          <div className="content-title">
            <div className="content-title-text cia-title">Build Test Binary</div>
            <div className="content-title-square"></div>
          </div>

          <div className="content-border"></div>

          <div className="content-body">
            <div className="module-info">
              <div className="module-info-title cia-title-small"><span>Module Info</span></div>
              <div className="row module-info-content">
                <div className=" medium col-lg-2"><span className="cia-label">Model</span>
                  <div className=''><PickModelListComponent
                    clearModuleList={this.clearModuleList}
                    pickModel={this.pickModel}
                  /></div>
                </div>
                <div className=" medium col-lg-2 "><span className="cia-label">Type</span>
                  <ComponentDropdown title={this.state.typeBinaryTitle}
                    iddropdown="cia-type" className=""
                    listSearchStatus={this.state.listTypeBinary}
                    handleClickItemDropdown={this.handleClickItemDropdown}
                  />
                </div>
                <div className="medium col-lg-3 module-info-component-wrapper">
                  <span className=" cia-label">Module Name</span>
                  <div className="">
                    <PickModuleListComponent
                      clearDataWithEmptyModule={this.clearDataWithEmptyModule}
                      pickModule={this.onHandleClick}
                      modelId={searchBinary.modelId}
                      type={searchBinary.type} />
                  </div>
                </div>
                <div className="medium col-lg-2">
                  <span className="cia-label">Version</span>
                  <PickVersionListComponent
                    clearVersionData={this.clearAllLabel}
                    pickVersion={this.pickVersion}
                    moduleName={searchBinary.moduleName}
                  />
                </div>
                <div className=" small col-lg-2"><span className="  cia-label">Code Type</span>
                  <input disabled type="text" className="cia-text" value={this.state.versionSelected.codeType} />
                </div>
              </div>

              <div className="row module-info-content">
                <div className=" medium col-lg-2"><span className=" padding-5 cia-label">QB Server</span>
                  <div className=""><input disabled type="text" className=" cia-text"
                    value={this.state.versionSelected.qbServer} /></div>
                </div>
                <div className=" medium col-lg-2"><span className=" cia-label">QB ID</span>
                  <div className=""><input disabled type="text" className=" cia-text"
                    value={this.state.versionSelected.qbId} /></div>
                </div>
                <div className=" medium col-lg-3"><span className=" padding-0 cia-label">Server</span>
                  <div className=" padding-0"><input disabled type="text" className=" cia-text"
                    value="1717" /></div>
                </div>
                <div className=" medium col-lg-3"><span className=" cia-label">Path</span>
                  <div className=""><input disabled type="text" className=" cia-text"
                    value={this.state.versionSelected.path} /></div>
                </div>
                <div className=" small col-lg-2"><span className=" cia-label">CL/Commit</span>
                  <input disabled type="text" className="cia-text " value={this.state.versionSelected.cl} />
                </div>
              </div>
            </div>
          </div>
          <div className="border-check-build">
            <button className="btn btn-check-build btn-primary" disabled={this.state.disabled} onClick={this.onClickCheckBuild}> Check & Build</button>
          </div>

          <div className="border-latest-build cia-title"><span>Build Information</span></div>
          <div className="table-binary">
            <BinaryTable listBuildLog={this.state.listBuildLog} />
          </div>
          <div className="pagination-body">
            {this.state.listBuildLog.list && this.state.listBuildLog.list.length > 0 &&
              <ComponentPagination
                totalCount={this.state.totalCount}
                pageNum={this.state.listBuildLog.pageNum}
                currentPage={this.state.currentTCPage}
                totalPages={this.state.TotalTCPage}
                onChange={this.handleChangeTCPage}
              />
            }
          </div>
        </div>
      </div>

    );
  }
}

const mapStateToProps = (state) => ({
  listCategory: state.application.share.listCategory,
  setSearchText: state.application.share.functionSetSearchText,
  isShowProgress: state.application.share.progressModal.isShow
});


const mapDispatchToProps = dispatch => {
  return {
    actionModal: (title, message, isShow, successCallBack, failCallBack, disableSubmitBtn) => {
      dispatch(actionModal(title, message, isShow, successCallBack, failCallBack, disableSubmitBtn));
    },
    redirectPage: url => {
      dispatch(push(url));
    },
    setLoadToolFunc: (func) => {
      dispatch(loadToolFunc(func));
    },
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    },
    reloadToolPage: (func) => {
      dispatch(reloadToolPage(func));
    },
    showAlert: (message) => {
      dispatch(showAlert(message));
    }
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(BuildTestBinary);