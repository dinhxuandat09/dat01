import React from 'react';
import {connect} from "react-redux";
import {push} from "redux-router";
import {showProgress, hideProgress, actionModal} from "../../../actions/share";
import {showAlert} from "../../../actions/share";
import Header from '../../components/share/header';
import '../../../../public/styles/pages/TCManagement.scss';
import {getTcSuitByModel} from '../../../service/commonService';
import {getTestCaseByTCSuit, uploadTestCases, exportTestCasesList} from '../../../service/TCManagementService';
import { DropdownButton, MenuItem } from 'react-bootstrap';
import ProgressModal from '../../components/progressModal/ProgressModal';
import PickModuleListComponent from '../../components/pickModelListComponent/pickModuleListComponent';
import SideBarTcManagement from '../../components/SideBarTcManagement/SideBarTcManagement';
import DragAndDrop from '../../components/Dropzone/DragAndDrop';
import SettingDisplayingModal from '../../components/settingDisplayingModal/settingDisplayingModal';

import trashIcon from "../../../../public/images/icons/ic_delete1.png";
import gridViewIcon from "../../../../public/images/icons/tile-view.png";
import exportIcon from "../../../../public/images/icons/excel-icon.png";
import editIcon from "../../../../public/images/icons/edit-icon.png";
import settingIcon from "../../../../public/images/icons/ic_tool.png";

let listSetting = [
  {id:0, name: 'TC ID', value: true, default: true},
  {id:1, name: 'Small Category', value: false, default: false},
  {id:2, name: 'Pre-condition', value: true, default: true},
  {id:3, name: '1st Iteration', value: false, default: false},
  {id:4, name: 'Level', value: false, default: false},
  {id:5, name: 'Detail Function', value: false, default: false},
  {id:6, name: 'Test Objectives', value: false, default: false},
  {id:7, name: '2nd Iteration', value: false, default: false},
  {id:8, name: 'Operator', value: false, default: false},
  {id:9, name: 'Test Objectives', value: true, default: true},
  {id:10, name: 'Expected Result', value: true, default: true},
  {id:11, name: '3rd Iteration', value: false, default: false},
  {id:12, name: 'Platform/APK Version', value: true, default: true},
  {id:13, name: 'Input Specification', value: false, default: false},
  {id:14, name: 'Remarks', value: false, default: false},
  {id:15, name: 'Automation', value: false, default: false},
  {id:16, name: 'Middle Category', value: false, default: false},
];
let TCdataForUpload = {
  moduleName:'',
  TCSuitId:''
};
let TCSuitIdForShowTable = '';
class TCManagement extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      TCSuitText: 'Select TC Suit',
      TCSuitList: [],
      testCaseList: [],
      isShowSetting: false
    }
  }
  componentWillUnmount() {
  }

  handleSelectModule = (item) => {
    TCdataForUpload.moduleName = item;
    this.clearTCSuit();
    this.getTcSuit();
  };
  getTcSuit = () => {
    let data = {
      moduleName: TCdataForUpload.moduleName
    };
    getTcSuitByModel(data, (res) => {
      this.setState({
        TCSuitList: res.data.list
      })
    }, (error) => {
    });
  };
  clearDataWithEmptyModule = () => {
    this.clearTCSuit();
  };
  handleSelectType = (item) => () => {
    TCdataForUpload.TCSuitName = item.name;
    TCdataForUpload.TCSuitId = item.id;
    this.setState({
      TCSuitText: item.name,
    });
  };
  clearTCSuit = () => {
    this.setState({
      TCSuitText: 'Select TC Suit',
      TCSuitList: []
    })
  }
  getTCSuitId = (id) => {
    TCSuitIdForShowTable = id;
    let data = {
      testSuitId: id
    };
    getTestCaseByTCSuit(data, (res) => {
      this.setState({
        testCaseList: res.data.value.list
      })
    }, (error) => {
    });
  }
  getFileForUpload = (file) =>{
    TCdataForUpload.file = file;
  };
  uploadTestCasesAction = () => {
    let data = {};
    data.file = TCdataForUpload.file;
    data.moduleName = TCdataForUpload.moduleName;
    data.testSuit = TCdataForUpload.TCSuitName;
    if (!data.moduleName || !data.testSuit) {
      this.props.showAlert("Please select all fields Module Name, TC Suite!");
      return;
    }
    this.props.showProgress();
    uploadTestCases(data, (response) => {
      this.props.hideProgress();
      this.props.showAlert("Uploaded successfully");
      TCSuitIdForShowTable = TCdataForUpload.TCSuitId;
      this.getTCSuitId(TCdataForUpload.TCSuitId);
    }, (error) => {
      this.props.hideProgress();
      this.props.showAlert("Upload fail");
    });
  };
  exportTestCases = () => {
    let data = {
      testSuitId: TCSuitIdForShowTable
    };
    exportTestCasesList(data, (response) => {
      let file = new Blob([response.data], { type: response.headers['content-type'] });
      if (window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(file);
      }
    }, (error) => {
      this.props.showAlert("Export fail");
    });
  };

  setNewListFromSetting = (newList)=> {
    listSetting =  newList;
  }

  showSettingDisplay = (value) => () => {
    this.setState({
      isShowSetting: value
    })
  }


  render() {
    return (
      <div>
        <ProgressModal />
        <Header />
        <div className="content">
          <div className="upload-test-log-wrapper">
            <div className="content-title">
              <div className="content-title-text">TC Management</div>
              <div className="content-title-square"></div>
              <img src={settingIcon} alt="setting display" className="setting-icon" onClick={this.showSettingDisplay(true)}/>
            </div>
            <div className="upload-test-log-content">
              <div className="module-info">
                <div className="cia-title-small">Module Info</div>
                <div className="upload-form row">
                  <div className="col-lg-4">
                    <span>Module Name</span>
                    <div className="content-input">
                      <PickModuleListComponent
                        clearDataWithEmptyModule={this.clearDataWithEmptyModule}
                        pickModule={this.handleSelectModule}
                        modelId=''
                        type='' />
                    </div>
                  </div>

                  <div className="col-lg-3">
                    <span className="">TC Suit</span>
                    <div className="content-input">
                      <DropdownButton title={this.state.TCSuitText}  id="tcSuit">
                        {
                          this.state.TCSuitList.map((item, index) => {
                            return <MenuItem key={index} className="dropdown-item"
                                             onClick={this.handleSelectType(item)}>{item.name}</MenuItem>
                          })
                        }
                      </DropdownButton>
                    </div>
                  </div>

                  <div className="col-lg-5">
                    <span className="">TC File</span>
                    <div className="content-input ">
                      <DragAndDrop returnFile={this.getFileForUpload}>
                      <span>Drop only file here or click here to browser</span>
                      </DragAndDrop>
                    </div>
                  </div>
                </div>

              </div>
              <br/>
              <button className="btn btn-primary btn-upload" onClick={this.uploadTestCasesAction}>Upload</button>
              <br/>

              <div className="file-list display-table">
                <div className="cia-title">TC list</div>
                <hr />
                <div className="col-lg-4 sidebar-border-left">
                  <SideBarTcManagement getTCSuitId={this.getTCSuitId}/>
                </div>
                <div className="col-lg-8">
                  <div className="tool-bar">
                    <img className="right" alt="export" src={exportIcon} onClick={this.exportTestCases}/>
                    <img className="right" alt="view type" src={gridViewIcon}/>
                    <img className="right" alt="trash" src={trashIcon}/>
                  </div>
                  <table className="table table-striped">
                    <tbody>
                    <tr>
                      <th className="td-no"><input type="checkbox" value="all"/></th>
                      <th className="td-no">No</th>
                      <th className="td-id">TC ID</th>
                      {listSetting[4].value && <th className="td-level">Level</th>}
                      {listSetting[8].value && <th className="td-operator">Operator</th>}
                      <th className="td-platform">Platform/APK Version</th>
                      {listSetting[16].value && <th className="td-cate">Middle Category</th>}
                      {listSetting[1].value && <th className="td-cate">Small Category</th>}
                      {listSetting[5].value && <th className="td-detail">Detail Function</th>}
                      <th className="td-test">Test Objective</th>
                      {listSetting[13].value && <th className="td-input">Input Specification</th>}
                      <th className="td-pre">Pre-condition</th>
                      {listSetting[6].value && <th className="td-test">Test Objectives</th>}
                      <th className="td-file">Expected Result</th>
                      {listSetting[14].value && <th className="td-remark">Remarks</th>}
                      {listSetting[3].value && <th className="td-iterator">1st Iterator</th>}
                      {listSetting[7].value && <th className="td-iterator">2nd Iterator</th>}
                      {listSetting[11].value && <th className="td-iterator">3rd Iterator</th>}
                      {listSetting[15].value && <th className="td-automation">Automation</th>}
                      <th className="td-file">Update Date</th>
                      <th className="td-file">Creator</th>
                      <th className="td-file">Modify</th>
                    </tr>
                    {this.state.testCaseList.length > 0
                    && this.state.testCaseList.map((data, idx) => {
                      return <tr key={idx}>
                        <th className="td-select"><input type="checkbox" value={idx}/></th>
                        <th className="td-no">No</th>
                        <th className="td-id">{data.tcId}</th>
                          {listSetting[4].value &&<th className="td-level">{data.level}</th>}
                          {listSetting[8].value && <th className="td-operator">{data.operator}</th>}
                        <th className="td-platform">{data.platform}</th>
                          {listSetting[16].value &&<th className="td-cate">{data.middleCategory}</th>}
                          {listSetting[1].value && <th className="td-cate">{data.smallCategory}</th>}
                          {listSetting[5].value && <th className="td-detail">{data.function}</th>}
                        <th className="td-test">{data.objectives}</th>
                          {listSetting[13].value && <th className="td-input">{data.specification}</th>}
                        <th className="td-pre">{preCondition}</th>
                          {listSetting[9].value && <th className="td-test">{data.objectives}</th>}
                        <th className="td-file">{data.expectedResult}</th>
                          {listSetting[14].value && <th className="td-remark">{data.remarks}</th>}
                          {listSetting[3].value && <th className="td-iterator">1st Iterator</th>}
                          {listSetting[7].value && <th className="td-iterator">2nd Iterator</th>}
                          {listSetting[11].value && <th className="td-iterator">3rd Iterator</th>}
                          {listSetting[15].value && <th className="td-automation">Automation</th>}
                        <td className="td-date">Update Date</td>
                        <td className="td-date">Creator</td>
                        <td className="td-date">
                          <img className="" src={editIcon} alt="edit"/>
                        </td>
                      </tr>;
                    })}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          </div>
        </div>
        {this.state.isShowSetting &&
        <SettingDisplayingModal listSetting={listSetting}
                                showSettingDisplay={this.showSettingDisplay}
                                setNewListFromSetting={this.setNewListFromSetting}/>}
      </div>
    )
  }
}
const mapStateToProps = (state) => ({
  listCategory: state.application.share.listCategory,
  setSearchText: state.application.share.functionSetSearchText,
  isShowProgress: state.application.share.progressModal.isShow
});


const mapDispatchToProps = dispatch => {
  return {
    actionModal: (title, message, isShow, successCallBack, failCallBack) => {
      dispatch(actionModal(title, message, isShow, successCallBack, failCallBack));
    },
    redirectPage: url => {
      dispatch(push(url));
    },
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    },
    showAlert: (permissions) => {
      dispatch(showAlert(permissions));
    }
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(TCManagement);