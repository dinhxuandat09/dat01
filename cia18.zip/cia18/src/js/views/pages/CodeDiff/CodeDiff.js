import React from 'react';
import {connect} from "react-redux";
import {push} from "redux-router";
import '../../../../public/styles/commons/share/body.scss';
import '../../../../public/styles/pages/CodeDiff.scss';
import Header from '../../components/share/header';
import ProgressModal from '../../components/progressModal/ProgressModal';
import * as commonService from '../../../service/commonService';
import * as codeDiffService from '../../../service/codeDiff/codeDiff';
import ComponentDropdown from '../../components/ComponentDropdown';
import '../../../../public/styles/pages/CIATable.scss';
import CodeDiffTable from './codeDiffTable';
import PickModelListComponent from '../../components/pickModelListComponent/pickModelListComponent';
import PickModuleListComponent from '../../components/pickModelListComponent/pickModuleListComponent';
import {showProgress, hideProgress, showAlert, removeDataTransfer} from "../../../actions/share";
import ComponentPagination from '../../components/ComponentPagination';
import PickVersionListComponent from '../../components/moduleInfoComponent/PickVersionComponent';

let SearchCIA = {};
let listSearchStatus = [];

class CodeDiff extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      listModelCIA: [],
      TypeCIATitle: 'Enter Type',
      listTypeCIA: [],
      listTargetVersionCIA: [],
      baseVersionId: '',
      baseVersionInfo: {
        id: '',
        qbServer: '',
        path: '',
        cl: '',
        version: ''
      },
      targetVersionInfo: {
        qbServer: '',
        path: '',
        cl: '',
        version: ''
      },
      codeDiffTable: {
        list: [],
        pageNum: '',
      },
      TotalCodeDiffPage: 1,
      currentCodeDiffPage: 1,
      totalCount: 0,
    }
  }


  componentWillMount() {
    this.props.showProgress();
    commonService.getModel(null, (res) => {
      this.props.hideProgress();
      this.setState({
        listModelCIA: res.data.value.list
      })
    }, (error) => {
      this.props.hideProgress();
    });
    this.getAllCodeDiff();
    if (this.props.dataTransferCIA && this.props.dataTransferCIA.moduleName) {
      this.transferDataFromProps();
    }
  };

  componentWillUnmount() {
    clearTimeout(this.timeOut);
  };

  transferDataFromProps = () => {
    let modelName = null;
    let dropdownType = "Select type";
    SearchCIA.moduleName = this.props.dataTransferCIA.moduleName;
    SearchCIA.baseVersionId = this.props.dataTransferCIA.baseVersion.id;
    SearchCIA.baseCL = this.props.dataTransferCIA.baseVersion.cl;
    SearchCIA.basePath = this.props.dataTransferCIA.baseVersion.path;
    SearchCIA.baseServer = this.props.dataTransferCIA.baseVersion.qbServer;
    SearchCIA.targetVersionId = this.props.dataTransferCIA.targetVersion.id;
    SearchCIA.targetCL = this.props.dataTransferCIA.targetVersion.cl;
    SearchCIA.targetPath = this.props.dataTransferCIA.targetVersion.path;
    SearchCIA.targetServer = this.props.dataTransferCIA.targetVersion.qbServer;
    if (this.props.dataTransferCIA.model) {
      SearchCIA.appModelId = this.props.dataTransferCIA.model.value;
      SearchCIA.type = this.props.dataTransferCIA.type.value;
      modelName = this.props.dataTransferCIA.model.title;
      dropdownType = this.props.dataTransferCIA.type.value;
    }

    this.setState({
      modelName: modelName,
      TypeCIATitle: dropdownType,
      moduleName: SearchCIA.moduleName,
      baseVersionId: SearchCIA.baseVersionId,
      baseVersionInfo: this.props.dataTransferCIA.baseVersion,
      targetVersionInfo: this.props.dataTransferCIA.targetVersion
    }, () => {
      this.props.removeDataTransfer();
    })
  };

  clearDataType = () => {
    SearchCIA.type = '';
    this.setState({
      TypeCIATitle: 'Enter Type',
      listTypeCIA: [],
    })
  };

  clearDataModule = () => {
    SearchCIA.moduleName = '';
  };
  clearDataBaseVersion = () => {
    SearchCIA.baseVersionId = '';
    SearchCIA.baseCL = '';
    SearchCIA.basePath = '';
    SearchCIA.baseServer = '';
    this.setState({
      baseVersionInfo: {
        qbServer: '',
        path: '',
        cl: ''
      },
      baseVersionId: '',
    })
  };
  clearDataTargetVersion = () => {
    SearchCIA.targetVersionId = '';
    SearchCIA.targetCL = '';
    SearchCIA.targetPath = '';
    SearchCIA.targetServer = '';
    this.setState({
      listTargetVersionCIA: [],
      targetVersionInfo: {
        qbServer: '',
        path: '',
        cl: '',
      }
    })
  };

  handleClickItemType = (item, idDropdown) => {
    SearchCIA.type = item.value;
    this.clearDataModule();
    this.clearDataBaseVersion();
    this.clearDataTargetVersion();
    this.setState({
      TypeCIATitle: item.title,
    });
  };

  handleClickModuleItem = (item) => {
    SearchCIA.moduleName = item;
    this.clearDataBaseVersion();
    this.clearDataTargetVersion();
  };

  pickBaseVersion = (item) => {
    SearchCIA.baseVersionId = item.id;
    SearchCIA.baseCL = item.cl;
    SearchCIA.basePath = item.path;
    SearchCIA.baseServer = item.qbServer;
    this.setState({
      baseVersionInfo: item,
      baseVersionId: item.id,
    });
    this.clearDataTargetVersion();
  };

  pickTargetVersion = (item) => {
    SearchCIA.targetVersionId = item.id;
    SearchCIA.targetCL = item.cl;
    SearchCIA.targetPath = item.path;
    SearchCIA.targetServer = item.qbServer;
    this.setState({
      targetVersionInfo: item
    })
  };

  getTypeByModel = () => {
    let Data = {
      modelId: SearchCIA.appModelId,
    };
    this.props.showProgress();
    commonService.getTypeByModel(Data, (res) => {
      this.props.hideProgress();
      let DropdownList = [];
      for (let i = 0; i < res.data.length; i++) {
        let DropdownItem = {title: res.data[i], value: res.data[i]};
        DropdownList.push(DropdownItem);
      }
      this.setState({
        listTypeCIA: DropdownList
      })
    }, (error) => {
      this.props.hideProgress();
    })
  };


  createCodeDiff = () => {
    this.setState({
      currentCodeDiffPage: 1
    });
    this.props.showProgress();
    codeDiffService.createCodeDiff(SearchCIA, (res) => {
      this.props.hideProgress();
      this.getAllCodeDiff();
    }, (error) => {
      this.props.hideProgress();
      this.props.showAlert(error.response.data.message);
    })
  };

  handleChangeCodeDiffPage = (pageNumber) => {
    this.setState({
      currentCodeDiffPage: pageNumber
    });
    let data = {
      pageNum: null
    };
    data.pageNum = pageNumber - 1;
    this.getAllCodeDiff(data);
  };

  getAllCodeDiff = (data) => {
    clearTimeout(this.timeOut);
    this.props.showProgress();
    codeDiffService.getAllCodeDiff(data, (res) => {
      this.props.hideProgress();
      let page = 0;
      if (data != 'undefined' && data != null) {
        page = data.pageNum;
      }
      this.setState({
        codeDiffTable: {list: res.data.list, pageNum: page},
        totalCount: res.data.totalCount,
        TotalCodeDiffPage: Math.ceil(res.data.totalCount / 10) !== 0 ? Math.ceil(res.data.totalCount / 10) : 1
      });

      let checkLoad;
      for (let i = 0; i < res.data.list.length; i++) {
        checkLoad = false;
        if (res.data.list[i].reportFile == null || res.data.list[i].reportFile == 'undefined') {
          checkLoad = true;
          break;
        }
      }
      if (checkLoad) {
        this.timeOut = setTimeout(this.getAllCodeDiffRunning, 4000);
      }
    }, () => {
      this.props.hideProgress();
    })
  };
  getAllCodeDiffRunning = (data) => {

    codeDiffService.getAllCodeDiff(data, (res) => {
      let page = 0;
      if (data != 'undefined' && data != null) {
        page = data.pageNum;
      }
      this.setState({
        codeDiffTable: {list: res.data.list, pageNum: page},
        TotalCodeDiffPage: Math.ceil(res.data.totalCount / 10) !== 0 ? Math.ceil(res.data.totalCount / 10) : 1
      });

      let checkLoad;
      for (let i = 0; i < res.data.list.length; i++) {
        checkLoad = false;
        if (res.data.list[i].reportFile == null || res.data.list[i].reportFile == 'undefined') {
          checkLoad = true;
          break;
        }
      }
      if (checkLoad) {
        this.timeOut = setTimeout(this.getAllCodeDiffRunning, 4000);
      }
    }, () => {
    })
  };

  pickModel = (item) => {
    SearchCIA.appModelId = item.value;
    this.clearDataType();
    this.clearDataModule();
    this.clearDataBaseVersion();
    this.clearDataTargetVersion();
    this.getTypeByModel();
  };

  clearModuleList = () => {
    SearchCIA.appModelId = '';
    this.clearDataModule();
    this.clearDataType();
    this.clearDataBaseVersion();
    this.clearDataTargetVersion();
  };
  clearDataWithEmptyModule = () => {
    this.clearDataModule();
    this.clearDataBaseVersion();
    this.clearDataTargetVersion();
  };

  render() {
    return (
      <div>
        <ProgressModal/>
        <Header/>
        <div className="content">
          <div className="content-title">
            <div className="content-title-text cia-title">Code Diff</div>
            <div className="content-title-square"></div>
          </div>

          <div className="content-body">
            <div className="module-info module-info-codediff">
              <div className="module-info-title info-title-codediff "><span
                className="cia-title-small">Module Info Information</span>
              </div>
              <div className="row module-info-codediff-title">
                <div className="col-lg-3 "><span className=" cia-label">Model</span>
                  <div className="">
                    <PickModelListComponent
                      modelName={this.state.modelName}
                      clearModuleList={this.clearModuleList}
                      pickModel={this.pickModel}/>
                  </div>
                </div>

                <div className="col-lg-3 "><span className=" cia-label">Type</span>
                  <ComponentDropdown title={this.state.TypeCIATitle} iddropdown="cia-type"
                                     handleClickItemDropdown={this.handleClickItemType}
                                     className="" listSearchStatus={this.state.listTypeCIA}/>
                </div>
                <div className="col-lg-3 "><span className=" cia-label">Module Name</span>
                  <div className="">
                    <PickModuleListComponent
                      clearDataWithEmptyModule={this.clearDataWithEmptyModule}
                      pickModule={this.handleClickModuleItem}
                      moduleName={this.state.moduleName}
                      modelId={SearchCIA.appModelId}
                      type={SearchCIA.type}/>
                  </div>
                </div>
              </div>
              <div className="row label-diffcode info-content-codediff">
                <div className=" col-lg-3 medium-codediff"><span className=""></span></div>
                <div className=" col-lg-3 medium-codediff"><span className="">Version</span></div>
                <div className=" col-lg-3 medium-codediff"><span>Server</span></div>
                <div className=" col-lg-3 medium-codediff"><span>Path</span></div>
                <div className=" col-lg-3 medium-codediff"><span>CL/Commit</span></div>
              </div>
              <div className="row module-info-content info-content-codediff medium-codediff">
                <div className="medium-codediff col-lg-3">
                  <span className="span-version">Base Code</span>
                </div>
                <div className="medium-codediff col-lg-3">
                  <PickVersionListComponent
                    clearVersionData={this.clearDataBaseVersion}
                    pickVersion={this.pickBaseVersion}
                    moduleName={SearchCIA.moduleName}
                    versionName={this.state.baseVersionInfo.version}
                  />
                </div>
                <div className="col-lg-3 medium-codediff">
                  <input disabled type="text" className="input-codediff cia-text"
                         value={this.state.baseVersionInfo.qbServer}></input>
                </div>
                <div className="col-lg-3 medium-codediff">
                  <input disabled type="text" className="input-codediff cia-text"
                         value={this.state.baseVersionInfo.path}></input>
                </div>
                <div className="col-lg-3 medium-codediff">
                  <input disabled type="text" className="input-codediff cia-text"
                         value={this.state.baseVersionInfo.cl}></input>
                </div>
              </div>

              <div className="row module-info-content info-content-codediff">
                <div className="medium-codediff col-lg-3">
                  <span className="span-version">Target Code</span>
                </div>
                <div className="medium-codediff col-lg-3">
                  <PickVersionListComponent
                    clearVersionData={this.clearDataTargetVersion}
                    pickVersion={this.pickTargetVersion}
                    moduleName={SearchCIA.moduleName}
                    targetversion={this.state.baseVersionId}
                    versionName={this.state.targetVersionInfo.version}
                  />
                </div>
                <div className="col-lg-3 medium-codediff">
                  <input disabled type="text" className="input-codediff cia-text"
                         value={this.state.targetVersionInfo.qbServer}></input>
                </div>
                <div className=" col-lg-3 medium-codediff">
                  <input disabled type="text" className="input-codediff cia-text"
                         value={this.state.targetVersionInfo.path}></input>
                </div>
                <div className=" col-lg-3 medium-codediff">
                  <input disabled type="text" className="input-codediff cia-text"
                         value={this.state.targetVersionInfo.cl}></input>
                </div>
              </div>
            </div>
          </div>

          <div className="border-compare border-check-build">
            <button disabled={SearchCIA.moduleName && SearchCIA.baseVersionId && SearchCIA.targetVersionId ? false : true} 
            className="btn-check-build btn btn-primary" onClick={this.createCodeDiff}> Compare</button>
          </div>

          <div className="border-latest-comparision border-latest-build"><span className="cia-title">Module Info Information</span>
          </div>
          <div className="content-table table-codediff">
            <CodeDiffTable tableData={this.state.codeDiffTable}/>
          </div>
          <div className="pagination-body">
            {this.state.codeDiffTable && this.state.codeDiffTable.list.length > 0 &&
            <ComponentPagination
              totalCount={this.state.totalCount}
              pageNum={this.state.codeDiffTable.pageNum}
              currentPage={this.state.currentCodeDiffPage}
              totalPages={this.state.TotalCodeDiffPage}
              onChange={this.handleChangeCodeDiffPage}
            />
            }
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  dataTransferCIA: state.application.share.dataTransferCIA
});


const mapDispatchToProps = dispatch => {
  return {
    showAlert: (message, successCallBack) => {
      dispatch(showAlert(message, successCallBack));
    },
    showProgress: () => {
      dispatch(showProgress());
    },
    hideProgress: () => {
      dispatch(hideProgress());
    },
    removeDataTransfer: () => {
      dispatch(removeDataTransfer());
    }
  };
};


export default connect(mapStateToProps, mapDispatchToProps)(CodeDiff);